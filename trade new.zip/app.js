// ─────────────────────────────────────────────
// SUPABASE CLIENT
// ─────────────────────────────────────────────
const _sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
});
let _currentUser = null;
let _currentSession = null;

// Helper — get current JWT access token.
// Serve from the cached session on the hot path so concurrent startup calls don't
// all hit getSession() at once (supabase-js v2's Web Locks can return a null
// session under that contention → spurious 401s). Fall back to getSession() when
// the cached token is missing or within 60s of expiry — that path auto-refreshes.
async function _getToken() {
  const now = Math.floor(Date.now() / 1000);
  const s = _currentSession;
  if (s?.access_token && s.expires_at && s.expires_at > now + 60) return s.access_token;
  const { data: { session } } = await _sb.auth.getSession();
  if (session) _currentSession = session;
  return session?.access_token ?? '';
}

// Soft 401 recovery for edge functions: if a /functions/v1/ call comes back 401,
// force one session refresh and retry with the fresh token before the caller sees
// the error. Covers every edge-function fetch site centrally. Other fetches pass through.
const _origFetch = window.fetch.bind(window);
window.fetch = async (input, init) => {
  const res = await _origFetch(input, init);
  const url = typeof input === 'string' ? input : (input?.url ?? '');
  if (res.status !== 401 || !url.includes('/functions/v1/')) return res;
  try {
    const { data: { session } } = await _sb.auth.refreshSession();
    if (!session) return res;
    _currentSession = session;
    const retryInit = { ...(init || {}) };
    retryInit.headers = { ...(init?.headers || {}), 'Authorization': `Bearer ${session.access_token}` };
    return await _origFetch(input, retryInit);
  } catch {
    return res;
  }
};

// ─────────────────────────────────────────────
// AUTH
// ─────────────────────────────────────────────
let _authMode = 'login';

// ─────────────────────────────────────────────
// LEGAL / POLICY DOCUMENTS — open standalone pages (single source of truth)
// ─────────────────────────────────────────────
const LEGAL_PAGES = { privacy: 'privacy.html', terms: 'terms.html', accessibility: 'accessibility.html' };
function openLegal(type) {
  const url = LEGAL_PAGES[type];
  if (url) window.open(url, '_blank', 'noopener');
}

function authSetMode(mode) {
  _authMode = mode;
  const isReg = mode === 'register';
  document.getElementById('auth-first').style.display     = isReg ? '' : 'none';
  if (!isReg) document.getElementById('auth-first').value = '';
  document.getElementById('auth-pass2').style.display     = isReg ? '' : 'none';
  document.getElementById('auth-consent-row').style.display = isReg ? 'flex' : 'none';
  if (!isReg) document.getElementById('auth-consent').checked = false;
  document.getElementById('auth-pass').autocomplete       = isReg ? 'new-password' : 'current-password';
  document.getElementById('auth-submit-btn').textContent  = isReg ? 'הרשמה' : 'כניסה';
  document.getElementById('auth-forgot-btn').style.display= isReg ? 'none' : '';
  document.getElementById('auth-tab-login').style.background    = isReg ? 'transparent' : '#4f46e5';
  document.getElementById('auth-tab-login').style.color         = isReg ? 'var(--text2)' : '#fff';
  document.getElementById('auth-tab-register').style.background = isReg ? '#4f46e5' : 'transparent';
  document.getElementById('auth-tab-register').style.color      = isReg ? '#fff' : 'var(--text2)';
  document.getElementById('auth-strength').style.display = 'none';
  document.getElementById('auth-strength-bar').style.width = '0';
  _authMsg('', '');
}

function authPasswordStrength(val) {
  if (_authMode !== 'register') return;
  const el  = document.getElementById('auth-strength');
  const bar = document.getElementById('auth-strength-bar');
  const txt = document.getElementById('auth-strength-txt');
  if (!val) { el.style.display = 'none'; return; }
  el.style.display = '';
  const score = [val.length >= 8, /[A-Z]/.test(val), /[0-9]/.test(val), /[^A-Za-z0-9]/.test(val)].filter(Boolean).length;
  const levels = [
    { w: '25%', color: '#ff6b8a', label: 'חלשה' },
    { w: '50%', color: '#f59e0b', label: 'בינונית' },
    { w: '75%', color: '#3b82f6', label: 'טובה' },
    { w: '100%', color: '#2dd4a0', label: 'חזקה' },
  ];
  const lvl = levels[score - 1] || levels[0];
  bar.style.width      = lvl.w;
  bar.style.background = lvl.color;
  txt.style.color      = lvl.color;
  txt.textContent      = lvl.label;
}

function _authMsg(text, type) {
  const el = document.getElementById('auth-msg');
  if (!text) { el.style.display = 'none'; return; }
  el.style.display = '';
  el.style.background = type === 'error' ? 'rgba(255,107,138,.12)' : 'rgba(45,212,160,.12)';
  el.style.color      = type === 'error' ? 'var(--red)' : 'var(--green)';
  el.textContent = text;
}

async function authSubmit() {
  const email = (document.getElementById('auth-email').value || '').trim();
  const pass  = (document.getElementById('auth-pass').value  || '');
  if (!email || !pass) { _authMsg('נא למלא אימייל וסיסמה', 'error'); return; }

  const btn = document.getElementById('auth-submit-btn');
  btn.disabled = true;
  btn.textContent = '...';

  try {
    if (_authMode === 'register') {
      const first = (document.getElementById('auth-first').value || '').trim();
      const pass2 = document.getElementById('auth-pass2').value || '';
      if (!first) { _authMsg('נא להזין שם פרטי', 'error'); document.getElementById('auth-first').focus(); return; }
      if (pass !== pass2) { _authMsg('הסיסמאות אינן תואמות', 'error'); return; }
      if (pass.length < 8) { _authMsg('סיסמה חייבת להכיל לפחות 8 תווים', 'error'); return; }
      if (!document.getElementById('auth-consent').checked) { _authMsg('יש לאשר את תנאי השימוש ומדיניות הפרטיות', 'error'); return; }
      const { error } = await _sb.auth.signUp({ email, password: pass, options: { data: { first_name: first, full_name: first } } });
      if (error) throw error;
      _authMsg('נשלח אימייל אישור — בדוק את תיבת הדואר שלך', 'success');
    } else {
      const { data, error } = await _sb.auth.signInWithPassword({ email, password: pass });
      if (error) throw error;
      await _onAuthSuccess(data.user);
    }
  } catch (e) {
    const msg = e.message || '';
    let friendly = 'שגיאה — נסה שוב';
    if (msg.includes('Invalid login credentials') || msg.includes('invalid_credentials') || msg.includes('Invalid email or password')) friendly = 'אימייל או סיסמה שגויים';
    else if (msg.includes('already registered') || msg.includes('already been registered') || msg.includes('User already registered')) friendly = 'אימייל זה כבר רשום — נסה להתחבר';
    else if (msg.includes('Email not confirmed') || msg.includes('not confirmed')) friendly = 'יש לאשר את האימייל תחילה — בדוק את תיבת הדואר';
    else if (msg.includes('invalid format') || msg.includes('Invalid email')) friendly = 'כתובת אימייל לא תקינה';
    else if (msg.includes('Too many requests') || msg.includes('rate limit')) friendly = 'יותר מדי ניסיונות — המתן דקה ונסה שוב';
    else if (msg.includes('Password') && msg.includes('characters')) friendly = 'הסיסמה חייבת להכיל לפחות 8 תווים';
    else if (msg) friendly = msg;
    _authMsg(friendly, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = _authMode === 'register' ? 'הרשמה' : 'כניסה';
  }
}

async function authGoogle() {
  const { error } = await _sb.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: window.location.origin + window.location.pathname }
  });
  if (error) _authMsg(error.message, 'error');
}

async function authForgotPassword() {
  const email = (document.getElementById('auth-email').value || '').trim();
  if (!email) { _authMsg('הכנס אימייל לשחזור', 'error'); return; }
  const { error } = await _sb.auth.resetPasswordForEmail(email, {
    redirectTo: window.location.origin + window.location.pathname
  });
  if (error) { _authMsg(error.message, 'error'); return; }
  _authMsg('נשלח לינק לאיפוס סיסמה לאימייל', 'success');
}

async function authSignOut() {
  _teardownRealtimeSync();
  await _sb.auth.signOut();
  _currentUser = null;
  document.getElementById('auth-overlay').style.display = 'flex';
  toast('יצאת מהחשבון', 'info');
}

// ─────────────────────────────────────────────
// ONBOARDING WIZARD
// ─────────────────────────────────────────────
function onboardingCheck(userId) {
  if (localStorage.getItem('ob_done_' + userId)) return;
  const el = document.getElementById('ob-overlay');
  el.style.display = 'flex';
  onboardingStep(1);
}

function onboardingStep(n) {
  [1,2,3].forEach(i => {
    document.getElementById('ob-step-' + i).style.display = i === n ? '' : 'none';
    document.getElementById('ob-dot-' + i).style.background = i === n ? 'var(--accent)' : i < n ? 'rgba(79,131,255,0.4)' : 'rgba(148,163,184,0.2)';
  });
}

function onboardingDone() {
  localStorage.setItem('ob_done_' + _currentUser?.id, '1');
  document.getElementById('ob-overlay').style.display = 'none';
}

function onboardingReplay() {
  localStorage.removeItem('ob_done_' + _currentUser?.id);
  const el = document.getElementById('ob-overlay');
  el.style.display = 'flex';
  onboardingStep(1);
}

function onboardingOpenTrade() {
  onboardingDone();
  openModal('stock');
}

function onboardingGoSettings() {
  onboardingDone();
  const settingsBtn = document.querySelector('.tab-btn[aria-label="Settings"]');
  if (settingsBtn) switchTab('ibkr', settingsBtn);
}

const ADMIN_ID = '9f9ffff4-0936-446c-b816-410b50894e8b';

function _timeGreeting() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return 'בוקר טוב';
  if (h >= 12 && h < 17) return 'צהריים טובים';
  if (h >= 17 && h < 22) return 'ערב טוב';
  return 'לילה טוב';
}

// First name as saved in Settings (falls back to the display name's first word,
// then the email handle). Shown in the header in place of the "TJ" mark on mobile.
function _firstName(user) {
  return (user?.user_metadata?.first_name || '').trim()
      || (user?.user_metadata?.full_name || '').trim().split(/\s+/)[0]
      || (user?.email || '').split('@')[0]
      || '';
}
function _setHeaderGreeting(name) {
  const hg = document.getElementById('header-greeting');
  if (hg) hg.textContent = `${_timeGreeting()} ${(name || '').trim()}`.trim();
}

// Block the app until a signed-in user has a first name on record. Covers
// Google sign-ins and any account made before the registration field existed.
function _maybeRequireName(user) {
  const m = user?.user_metadata || {};
  if ((m.first_name && m.first_name.trim()) || (m.full_name && m.full_name.trim())) return;
  const gate = document.getElementById('name-gate');
  if (!gate) return;
  gate.style.display = 'flex';
  setTimeout(() => document.getElementById('name-gate-input')?.focus(), 120);
}
async function nameGateSave() {
  const input = document.getElementById('name-gate-input');
  const msg = document.getElementById('name-gate-msg');
  const first = (input.value || '').trim();
  if (!first) { msg.textContent = 'נא להזין שם פרטי'; msg.style.display = ''; input.focus(); return; }
  try {
    await _sb.auth.updateUser({ data: { first_name: first, full_name: first } });
    if (_currentUser?.user_metadata) { _currentUser.user_metadata.first_name = first; _currentUser.user_metadata.full_name = first; }
    _setHeaderGreeting(first);
    const el = document.getElementById('header-user-name'); if (el) el.textContent = first;
    document.getElementById('name-gate').style.display = 'none';
  } catch {
    msg.textContent = 'שגיאה — נסה שוב'; msg.style.display = '';
  }
}

async function _onAuthSuccess(user) {
  _currentUser = user;
  const _displayName = user.user_metadata?.full_name || user.email?.split('@')[0] || 'Trading Journal';
  _setHeaderGreeting(_firstName(user));
  const _nameEl = document.getElementById('header-user-name');
  if (_nameEl) {
    _nameEl.textContent = _displayName;
    const greetEl = document.getElementById('time-greeting');
    if (greetEl) { greetEl.textContent = _timeGreeting(); setTimeout(() => { greetEl.style.opacity = '1'; }, 600); }
    _nameEl.title = 'לחץ לשינוי שם';
    _nameEl.style.cursor = 'pointer';
    _nameEl.onclick = async () => {
      const n = prompt('שם תצוגה:', _nameEl.textContent);
      if (!n || !n.trim()) return;
      _nameEl.textContent = n.trim();
      await _sb.auth.updateUser({ data: { full_name: n.trim() } });
      _setHeaderGreeting(n.trim().split(/\s+/)[0]);
      toast('שם עודכן ✓', 'success');
    };
  }
  document.getElementById('auth-overlay').style.display = 'none';
  _maybeRequireName(user);
  await Promise.all([loadDB(), loadUserSettings()]);
  _setupRealtimeSync(); // keep every open device in step (computer ⇆ phone)
  loadCryptoSymbolsFromCoinGecko(); // background — don't delay startup or broker sync

  // Show admin-only UI elements
  const isAdmin = user.id === ADMIN_ID;
  const aiKey = document.getElementById('ai-key-section');
  const fhKey = document.getElementById('finnhub-key-section');
  const fhRow = document.getElementById('finnhub-key-row');
  if (aiKey) aiKey.style.display = isAdmin ? '' : 'none';
  if (fhKey) fhKey.style.display = isAdmin ? '' : 'none';
  // Regular users rely on the shared Finnhub key (edge-function secret) — hide the
  // personal-key field from them; data still flows via the fallback shared key.
  if (fhRow) fhRow.style.display = isAdmin ? '' : 'none';
  // The whole Data Sources section is config/status only — nothing for regular
  // users to do (keys are centralized, data loads in the background). Hide it.
  const dataSec = document.getElementById('s-data-sources');
  if (dataSec) dataSec.style.display = isAdmin ? '' : 'none';
  document.querySelectorAll('.ai-tab-btn, .tnav-btn, .tab-btn').forEach(btn => {
    const oc = btn.getAttribute('onclick') || '';
    if (oc.includes("'ai'")) btn.style.display = isAdmin ? '' : 'none';
  });
  // Investments tab is open to all users, but the AI advisor card inside it stays admin-only
  const advCard = document.getElementById('inv-advisor-card');
  if (advCard) advCard.style.display = isAdmin ? '' : 'none';
  const syncBtn = document.getElementById('flex-sync-btn');
  if (syncBtn) syncBtn.style.display = '';
  // Post-load UI setup
  initFilters();
  applyPrivacy();
  renderAuditLog();
  cleanOldDeleted();
  _migrateCommission();
  loadStockSymbols();
  _autoFlexSync();
  _autoBybitSync();
  setInterval(() => { _autoFlexSync(); _autoBybitSync(); }, 30 * 60 * 1000);
  loadFearGreed();
  loadCryptoFearGreed();
  ttLoad(false);
  langInit();
  // Offer localStorage migration on first login
  await offerMigration();
  onboardingCheck(user.id);
  const _activeTabEl = document.querySelector('.tab-content.active');
  if (_activeTabEl) _maybeShowTabIntro(_activeTabEl.id.replace('tab-', ''), _activeTabEl);
  console.log('%c Trading Journal 2.0 ','background:#818cf8;color:#fff;font-weight:700;font-size:13px;border-radius:3px;padding:2px 6px');
  console.log('%cRunning in the browser — treat other users\' data with respect.','color:#8896a8;font-size:11px');
}

// ─────────────────────────────────────────────
// DATA MIGRATION (localStorage → Supabase)
// ─────────────────────────────────────────────
async function offerMigration() {
  const localRaw = localStorage.getItem(KEY);
  if (!localRaw) return;

  let localDb;
  try { localDb = JSON.parse(localRaw); } catch { return; }
  const localTrades = [...(localDb.stocks || []), ...(localDb.crypto || [])].filter(t => !t.deleted);
  if (!localTrades.length) return;

  // Only offer if Supabase has no trades yet
  const { count } = await _sb.from('trades').select('id', { count: 'exact', head: true }).eq('user_id', _currentUser.id);
  if (count > 0) return;

  const ok = confirm(`נמצאו ${localTrades.length} עסקאות מקומיות — להעביר לענן?\n(הנתונים המקומיים יישארו כגיבוי)`);
  if (!ok) return;

  try {
    // Migrate trades in chunks of 100
    const rows = localTrades.map(t => _tradeToRow(t));
    for (let i = 0; i < rows.length; i += 100) {
      const { error } = await _sb.from('trades').insert(rows.slice(i, i + 100));
      if (error) throw error;
    }

    // Migrate missed opportunities
    const localMissed = JSON.parse(localStorage.getItem('tj-missed-v1') || '[]');
    if (localMissed.length) {
      const missedRows = localMissed.map(r => ({
        user_id: _currentUser.id,
        symbol: r.sym,
        date: r.date,
        price: r.price,
        sector: r.sector || '',
        note: r.note || ''
      }));
      await _sb.from('missed_opportunities').insert(missedRows);
    }

    // Migrate plaintext Groq key from localStorage (one-time cleanup)
    const localGroqKey = localStorage.getItem('tj-ai-key');
    if (localGroqKey) {
      if (!_userSettings.groq_api_key) await _saveUserSettings({ groq_api_key: localGroqKey });
      localStorage.removeItem('tj-ai-key');
    }
    localStorage.removeItem('groq-inv-key');

    toast(`✓ ${localTrades.length} עסקאות הועברו לענן`, 'success');
    await loadDB();
  } catch(e) {
    toast('שגיאה בהעברת נתונים: ' + e.message, 'error');
    console.error('[migration]', e);
  }
}

// ─────────────────────────────────────────────
// DATA
// ─────────────────────────────────────────────
const KEY = 'trading-journal-v1';

// ─────────────────────────────────────────────
// SECURITY — XSS Prevention
// ─────────────────────────────────────────────
// esc() — מסנן כל תו HTML מסוכן לפני הכנסה ל-innerHTML
// חובה להשתמש בה על כל טקסט שמגיע מהמשתמש
function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/\//g, '&#x2F;');
}

// sanitizeText() — חותך טקסט ארוך מדי ומנקה תווים בלתי נראים
function sanitizeText(s, maxLen = 500) {
  if (!s) return '';
  return String(s).trim().slice(0, maxLen);
}

// sanitizeNumber() — מוודא שהערך הוא מספר תקין ובטווח הגיוני
function sanitizeNumber(v, min = -1e9, max = 1e9) {
  const n = parseFloat(v);
  if (isNaN(n) || !isFinite(n)) return 0;
  return Math.min(Math.max(n, min), max);
}

// validateTradeSchema() — בודק שאובייקט עסקה שנטען מ-localStorage תקין
function validateTradeSchema(t) {
  if (!t || typeof t !== 'object') return false;
  if (typeof t.id !== 'number') return false;
  if (!['L','S'].includes(t.ls)) return false;
  if (typeof t.symbol !== 'string' || !t.symbol) return false;
  if (typeof t.entryPrice !== 'number' || t.entryPrice < 0) return false;
  if (!Array.isArray(t.t)) t.t = [];
  // נקה שדות טקסט
  t.notes_keep    = sanitizeText(t.notes_keep,    500);
  t.notes_improve = sanitizeText(t.notes_improve, 500);
  t.symbol        = sanitizeText(t.symbol, 20).toUpperCase().replace(/[^A-Z0-9._\-]/g,'');
  return true;
}

const SEED = {
  stocks: [
    {id:1,type:'stock',entryDate:'2025-09-05',ls:'L',symbol:'CONL',entryPrice:33.21,shares:6,stop:28.80,t:[],closeDate:'2025-09-17',closedShares:6,exitPrice:28.80,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:2,type:'stock',entryDate:'2025-09-09',ls:'L',symbol:'SHOP',entryPrice:145.47,shares:6,stop:140.60,t:[],closeDate:'2025-09-17',closedShares:6,exitPrice:146.52,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:3,type:'stock',entryDate:'2025-10-20',ls:'L',symbol:'NEGG',entryPrice:48.87,shares:6,stop:43.93,t:[],closeDate:'2025-10-23',closedShares:6,exitPrice:43.93,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:4,type:'stock',entryDate:'2025-10-09',ls:'L',symbol:'PJT',entryPrice:180.85,shares:7,stop:176.85,t:[],closeDate:'2025-10-17',closedShares:7,exitPrice:185.00,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:5,type:'stock',entryDate:'2025-11-10',ls:'L',symbol:'QS',entryPrice:16.63,shares:14,stop:14.76,t:[],closeDate:'2025-12-11',closedShares:14,exitPrice:7.17,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:6,type:'stock',entryDate:'2025-11-10',ls:'L',symbol:'A',entryPrice:147.13,shares:10,stop:144.32,t:[],closeDate:'2025-11-17',closedShares:10,exitPrice:144.32,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:7,type:'stock',entryDate:'2025-11-12',ls:'L',symbol:'AIR',entryPrice:84.08,shares:14,stop:82.11,t:[],closeDate:'2025-11-13',closedShares:14,exitPrice:82.34,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:8,type:'stock',entryDate:'2025-11-28',ls:'L',symbol:'OPEN',entryPrice:7.95,shares:57,stop:7.42,t:[],closeDate:'2025-11-29',closedShares:57,exitPrice:7.42,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:9,type:'stock',entryDate:'2026-01-02',ls:'L',symbol:'RDDT',entryPrice:233.72,shares:3,stop:227.49,t:[{shares:1,price:262.00}],closeDate:'2026-01-07',closedShares:3,exitPrice:230.00,ecn:0,commission:5.0,notes_keep:'',notes_improve:''},
    {id:10,type:'stock',entryDate:'2026-01-05',ls:'L',symbol:'GROY',entryPrice:4.18,shares:110,stop:3.97,t:[],closeDate:'2026-01-16',closedShares:110,exitPrice:4.95,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:11,type:'stock',entryDate:'2026-01-06',ls:'L',symbol:'TQQQ',entryPrice:54.34,shares:19,stop:53.28,t:[],closeDate:'2026-01-14',closedShares:19,exitPrice:53.29,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:12,type:'stock',entryDate:'2026-01-28',ls:'L',symbol:'JOE',entryPrice:64.79,shares:26,stop:null,t:[],closeDate:'2026-02-06',closedShares:26,exitPrice:66.98,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:13,type:'stock',entryDate:'2026-02-11',ls:'L',symbol:'ANAB',entryPrice:51.46,shares:8,stop:48.14,t:[],closeDate:'2026-02-11',closedShares:8,exitPrice:48.40,ecn:0,commission:2.5,notes_keep:'סטאפ יומי טוב אחלה vcp',notes_improve:'שבועי וחודשי נראה פחות טוב'},
    {id:14,type:'stock',entryDate:'2026-03-18',ls:'L',symbol:'AHR',entryPrice:53.40,shares:27,stop:52.40,t:[],closeDate:'2026-03-19',closedShares:27,exitPrice:52.43,ecn:0,commission:2.5,notes_keep:'',notes_improve:'לא היה טריגר כניסה'},
    {id:15,type:'stock',entryDate:'2026-03-30',ls:'L',symbol:'SOLS',entryPrice:76.75,shares:10,stop:73.29,t:[],closeDate:'2026-04-01',closedShares:10,exitPrice:73.16,ecn:0,commission:2.5,notes_keep:'',notes_improve:'קנה לי במחיר יקר מידי'}
  ],
  crypto: [
    {id:1,type:'crypto',entryDate:'2026-02-17',ls:'L',symbol:'HIPPOUSDT.P',entryPrice:0.3385,shares:7,stop:0.3285,t:[{shares:4,price:0.3580}],closeDate:'2026-02-17',closedShares:3,exitPrice:0.35,ecn:0,commission:5,notes_keep:'',notes_improve:''},
    {id:2,type:'crypto',entryDate:'2026-02-17',ls:'L',symbol:'BEAMUSDT.P',entryPrice:0.007672,shares:6,stop:0.00726,t:[],closeDate:'2026-02-18',closedShares:6,exitPrice:0.007554,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:3,type:'crypto',entryDate:'2026-02-17',ls:'L',symbol:'SOLUSDT.P',entryPrice:209.56,shares:1,stop:204.29,t:[],closeDate:'2026-02-18',closedShares:1,exitPrice:209.56,ecn:0,commission:0,notes_keep:'',notes_improve:''},
    {id:4,type:'crypto',entryDate:'2026-02-20',ls:'L',symbol:'ETHUSDT.P',entryPrice:2780.0,shares:1,stop:2700.0,t:[],closeDate:'2026-02-21',closedShares:1,exitPrice:2750.0,ecn:0,commission:2.5,notes_keep:'',notes_improve:''},
    {id:5,type:'crypto',entryDate:'2026-02-24',ls:'L',symbol:'XRPUSDT.P',entryPrice:2.45,shares:100,stop:2.3,t:[],closeDate:'2026-02-25',closedShares:100,exitPrice:2.52,ecn:0,commission:2.5,notes_keep:'',notes_improve:''}
  ]
};

let db = {stocks:[], crypto:[]};

// ── Supabase row ↔ JS trade object ─────────────────────────────────────────
function _rowToTrade(row) {
  return {
    id:           row.id,
    type:         row.type,
    entryDate:    row.entry_date,
    ls:           row.ls,
    symbol:       row.symbol,
    entryPrice:   row.entry_price,
    shares:       row.shares,
    stop:         row.stop,
    t:            Array.isArray(row.targets) ? row.targets : (row.targets ? JSON.parse(row.targets) : []),
    closeDate:    row.close_date,
    closedShares: row.closed_shares,
    exitPrice:    row.exit_price,
    ecn:          row.ecn,
    commission:   row.commission,
    notes_keep:   row.notes_keep    || '',
    notes_improve:row.notes_improve || '',
    entryReason:  row.entry_reason  || '',
    marketCond:   row.market_cond   || '',
    processScore: row.process_score,
    mood:         row.mood          || '',
    ibkr_id:      row.ibkr_id       || null,
    deleted:      row.deleted       || false,
    deletedAt:    row.deleted_at,
  };
}

function _tradeToRow(trade) {
  return {
    user_id:       _currentUser.id,
    type:          trade.type,
    entry_date:    trade.entryDate,
    ls:            trade.ls,
    symbol:        trade.symbol,
    entry_price:   trade.entryPrice,
    shares:        trade.shares,
    stop:          trade.stop,
    targets:       trade.t || [],
    close_date:    trade.closeDate   || null,
    closed_shares: trade.closedShares|| null,
    exit_price:    trade.exitPrice   || null,
    ecn:           trade.ecn         || 0,
    commission:    trade.commission  || 0,
    notes_keep:    trade.notes_keep  || '',
    notes_improve: trade.notes_improve || '',
    entry_reason:  trade.entryReason || '',
    market_cond:   trade.marketCond  || '',
    process_score: trade.processScore|| null,
    mood:          trade.mood        || '',
    deleted:       trade.deleted     || false,
    deleted_at:    trade.deletedAt   || null,
    // Only set when present so manual-trade inserts work even before the
    // ibkr_id column migration has been applied.
    ...(trade.ibkr_id ? { ibkr_id: trade.ibkr_id } : {}),
  };
}

async function loadDB() {
  if (!_currentUser) { db = JSON.parse(JSON.stringify(SEED)); return; }
  const { data, error } = await _sb.from('trades').select('*')
    .eq('user_id', _currentUser.id)
    .order('entry_date', { ascending: false });
  if (error) { toast('שגיאה בטעינת נתונים — נסה לרענן', 'error'); console.error('[loadDB]', error); return; }
  const all = (data || []).map(_rowToTrade).filter(validateTradeSchema);
  db.stocks  = all.filter(t => t.type === 'stock'  && !t.deleted);
  db.crypto  = all.filter(t => t.type === 'crypto' && !t.deleted);
  // Build a fingerprint set of deleted trades so auto-sync never re-imports them
  db._deletedFingerprints = new Set(
    all.filter(t => t.deleted).map(t =>
      `${t.symbol}||${t.entryDate}||${Math.round((t.entryPrice||0)*1000)}||${Math.round((t.shares||0)*1000)}`
    )
  );
  await _dedupeTrades(); // always keep the journal free of duplicates
  initFilters(); renderOverview(); renderTable('stock');
}

// ── Live cross-device sync (Supabase Realtime) ───────────────────────────
// A change made on one device (add/edit/delete a trade) is pushed to every
// other open session and re-rendered, so the computer and the phone stay in
// step without a manual refresh. Lighter than loadDB(): re-fetches and
// re-renders but keeps the user's current filter and skips the dedupe write
// (so a remote change can't trigger a write→event loop).
let _rtChannel = null;
async function _syncReloadTrades() {
  if (!_currentUser) return;
  const { data, error } = await _sb.from('trades').select('*')
    .eq('user_id', _currentUser.id).order('entry_date', { ascending: false });
  if (error) return;
  const all = (data || []).map(_rowToTrade).filter(validateTradeSchema);
  db.stocks = all.filter(t => t.type === 'stock'  && !t.deleted);
  db.crypto = all.filter(t => t.type === 'crypto' && !t.deleted);
  db._deletedFingerprints = new Set(all.filter(t => t.deleted).map(t =>
    `${t.symbol}||${t.entryDate}||${Math.round((t.entryPrice||0)*1000)}||${Math.round((t.shares||0)*1000)}`));
  renderOverview();
  renderTable('stock');
}
function _teardownRealtimeSync() {
  if (_rtChannel) { try { _sb.removeChannel(_rtChannel); } catch {} _rtChannel = null; }
}
async function _setupRealtimeSync() {
  if (!_currentUser) return;
  _teardownRealtimeSync();
  const uid = _currentUser.id;
  const f = 'user_id=eq.' + uid;
  // Realtime must carry the user's JWT or RLS filters out every change event.
  const token = await _getToken();
  if (token && _sb.realtime?.setAuth) { try { _sb.realtime.setAuth(token); } catch {} }
  const activeTab = () => (document.querySelector('.tab-content.active') || {}).id || '';
  let tt;
  const reloadTrades = () => { clearTimeout(tt); tt = setTimeout(_syncReloadTrades, 400); };
  _rtChannel = _sb.channel('rt-' + uid)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'trades', filter: f }, reloadTrades)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'missed_opportunities', filter: f },
        () => { if (activeTab() === 'tab-missed') missedRender(); })
    .on('postgres_changes', { event: '*', schema: 'public', table: 'investments', filter: f },
        () => { if (activeTab() === 'tab-investments') invInit(); })
    .subscribe();
}

// Remove duplicate trades — runs on every load and after every sync. Only
// removes provably-duplicate rows, never a legitimate unique trade or scale-in:
//   • two trades sharing IBKR's unique tradeID (same execution)
//   • an untagged trade that exactly matches (entry AND exit) a tagged IBKR trade
//     (a leftover from the old buggy import; the tagged one is canonical)
async function _dedupeTrades() {
  if (!_currentUser) return 0;
  const fp = t => [t.symbol, t.entryDate, Math.round((t.entryPrice||0)*1000), Math.round((t.shares||0)*1000),
                   Math.round((t.exitPrice||0)*1000), Math.round((t.closedShares||0)*1000)].join('|');
  const toRemove = [];
  for (const type of ['stock', 'crypto']) {
    const live = (type === 'stock' ? db.stocks : db.crypto).filter(x => !x.deleted);
    const seenId = new Set();      // ibkr_ids already kept
    const taggedFp = new Set();    // full fingerprints of kept tagged trades
    // Process tagged (canonical) trades first so untagged duplicates are the ones removed.
    const ordered = [...live].sort((a, b) => (a.ibkr_id ? 0 : 1) - (b.ibkr_id ? 0 : 1) || ((+a.id || 0) - (+b.id || 0)));
    for (const t of ordered) {
      if (t.ibkr_id) {
        if (seenId.has(t.ibkr_id)) toRemove.push(t);
        else { seenId.add(t.ibkr_id); taggedFp.add(fp(t)); }
      } else if (taggedFp.has(fp(t))) {
        toRemove.push(t); // exact duplicate of a tagged trade
      }
    }
  }
  for (const t of toRemove) {
    t.deleted = true;
    await _sb.from('trades').update({ deleted: true, deleted_at: new Date().toISOString() })
      .eq('id', t.id).eq('user_id', _currentUser.id);
  }
  if (toRemove.length) {
    db.stocks = db.stocks.filter(x => !x.deleted);
    db.crypto = db.crypto.filter(x => !x.deleted);
  }
  return toRemove.length;
}
// ─────────────────────────────────────────────
// CALCULATIONS
// ─────────────────────────────────────────────
function calcPL(tr) {
  let pl = 0;
  const entry = +tr.entryPrice || 0;
  const ls = tr.ls;
  if (tr.t && tr.t.length > 0) {
    for (const tg of tr.t) {
      const s = +tg.shares || 0;
      const p = +tg.price || 0;
      if (s > 0 && p > 0) {
        pl += (ls === 'L' ? p - entry : entry - p) * s;
      }
    }
    const exited = tr.t.reduce((a,tg) => a + (+tg.shares||0), 0);
    const rem = (+tr.closedShares || +tr.shares || 0) - exited;
    const ep = +tr.exitPrice || 0;
    if (rem > 0 && ep > 0) {
      pl += (ls === 'L' ? ep - entry : entry - ep) * rem;
    }
  } else {
    const s = +tr.closedShares || +tr.shares || 0;
    const ep = +tr.exitPrice || 0;
    if (s > 0 && ep > 0) {
      pl = (ls === 'L' ? ep - entry : entry - ep) * s;
    }
  }
  return pl;
}
function calcTotal(tr) { return calcPL(tr) - (+tr.ecn||0) - (+tr.commission||0); }
function calcRisk(tr) { return (+tr.entryPrice||0) * (+tr.shares||0); }
function calcPct(tr) {
  const risk = calcRisk(tr);
  return risk ? (calcTotal(tr) / risk) * 100 : 0;
}

function stats(trades) {
  const total = trades.reduce((s,t) => s+calcTotal(t), 0);
  const wins = trades.filter(t => calcPL(t) > 0);
  const losses = trades.filter(t => calcPL(t) <= 0);
  const wr = trades.length ? wins.length / trades.length * 100 : 0;
  const best = trades.length ? Math.max(...trades.map(t=>calcPL(t))) : 0;
  const worst = trades.length ? Math.min(...trades.map(t=>calcPL(t))) : 0;
  const avg = trades.length ? trades.reduce((s,t)=>s+calcPL(t),0) / trades.length : 0;
  return {total, wins:wins.length, losses:losses.length, wr, best, worst, avg, n:trades.length};
}

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
const MONTHS_HE = ['ינואר','פברואר','מרץ','אפריל','מאי','יוני','יולי','אוגוסט','ספטמבר','אוקטובר','נובמבר','דצמבר'];
const MONTHS_EN = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const MONTHS_SHORT_HE = ['ינו','פבר','מרץ','אפר','מאי','יוני','יולי','אוג','ספט','אוק','נוב','דצ'];
const MONTHS_SHORT_EN = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const MONTHS = MONTHS_HE;
function months() { return _lang === 'he' ? MONTHS_HE : MONTHS_EN; }
function monthsShort() { return _lang === 'he' ? MONTHS_SHORT_HE : MONTHS_SHORT_EN; }

function fmt(n, d=2) {
  if (n === null || n === undefined || isNaN(n)) return '—';
  return (+n).toFixed(d);
}
// fmtPrice — מציג מחיר בלי אפסים מיותרים בסוף (28.8000 → 28.8, 0.0077 → 0.0077)
function fmtPrice(n) {
  if (n === null || n === undefined || isNaN(n) || +n === 0) return '—';
  const v = +n;
  // לקריפטו עם ערכים קטנים מאוד — מציג עד 6 ספרות
  if (v < 0.01) return v.toPrecision(4).replace(/\.?0+$/, '');
  // רגיל — עד 4 ספרות, ללא אפסים מיותרים
  return parseFloat(v.toFixed(4)).toString();
}
function fmtUSD(n) {
  if (isNaN(n)) return '—';
  return (n>=0?'+':'-') + '$' + Math.abs(n).toFixed(2);
}
function fmtPct(n) {
  if (isNaN(n)) return '—';
  return (n>=0?'+':'') + n.toFixed(2) + '%';
}
function clr(v) { return v > 0 ? 'num-green' : v < 0 ? 'num-red' : ''; }
// calcStopRisk — סיכון אמיתי: (מחיר כניסה - סטופ) × מניות
function calcStopRisk(tr) {
  // Risk reference for the R-multiple = the stop. When no stop is set (e.g. broker
  // imports) fall back to the exit price — same formula, exit instead of stop.
  // If neither exists (open position, no stop) R is undefined → return 0 → "—".
  const ref = (+tr.stop) || (+tr.exitPrice) || 0;
  if (!ref) return 0;
  const diff = Math.abs((+tr.entryPrice||0) - ref);
  return diff * (+tr.shares||0);
}
// fmtR — מחשב R-Multiple: כמה כפולות סיכון הרווחנו/הפסדנו
function fmtR(tot, stopRisk) {
  if (!stopRisk || isNaN(stopRisk) || stopRisk === 0) return '<span style="color:var(--text3)">—</span>';
  const r = tot / stopRisk;
  const cls = r > 0 ? 'num-green' : r < 0 ? 'num-red' : '';
  return `<span class="${cls}">${r >= 0 ? '+' : ''}${r.toFixed(2)}R</span>`;
}
function fmtDate(s) {
  if (!s) return '—';
  const d = new Date(s+'T00:00:00');
  return d.toLocaleDateString('he-IL',{day:'2-digit',month:'2-digit',year:'2-digit'});
}

function filterTrades(type, month, year) {
  let active;
  if (type === 'stock' && _tradesScope !== 'stock') {
    if (_tradesScope === 'all') {
      active = [
        ...db.stocks.filter(x=>!x.deleted).map(x=>({...x,_tt:'stock'})),
        ...db.crypto.filter(x=>!x.deleted).map(x=>({...x,_tt:'crypto'}))
      ];
    } else {
      active = db.crypto.filter(x=>!x.deleted).map(x=>({...x,_tt:'crypto'}));
    }
  } else {
    active = (type==='stock' ? db.stocks : db.crypto).filter(t=>!t.deleted);
  }
  if (!month && !year) return active;
  return active.filter(t => {
    const d = new Date(t.entryDate+'T00:00:00');
    return (!month || d.getMonth()+1 === +month) && (!year || d.getFullYear() === +year);
  });
}

// ─────────────────────────────────────────────
// FILTERS INIT
// ─────────────────────────────────────────────
function initFilters() {
  const curYear = new Date().getFullYear();
  const years = new Set();
  [...db.stocks,...db.crypto].forEach(t => {
    if (t.entryDate) years.add(new Date(t.entryDate+'T00:00:00').getFullYear());
  });
  years.add(curYear); // always include current year so filter works even with no trades yet
  const yrs = [...years].sort((a,b)=>b-a);

  ['ov','st','cr','stats'].forEach(p => {
    const ms = document.getElementById(p+'-month');
    const ys = document.getElementById(p+'-year');
    if (!ms) return;
    ms.innerHTML = `<option value="">${t('filter_all_months')}</option>` + months().map((m,i)=>`<option value="${i+1}">${m}</option>`).join('');
    if (ys) ys.innerHTML = `<option value="">${t('filter_all_years')}</option>` + yrs.map(y=>`<option value="${y}">${y}</option>`).join('');
    if (p === 'ov') {
      ms.value = new Date().getMonth() + 1;
      if (ys) ys.value = new Date().getFullYear();
      updatePeriodLabel('ov');
    } else if (p === 'stats') {
      updatePeriodLabel('stats');
    } else if (p === 'st') {
      if (ys) ys.value = curYear;
      _pdYear[p] = curYear;
      updatePeriodLabel(p);
    }
  });
}

function getFilter(p) {
  return {
    month: (document.getElementById(p+'-month')||{}).value || '',
    year:  (document.getElementById(p+'-year')||{}).value  || ''
  };
}

function resetFilter(p) {
  const ms = document.getElementById(p+'-month');
  const ys = document.getElementById(p+'-year');
  if (ms) ms.value = '';
  if (ys) ys.value = '';
  updatePeriodLabel(p);
  if (p==='st') renderTable('stock');
  else if (p==='cr') renderTable('crypto');
  else if (p==='stats') renderStatistics();
  else renderOverview();
}

// ─────────────────────────────────────────────
// TAB SWITCHING
// ─────────────────────────────────────────────
let ovScope = 'stock';
let _tradesScope = 'stock';
function _setTradesScope(s) { _tradesScope = s; renderTable('stock'); }

function switchTab(name, btn) {
  if (name === 'ai' && _currentUser?.id !== ADMIN_ID) return;
  try { localStorage.setItem('tj_active_tab', name); } catch {}
  document.querySelectorAll('.tab-btn,.tnav-btn').forEach(b=>{ b.classList.remove('active'); b.style.color=''; });
  document.querySelectorAll('.tab-content').forEach(c=>c.classList.remove('active'));
  btn.classList.add('active');
  const tabEl = document.getElementById('tab-'+name);
  tabEl.classList.add('active');
  tabEl.classList.remove('tab-entering');
  void tabEl.offsetWidth;
  tabEl.classList.add('tab-entering');
  if (name==='overview') renderOverview();
  else if (_ovLiveTimer) { clearInterval(_ovLiveTimer); _ovLiveTimer = null; }
  if (name !== 'investments' && _invPriceTimer) { clearInterval(_invPriceTimer); _invPriceTimer = null; }
  if (name==='stocks') renderTable('stock');
  if (name==='crypto') renderTable('crypto');
  if (name==='archive') renderArchive();
  if (name==='statistics') renderStatistics();
  if (name==='themes') { ttLoad(true); ttStartTimer(); } else { ttStopTimer(); }
  if (name==='ibkr') {
    flexInit();
    bybitInit();
    renderSecurityStatus();
    profileLoad();
  }
  if (name==='ai') {
    // Key is pre-filled by loadUserSettings() on login — nothing to do here
  }
  if (name==='missed') missedRender();
  if (name==='investments') invInit();
  _syncMobileNav(name);
  _maybeShowTabIntro(name, tabEl);
}

// Mobile bottom-nav: route a tap to the real sidebar tab button (keeps the
// drawer's highlight in sync too), then highlight the matching bar item.
function mNav(name) {
  const btn = document.querySelector(`.tab-btn[onclick*="switchTab('${name}'"]`)
           || document.querySelector(`.tnav-btn[onclick*="switchTab('${name}'"]`);
  if (btn) switchTab(name, btn);
}
function _syncMobileNav(name) {
  document.querySelectorAll('.mnav-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
}

// ── First-visit tab intros ───────────────────────
// A short "what is this tab for" banner shown once per tab, per user.
const _tabIntros = {
  overview:    { he: { t: 'סקירה כללית', d: 'מבט-על על הביצועים שלך: רווח/הפסד כולל, פוזיציות פתוחות בזמן אמת, אחוז הצלחה, וגרף מצטבר. אפשר לסנן לפי תקופה ולעבור בין מניות/קריפטו.' },
                 en: { t: 'Overview', d: 'A snapshot of your performance: total P&L, live open positions, win rate and a cumulative chart. Filter by period and switch between stocks and crypto.' } },
  stocks:      { he: { t: 'יומן העסקאות', d: 'כל העסקאות שלך — מסונכרנות מהברוקר או נוספות ידנית בכפתור "הוסף עסקה". לחיצה על שורה פותחת פירוט מלא, אפשר לחפש לפי סימבול ולסנן לפי תקופה.' },
                 en: { t: 'Trade journal', d: 'All your trades — synced from your broker or added manually with "Add Trade". Click a row for full detail, search by symbol and filter by period.' } },
  statistics:  { he: { t: 'סטטיסטיקה', d: 'ניתוח עומק של הביצועים: אחוז הצלחה, יחס רווח/סיכון (R), רצפי ניצחון/הפסד וגרפים. אפשר לסנן לפי scope ותקופה.' },
                 en: { t: 'Statistics', d: 'Deep performance analysis: win rate, risk/reward (R), win/loss streaks and charts. Filter by scope and period.' } },
  themes:      { he: { t: 'דופק השוק', d: 'ביצועי סקטורים בזמן אמת. לחיצה על סקטור מציגה את המניות המובילות בו, עם בחירת תקופה (היום/שבוע/חודש).' },
                 en: { t: 'Market Pulse', d: 'Live sector performance. Click a sector to see its leading stocks, with a period selector (today/week/month).' } },
  missed:      { he: { t: 'הזדמנויות שהוחמצו', d: 'תיעוד מניות שפספסת — מתי, באיזה מחיר ולמה. כלי ללמידה כדי לזהות דפוסים ולא לחזור על אותן החמצות.' },
                 en: { t: 'Missed opportunities', d: 'Log trades you missed — when, at what price and why. A learning tool to spot patterns and avoid repeating them.' } },
  investments: { he: { t: 'תיק השקעות', d: 'התיק ארוך-הטווח שלך: אחזקות, הקצאה מול יעד, מזומן פנוי והפקדות חודשיות. המחירים והרווח מתעדכנים חי.' },
                 en: { t: 'Investments', d: 'Your long-term portfolio: holdings, allocation vs target, free cash and monthly deposits. Prices and P&L update live.' } },
  ibkr:        { he: { t: 'הגדרות', d: 'ניהול החשבון והאבטחה (PIN / 2FA / סיסמה), חיבור הברוקר לסנכרון אוטומטי, ויצוא הנתונים שלך ל-CSV.' },
                 en: { t: 'Settings', d: 'Manage your account and security (PIN / 2FA / password), connect your broker for auto-sync, and export your data to CSV.' } },
};
function _maybeShowTabIntro(name, tabEl) {
  if (!tabEl || !_currentUser) return;
  if (_userSettings.tab_intros_dismissed) return;
  try { if (localStorage.getItem('ob_done_' + _currentUser.id)) return; } catch {}
  const intro = _tabIntros[name];
  if (!intro) return;
  const key = 'tj_intro_' + _currentUser.id + '_' + name;
  try { if (localStorage.getItem(key)) return; } catch {}
  if (tabEl.querySelector('.tab-intro')) return;
  const c = _lang === 'he' ? intro.he : intro.en;
  const el = document.createElement('div');
  el.className = 'tab-intro';
  el.innerHTML = `<div class="tab-intro-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.2 1 2h6c0-.8.4-1.5 1-2A7 7 0 0 0 12 2z"/></svg></div>
    <div class="tab-intro-body"><div class="tab-intro-title">${esc(c.t)}</div><div class="tab-intro-text">${esc(c.d)}</div></div>
    <button class="tab-intro-dismiss" onclick="_dismissTabIntro(this)">${_lang === 'he' ? 'הבנתי' : 'Got it'}</button>`;
  tabEl.insertBefore(el, tabEl.firstChild);
  try { localStorage.setItem(key, '1'); } catch {}
}
function _dismissTabIntro(btn) {
  const el = btn.closest('.tab-intro');
  if (!el) return;
  el.style.maxHeight = el.offsetHeight + 'px';
  requestAnimationFrame(() => { el.style.maxHeight = '0'; el.style.opacity = '0'; el.style.marginBottom = '0'; el.style.paddingTop = '0'; el.style.paddingBottom = '0'; });
  setTimeout(() => el.remove(), 280);
  _userSettings.tab_intros_dismissed = true;
  _saveUserSettings({ tab_intros_dismissed: true });
}

// Restore the tab the user last viewed (set in switchTab). Falls back to the
// default overview when nothing is saved or the target isn't navigable here.
function _restoreLastTab() {
  let name; try { name = localStorage.getItem('tj_active_tab'); } catch {}
  if (!name || name === 'overview') return;
  const tabEl = document.getElementById('tab-' + name);
  if (!tabEl) return;
  const btn = Array.from(document.querySelectorAll('.tnav-btn,.tab-btn')).find(b =>
    (b.getAttribute('onclick') || '').includes(`switchTab('${name}'`) && b.offsetParent !== null);
  if (btn) switchTab(name, btn);
}

// ─── Command palette (⌘/Ctrl-K) ──────────────────
function _navTo(name) {
  const btn = Array.from(document.querySelectorAll('.tnav-btn,.tab-btn')).find(b =>
    (b.getAttribute('onclick') || '').includes(`switchTab('${name}'`) && b.offsetParent !== null)
    || document.querySelector('.tnav-btn:last-child');
  if (btn) switchTab(name, btn);
}
function _cmdkActions() {
  const admin = _currentUser?.id === ADMIN_ID;
  const a = [
    { ic:'🏠', label:'מעבר: סקירה', kw:'home overview סקירה דשבורד בית', run:()=>_navTo('overview') },
    { ic:'📈', label:'מעבר: עסקאות', kw:'stocks trades מניות עסקאות טבלה יומן', run:()=>_navTo('stocks') },
    { ic:'📊', label:'מעבר: סטטיסטיקה', kw:'statistics stats סטטיסטיקה ביצועים', run:()=>_navTo('statistics') },
    { ic:'🌡️', label:'מעבר: Market Pulse', kw:'market pulse themes שוק מגמות', run:()=>_navTo('themes') },
    { ic:'🎯', label:'מעבר: Missed', kw:'missed החמצות פספוס', run:()=>_navTo('missed') },
    { ic:'⚙️', label:'הגדרות / חיבור ברוקר', kw:'settings broker ibkr הגדרות ברוקר חיבור', run:()=>_navTo('ibkr') },
    { ic:'➕', label:'עסקה חדשה — מניה', kw:'add new trade stock עסקה חדשה מניה', run:()=>openModal('stock') },
    { ic:'➕', label:'עסקה חדשה — קריפטו', kw:'add new trade crypto עסקה חדשה קריפטו', run:()=>openModal('crypto') },
    { ic:'🔄', label:'סנכרן ברוקר עכשיו', kw:'sync broker ibkr סנכרן עדכן', run:()=>{ _navTo('ibkr'); setTimeout(()=>document.getElementById('flex-sync-btn')?.click(), 250); } },
    { ic:'🔒', label:'מצב פרטיות', kw:'privacy hide פרטיות הסתר מספרים', run:()=>togglePrivacy() },
    { ic:'🎨', label:'החלף ערכת נושא', kw:'theme dark light ערכת נושא צבע', run:()=>toggleTheme() },
  ];
  a.push({ ic:'💼', label:'מעבר: Investments', kw:'investments תיק השקעות', run:()=>_navTo('investments') });
  if (admin) {
    a.splice(5, 0, { ic:'🧠', label:'מעבר: Minervini', kw:'minervini ai מינרביני', run:()=>_navTo('ai') });
  }
  return a;
}
let _cmdkIdx = 0, _cmdkList = [];
function cmdkToggle() {
  const o = document.getElementById('cmdk');
  if (o.classList.contains('open')) cmdkClose(); else cmdkOpen();
}
function cmdkOpen() {
  document.getElementById('cmdk').classList.add('open');
  const inp = document.getElementById('cmdk-input');
  inp.value = ''; cmdkFilter('');
  setTimeout(() => inp.focus(), 20);
}
function cmdkClose() { document.getElementById('cmdk').classList.remove('open'); }
function cmdkFilter(q) {
  q = (q || '').trim().toLowerCase();
  const all = _cmdkActions();
  _cmdkList = q ? all.filter(a => (a.label + ' ' + a.kw).toLowerCase().includes(q)) : all;
  _cmdkIdx = 0; cmdkRender();
}
function cmdkRender() {
  const ul = document.getElementById('cmdk-list');
  ul.innerHTML = _cmdkList.length
    ? _cmdkList.map((a, i) => `<div class="cmdk-item${i === _cmdkIdx ? ' sel' : ''}" onmousemove="_cmdkHover(${i})" onclick="_cmdkRun(${i})"><span class="cmdk-ic">${a.ic}</span><span>${esc(a.label)}</span></div>`).join('')
    : `<div class="cmdk-empty">אין תוצאות</div>`;
}
function _cmdkHover(i) { if (i !== _cmdkIdx) { _cmdkIdx = i; cmdkRender(); } }
function _cmdkRun(i) { const a = _cmdkList[i]; if (!a) return; cmdkClose(); a.run(); }
function _cmdkScroll() { document.querySelector('#cmdk-list .cmdk-item.sel')?.scrollIntoView({ block: 'nearest' }); }
function _cmdkKey(e) {
  if (e.key === 'ArrowDown') { e.preventDefault(); _cmdkIdx = Math.min(_cmdkIdx + 1, _cmdkList.length - 1); cmdkRender(); _cmdkScroll(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); _cmdkIdx = Math.max(_cmdkIdx - 1, 0); cmdkRender(); _cmdkScroll(); }
  else if (e.key === 'Enter') { e.preventDefault(); _cmdkRun(_cmdkIdx); }
  else if (e.key === 'Escape') { e.preventDefault(); cmdkClose(); }
}
document.addEventListener('keydown', e => {
  if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); cmdkToggle(); return; }
  if (e.metaKey || e.ctrlKey || e.altKey) return;
  const ae = document.activeElement, tag = ae?.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || ae?.isContentEditable) return;
  if (_topOpenModal() || document.getElementById('cmdk')?.classList.contains('open')) return;
  if (e.key === '/') { const s = document.getElementById('st-search'); if (s && s.offsetParent) { e.preventDefault(); s.focus(); } }
  else if (e.key === 'n' || e.key === 'N') { e.preventDefault(); openModal('stock'); }
});

// ─── Shared dropdown helpers ─────────────────────
function _closeAllDDs() {
  document.querySelectorAll('.scope-dd.open').forEach(d => d.classList.remove('open'));
  document.querySelectorAll('.dd-open').forEach(m => m.classList.remove('dd-open'));
}
function _openMenu(triggerBtn, menu) {
  _closeAllDDs();
  const rect = triggerBtn.getBoundingClientRect();
  // Render off-screen first to measure dimensions
  menu.style.left = '-9999px';
  menu.style.top  = '-9999px';
  menu.classList.add('dd-open');
  const mw = menu.offsetWidth;
  const mh = menu.offsetHeight;
  // Align right edge of menu to right edge of button (RTL-natural)
  let left = rect.right - mw;
  if (left < 8) left = 8;
  if (left + mw > window.innerWidth - 8) left = window.innerWidth - mw - 8;
  // Open downward, flip upward if not enough space
  let top = rect.bottom + 5;
  if (top + mh > window.innerHeight - 8) top = rect.top - mh - 5;
  menu.style.left = left + 'px';
  menu.style.top  = top  + 'px';
  triggerBtn.closest('.scope-dd').classList.add('open');
}
document.addEventListener('click', function(e) {
  if (!e.target.closest('.scope-dd') && !e.target.closest('.scope-dd-menu') && !e.target.closest('.period-dd-menu'))
    _closeAllDDs();
});
// Move menus to body so they escape any parent overflow/stacking context
document.addEventListener('DOMContentLoaded', function() {
  ['ov-scope-menu','stats-scope-menu'].forEach(id => {
    const el = document.getElementById(id);
    if (el) document.body.appendChild(el);
  });
});

// ─── Scope dropdown ──────────────────────────────
const _scopeLabels = { stock: '📈 מניות', crypto: '₿ קריפטו', all: 'הכל' };

function toggleScopeDD(id) {
  const dd = document.getElementById(id);
  const btn = dd.querySelector('.scope-dd-btn');
  const menuId = id.replace('-dd', '-menu');
  const menu = document.getElementById(menuId);
  if (menu.classList.contains('dd-open')) { _closeAllDDs(); return; }
  _openMenu(btn, menu);
}

function setOvScope(s, btn, ddId) {
  ovScope = s;
  document.getElementById('ov-scope-lbl').textContent = _scopeLabels[s];
  document.querySelectorAll('#ov-scope-menu button').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  _closeAllDDs();
  renderOverview();
}

let statsScope = 'stock';
let _statsInitialized = false;

function _saveStatsState() {
  const ms = document.getElementById('stats-month');
  const ys = document.getElementById('stats-year');
  localStorage.setItem('stats_state_v1', JSON.stringify({
    scope: statsScope,
    month: ms?.value || '',
    year:  ys?.value  || ''
  }));
}

function _restoreStatsState() {
  if (_statsInitialized) return;
  _statsInitialized = true;
  try {
    const raw = localStorage.getItem('stats_state_v1');
    if (!raw) return;
    const s = JSON.parse(raw);
    if (s.scope && _scopeLabels[s.scope]) {
      statsScope = s.scope;
      const lbl = document.getElementById('stats-scope-lbl');
      if (lbl) lbl.textContent = _scopeLabels[s.scope];
      document.querySelectorAll('#stats-scope-menu button').forEach(b => {
        b.classList.toggle('active', b.getAttribute('onclick')?.includes(`'${s.scope}'`));
      });
    }
    const ms = document.getElementById('stats-month');
    const ys = document.getElementById('stats-year');
    if (ms && s.month) ms.value = s.month;
    if (ys && s.year)  ys.value = s.year;
    if (s.month || s.year) {
      _pdYear['stats'] = s.year ? +s.year : new Date().getFullYear();
      updatePeriodLabel('stats');
    }
  } catch(e) {}
}

function setStatsScope(s, btn, ddId) {
  statsScope = s;
  document.getElementById('stats-scope-lbl').textContent = _scopeLabels[s];
  document.querySelectorAll('#stats-scope-menu button').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  _closeAllDDs();
  _saveStatsState();
  renderStatistics();
}

// ─── Period dropdown ──────────────────────────────
const _pdYear = {};
let _pdMenuEl = null;

function _getPdMenu() {
  if (!_pdMenuEl) {
    _pdMenuEl = document.createElement('div');
    _pdMenuEl.className = 'period-dd-menu';
    _pdMenuEl.id = '_pd_menu';
    document.body.appendChild(_pdMenuEl);
  }
  return _pdMenuEl;
}

function _buildPeriodHTML(prefix, showYears) {
  const ms = document.getElementById(prefix+'-month');
  const ys = document.getElementById(prefix+'-year');
  const selMonth = ms ? +ms.value : 0;
  const selYear  = ys ? +ys.value  : 0;
  const yr = _pdYear[prefix] || new Date().getFullYear();
  const yOpts = ys ? [...ys.options].map(o=>+o.value).filter(v=>v) : [new Date().getFullYear()];
  const isAll = !ms?.value && !ys?.value;

  if (showYears) {
    const yearBtns = yOpts.map(y =>
      `<button class="pd-month-btn${y===selYear?' active':''}" onclick="event.stopPropagation();_pdPickYear('${prefix}',${y})">${y}</button>`
    ).join('');
    return `
      <button class="pd-all-btn${isAll?' active':''}" onclick="_resetPeriod('${prefix}')">כל הזמן</button>
      <button class="pd-year-btn active" onclick="event.stopPropagation();_pdToggleYears('${prefix}',false)">${yr}</button>
      <div class="pd-years">${yearBtns}</div>`;
  }

  const monthBtns = MONTHS_SHORT_HE.map((m,i) => {
    const mn = i+1;
    const active = mn===selMonth && yr===selYear ? ' active':'';
    return `<button class="pd-month-btn${active}" onclick="_setPeriod('${prefix}',${mn},${yr})">${m}</button>`;
  }).join('');

  const wholeYearActive = !selMonth && selYear===yr ? ' active':'';
  return `
    <button class="pd-all-btn${isAll?' active':''}" onclick="_resetPeriod('${prefix}')">כל הזמן</button>
    <button class="pd-year-btn" onclick="event.stopPropagation();_pdToggleYears('${prefix}',true)">${yr}</button>
    <button class="pd-all-btn${wholeYearActive}" onclick="_setYearOnly('${prefix}',${yr})">כל ${yr}</button>
    <div class="pd-months">${monthBtns}</div>`;
}

function togglePeriodDD(prefix) {
  const dd = document.getElementById(prefix+'-period-dd');
  const btn = dd.querySelector('.scope-dd-btn');
  const menu = _getPdMenu();
  menu._prefix = prefix;
  if (menu.classList.contains('dd-open') && menu._prefix === prefix) { _closeAllDDs(); return; }
  if (!_pdYear[prefix]) _pdYear[prefix] = +(document.getElementById(prefix+'-year')?.value) || new Date().getFullYear();
  menu.innerHTML = _buildPeriodHTML(prefix, false);
  _openMenu(btn, menu);
}

function _pdToggleYears(prefix, show) {
  _getPdMenu().innerHTML = _buildPeriodHTML(prefix, show);
}

function _pdPickYear(prefix, year) {
  _pdYear[prefix] = year;
  _getPdMenu().innerHTML = _buildPeriodHTML(prefix, false);
}

function _setPeriod(prefix, month, year) {
  const ms = document.getElementById(prefix+'-month');
  const ys = document.getElementById(prefix+'-year');
  if (ms) ms.value = month;
  if (ys) ys.value = year;
  _pdYear[prefix] = year;
  document.getElementById(prefix+'-period-lbl').textContent = MONTHS_SHORT_HE[month-1]+' '+year;
  _closeAllDDs();
  if (prefix==='ov') renderOverview();
  else if (prefix==='st') renderTable('stock');
  else { _saveStatsState(); renderStatistics(); }
}

// Filter by a whole year (no specific month).
function _setYearOnly(prefix, year) {
  const ms = document.getElementById(prefix+'-month');
  const ys = document.getElementById(prefix+'-year');
  if (ms) ms.value = '';
  if (ys) ys.value = year;
  _pdYear[prefix] = year;
  document.getElementById(prefix+'-period-lbl').textContent = String(year);
  _closeAllDDs();
  if (prefix==='ov') renderOverview();
  else if (prefix==='st') renderTable('stock');
  else { _saveStatsState(); renderStatistics(); }
}

function _resetPeriod(prefix) {
  const ms = document.getElementById(prefix+'-month');
  const ys = document.getElementById(prefix+'-year');
  if (ms) ms.value = '';
  if (ys) ys.value = '';
  document.getElementById(prefix+'-period-lbl').textContent = 'כל הזמן';
  _closeAllDDs();
  if (prefix==='ov') renderOverview();
  else if (prefix==='st') renderTable('stock');
  else { _saveStatsState(); renderStatistics(); }
}

function updatePeriodLabel(prefix) {
  const ms = document.getElementById(prefix+'-month');
  const ys = document.getElementById(prefix+'-year');
  const lbl = document.getElementById(prefix+'-period-lbl');
  if (!lbl) return;
  const m = ms?.value, y = ys?.value;
  lbl.textContent = (m||y) ? ((m?MONTHS_SHORT_HE[+m-1]:'')+(y?' '+y:'')).trim() : 'כל הזמן';
}

// ─────────────────────────────────────────────
// TRADES TABLE
// ─────────────────────────────────────────────
const expanded = {};
const sortState = { stock: { col: 'entryDate', dir: -1 }, crypto: { col: 'entryDate', dir: -1 } };
const searchQuery = { stock: '', crypto: '' };
// IDs present in the last render of each type — used to flash genuinely-new rows
// (broker sync / manual add). null on first render so nothing flashes on initial load.
const _prevTradeIds = { stock: null, crypto: null };

function sortTable(type, col) {
  const s = sortState[type];
  if (s.col === col) s.dir *= -1;
  else { s.col = col; s.dir = -1; }
  renderTable(type);
}

function applySort(trades, type) {
  const { col, dir } = sortState[type];
  return [...trades].sort((a, b) => {
    let va, vb;
    if (col === 'total')    { va = calcTotal(a);    vb = calcTotal(b); }
    else if (col === 'pct') { va = calcPct(a);      vb = calcPct(b); }
    else if (col === 'r')   { const ra = calcStopRisk(a), rb = calcStopRisk(b); va = ra ? calcTotal(a)/ra : -Infinity; vb = rb ? calcTotal(b)/rb : -Infinity; }
    else if (col === 'symbol')    { return dir * a.symbol.localeCompare(b.symbol); }
    else if (col === 'entryDate') { return dir * (new Date(b.entryDate) - new Date(a.entryDate)) * -1; }
    else { va = a[col] || 0; vb = b[col] || 0; }
    return dir * (va - vb);
  });
}

function applySearch(trades, type) {
  const q = searchQuery[type].trim().toLowerCase();
  if (!q) return trades;
  return trades.filter(t => t.symbol.toLowerCase().includes(q));
}

function tradeSector(tr) {
  const raw = (tr.symbol || '').toUpperCase().replace(/USDT\.P|USDT|\.P$/,'');
  const sec = SECTOR_MAP[raw];
  if (!sec) return `<span class="sector-cell" data-sym="${raw}" style="color:var(--text3)">—</span>`;
  return `<span class="sector-cell" style="color:var(--text2);font-size:12px">${esc(sec)}</span>`;
}

function tradeStatus(tr) {
  const closed = +tr.closedShares || 0;
  const total  = +tr.shares || 0;
  if (tr.exitPrice && closed >= total && total > 0) return '<span class="status-badge closed">סגור</span>';
  if (tr.exitPrice || tr.closeDate)                 return '<span class="status-badge partial">חלקי</span>';
  return '<span class="status-badge open">פתוח</span>';
}

function thSort(type, col, label, currentCol, currentDir) {
  const active = currentCol === col;
  const cls = active ? (currentDir === 1 ? 'sort-asc' : 'sort-desc') : '';
  const arrow = active
    ? (currentDir === 1
        ? `<svg width="8" height="8" viewBox="0 0 8 8" style="margin-right:4px;vertical-align:middle;opacity:1;color:var(--accent)" fill="currentColor"><path d="M4 1L7 6H1z"/></svg>`
        : `<svg width="8" height="8" viewBox="0 0 8 8" style="margin-right:4px;vertical-align:middle;opacity:1;color:var(--accent)" fill="currentColor"><path d="M4 7L1 2H7z"/></svg>`)
    : `<svg width="8" height="8" viewBox="0 0 8 8" style="margin-right:4px;vertical-align:middle;opacity:0.25" fill="currentColor"><path d="M4 1L6.5 4H1.5z"/><path d="M4 7L1.5 4H6.5z"/></svg>`;
  return `<th class="sortable ${cls}" onclick="sortTable('${type}','${col}')">${label}${arrow}</th>`;
}

// ─────────────────────────────────────────────
// CALENDAR VIEW
// ─────────────────────────────────────────────
const tableViewMode = { stock: 'table', crypto: 'table' };
const calendarNav   = { stock: null, crypto: null, overview: null };
let _ovLiveTimer = null;
const CAL_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`;
const TBL_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="3" cy="6" r="0.5" fill="currentColor"/><circle cx="3" cy="12" r="0.5" fill="currentColor"/><circle cx="3" cy="18" r="0.5" fill="currentColor"/></svg>`;

function toggleTableView(type) {
  tableViewMode[type] = tableViewMode[type] === 'table' ? 'calendar' : 'table';
  if (tableViewMode[type] === 'table') { calendarNav[type] = null; renderTable(type); return; }
  if (tableViewMode[type] === 'calendar' && !calendarNav[type]) {
    const p = type === 'stock' ? 'st' : 'cr';
    const f = getFilter(p);
    if (f.month && f.year) {
      calendarNav[type] = { year: +f.year, month: +f.month };
    } else {
      const arr = (type === 'stock' ? db.stocks : db.crypto).filter(t => !t.deleted && t.entryDate);
      const pool = f.year ? arr.filter(t => t.entryDate.startsWith(f.year)) : arr;
      if (pool.length) {
        const latest = pool.reduce((b, t) => t.entryDate > b.entryDate ? t : b);
        const d = new Date(latest.entryDate + 'T00:00:00');
        calendarNav[type] = { year: d.getFullYear(), month: d.getMonth() + 1 };
      } else {
        const now = new Date();
        calendarNav[type] = { year: f.year ? +f.year : now.getFullYear(), month: now.getMonth() + 1 };
      }
    }
  }
  renderTable(type);
}
function calNavPrev(type) {
  const n = calendarNav[type];
  calendarNav[type] = n.month === 1 ? { year: n.year-1, month: 12 } : { year: n.year, month: n.month-1 };
  if (type === 'overview') _ovGoToMonth(); else renderTable(type);
}
function calNavNext(type) {
  const n = calendarNav[type];
  calendarNav[type] = n.month === 12 ? { year: n.year+1, month: 1 } : { year: n.year, month: n.month+1 };
  if (type === 'overview') _ovGoToMonth(); else renderTable(type);
}
// Overview calendar nav drives the period filter so KPIs, chart and calendar all move together.
function _ovGoToMonth() {
  const { month, year } = calendarNav.overview;
  const ys = document.getElementById('ov-year');
  if (ys && ![...ys.options].some(o => +o.value === year)) {
    const opt = document.createElement('option');
    opt.value = year; opt.textContent = year;
    ys.appendChild(opt);
  }
  _setPeriod('ov', month, year);
}

function renderCalendar(type) {
  const isAll = type === 'all';
  const navType = isAll ? 'overview' : type;
  const p    = isAll ? 'ov' : (type === 'stock' ? 'st' : 'cr');
  const wrap = document.getElementById(isAll ? 'ov-calendar' : (type === 'stock' ? 'stocks-wrap' : 'crypto-wrap'));
  if (!calendarNav[navType]) {
    const f = getFilter(p), now = new Date();
    calendarNav[navType] = { year: f.year?+f.year:now.getFullYear(), month: f.month?+f.month:now.getMonth()+1 };
  }
  const { year, month } = calendarNav[navType];
  const arr = isAll
    ? (ovScope === 'stock' ? db.stocks : ovScope === 'crypto' ? db.crypto : [...db.stocks, ...db.crypto]).filter(t => !t.deleted)
    : (type === 'stock' ? db.stocks : db.crypto).filter(t => !t.deleted);

  // Group trades by day
  const byDay = {};
  arr.forEach(t => {
    if (!t.entryDate) return;
    const d = new Date(t.entryDate+'T00:00:00');
    if (d.getFullYear() === year && d.getMonth()+1 === month) {
      const key = t.entryDate.slice(0,10);
      if (!byDay[key]) byDay[key] = [];
      byDay[key].push(t);
    }
  });

  const allMonthTrades = Object.values(byDay).flat();
  const monthTotal = allMonthTrades.reduce((s,t) => s+calcTotal(t), 0);
  const totalStyle = monthTotal > 0 ? 'color:var(--green)' : monthTotal < 0 ? 'color:var(--red)' : 'color:var(--text2)';
  const daysInMonth = new Date(year, month, 0).getDate();
  const startDow    = new Date(year, month-1, 1).getDay(); // 0=Sun
  const todayObj    = new Date();
  const todayStr    = `${todayObj.getFullYear()}-${String(todayObj.getMonth()+1).padStart(2,'0')}-${String(todayObj.getDate()).padStart(2,'0')}`;

  // Build cell array (null = empty, number = day)
  const cells = Array(startDow).fill(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);

  // In RTL grid: HTML order = [Sun, Mon, Tue, Wed, Thu, Fri, Sat, WeekSum]
  // grid-template-columns: repeat(7,1fr) 110px → WeekSum is leftmost in RTL
  const DAY_HDRS_HE = ['ראשון','שני','שלישי','רביעי','חמישי','שישי','שבת','סיכום שבועי'];
  const DAY_HDRS_EN = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat','Weekly Sum'];
  const DAY_HDRS_ORDER = _lang === 'he' ? DAY_HDRS_HE : DAY_HDRS_EN;

  const winsCount  = allMonthTrades.filter(t => calcPL(t) > 0).length;
  const lossCount  = allMonthTrades.length - winsCount;

  const _isLight = document.documentElement.getAttribute('data-theme') === 'light';
  if (_isLight) {
    wrap.style.setProperty('background', '#ffffff', 'important');
    wrap.style.setProperty('border-color', '#e2e8f0', 'important');
  } else {
    wrap.style.removeProperty('background');
    wrap.style.removeProperty('border-color');
  }
  const _calBg = _isLight ? 'style="background:#ffffff !important;"' : '';

  let html = `<div class="cal-wrap" ${_calBg}>
  <div class="cal-header" ${_calBg}>
    <button class="cal-nav-btn" onclick="calNavPrev('${navType}')" title="חודש קודם"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg></button>
    <div class="cal-title">
      <span class="cal-title-month">${months()[month-1]} ${year}</span>
      ${allMonthTrades.length ? `<span class="cal-divider"></span>
      <span class="cal-summary sensitive" style="${totalStyle}">${fmtUSD(monthTotal)}</span>
      <span class="cal-divider"></span>
      <span class="cal-trade-count">${allMonthTrades.length} ${t('trades')} · ${winsCount}W / ${lossCount}L</span>` : `<span class="cal-trade-count cal-no-trades">${t('cal_no_trades')}</span>`}
    </div>
    <button class="cal-nav-btn" onclick="calNavNext('${navType}')" title="חודש הבא"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg></button>
  </div>
  <div class="cal-grid">`;

  // Header row — days first, week-sum last (RTL: WeekSum appears leftmost)
  DAY_HDRS_ORDER.forEach((h,i) => {
    const isLast = i === DAY_HDRS_ORDER.length - 1;
    html += `<div class="cal-day-hdr${isLast?' hdr-week':''}">${h}</div>`;
  });

  // Weeks — day cells first (Sun→Sat), then WeekSum last
  const numWeeks = cells.length / 7;
  for (let w = 0; w < numWeeks; w++) {
    const weekDays = cells.slice(w*7, w*7+7);

    // Day cells Sun(0)→Sat(6)
    weekDays.forEach((day, colIdx) => {
      const isWeekend = colIdx === 5 || colIdx === 6; // Fri=5, Sat=6
      if (day === null) {
        html += `<div class="cal-empty${isWeekend?' weekend':''}"></div>`;
      } else {
        const ds = `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
        const dt = byDay[ds] || [];
        const dayTotal = dt.reduce((s,t) => s+calcTotal(t), 0);
        const isToday  = ds === todayStr;
        const cls = [
          'cal-cell',
          dt.length ? 'has-trades' : '',
          isWeekend   ? 'weekend'    : '',
          isToday     ? 'today'      : ''
        ].filter(Boolean).join(' ');
        const dtStyle = dayTotal >= 0 ? 'color:var(--green)' : 'color:var(--red)';
        const plStr1 = dt.length === 1 ? fmtUSD(calcTotal(dt[0])) : '';
        html += `<div class="${cls}" ${dt.length > 1 ? `onclick="showCalDayModal('${ds}')" style="cursor:pointer"` : ''}>
          <div class="cal-date">${day}</div>
          ${dt.length === 1 ? `<div class="cal-chip ${calcPL(dt[0])>=0?'win':'loss'}" onclick="event.stopPropagation();showCalTradeModal('${dt[0].type}','${dt[0].id}')">
              <span class="cal-chip-sym">${esc(dt[0].symbol)}</span>
              <span class="cal-chip-pl sensitive">${plStr1}</span>
            </div>` : ''}
          ${dt.length > 1 ? `<div class="cal-multi-badge sensitive" style="${dtStyle}">
              <span class="cal-multi-count">${dt.length}</span>
              <span class="cal-multi-pl">${fmtUSD(dayTotal)}</span>
            </div>` : ''}
        </div>`;
      }
    });

    // Weekly summary cell — rendered last = leftmost column in RTL
    const wTrades = weekDays.filter(Boolean).flatMap(d => {
      const ds = `${year}-${String(month).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
      return byDay[ds] || [];
    });
    const wTotal = wTrades.reduce((s,t) => s+calcTotal(t), 0);
    if (wTrades.length) {
      const wCls = wTotal >= 0 ? 'color:var(--green)' : 'color:var(--red)';
      html += `<div class="cal-week-sum">
        <span class="cal-week-pl sensitive" style="${wCls}">${fmtUSD(wTotal)}</span>
        <span class="cal-week-count">${wTrades.length} ${t('trades')}</span>
      </div>`;
    } else {
      html += `<div class="cal-week-sum"><span class="cal-week-empty">—</span></div>`;
    }
  }

  html += `</div></div>`;
  wrap.innerHTML = html;
}

// Builds the expandable detail row for a trade. Pure given `tr` — used both by
// the full renderTable and by the partial toggleTradeRow (no full re-render).
function _expandedRowHTML(tr, key) {
  const tot   = calcTotal(tr);
  const risk  = calcRisk(tr);
  const pct   = calcPct(tr);
  const stopR = calcStopRisk(tr);
  const rVal  = stopR ? tot / stopR : null;
  const stopDist = tr.entryPrice && tr.stop
    ? Math.abs((tr.entryPrice - tr.stop) / tr.entryPrice * 100)
    : null;
  const commission = +(tr.commission || 0);
  const isWin = tot > 0;

  const tile = (label, val, col) =>
    `<div class="tr-tile">
      <div class="tr-tile-val" style="color:${col||'var(--text)'}">${val}</div>
      <div class="tr-tile-label">${label}</div>
    </div>`;

  const tgtsHtml = tr.t && tr.t.length
    ? tr.t.map((tg,i)=>`<span class="tr-target-pill"><strong>T${i+1}</strong> ${tg.shares} @ $${fmtPrice(tg.price)}</span>`).join('')
    : `<span style="color:var(--text3);font-size:12px;">${t('tile_no_targets')}</span>`;

  const mcLabel = {'green':t('mc_green'),'orange':t('mc_orange'),'red':t('mc_red'),'easy':t('mc_easy'),'hard':t('mc_hard'),'up':t('mc_up'),'press':t('mc_press'),'down':t('mc_down')};
  const mcSafe = Object.prototype.hasOwnProperty.call(mcLabel, tr.market_cond) ? tr.market_cond : '';

  const noteKeep = tr.notes_keep
    ? `<div class="tr-note tr-note-keep"><div class="tr-note-label">${t('tile_keep')}</div><div class="tr-note-text">${esc(tr.notes_keep)}</div></div>` : '';
  const noteImp = tr.notes_improve
    ? `<div class="tr-note tr-note-imp"><div class="tr-note-label">${t('tile_improve')}</div><div class="tr-note-text">${esc(tr.notes_improve)}</div></div>` : '';
  const noNotes = !tr.notes_keep && !tr.notes_improve
    ? `<span style="color:var(--text3);font-size:12px;">${t('tile_no_notes')}</span>` : '';

  return `<tr class="expanded-row" data-expkey="${key}">
    <td colspan="20">
      <div class="tr-review">

        <!-- Metric tiles -->
        <div class="tr-tiles">
          ${tile(t('tile_net_pl'), `<span class="sensitive">${fmtUSD(tot)}</span>`, tot>=0?'var(--green)':'var(--red)')}
          ${tile(t('tile_return'), `<span class="sensitive">${fmtPct(pct)}</span>`, pct>=0?'var(--green)':'var(--red)')}
          ${tile(t('tile_r_mult'), rVal!==null ? fmtR(tot,stopR) : '—', rVal===null?'var(--text3)':rVal>=1?'var(--green)':rVal>=0?'var(--yellow)':'var(--red)')}
          ${tile(t('tile_risk'), risk>0?`<span class="sensitive">${fmtUSD(risk)}</span>`:'—', 'var(--text)')}
          ${tile(t('tile_stop_dist'), stopDist!==null?`${fmt(stopDist,1)}%`:'—', 'var(--text)')}
          ${tile(t('tile_commission'), `<span class="sensitive">$${fmt(commission)}</span>`, 'var(--text3)')}
        </div>

        <!-- Price flow -->
        <div class="tr-flow-row">
          <div class="tr-flow-block">
            <div class="tr-flow-label">${t('tile_entry')}</div>
            <div class="tr-flow-price sensitive">$${fmtPrice(tr.entryPrice)}</div>
            <div class="tr-flow-sub">${fmtDate(tr.entryDate)}</div>
          </div>
          <div class="tr-flow-arrow">→</div>
          <div class="tr-flow-block">
            <div class="tr-flow-label">${t('tile_stop')}</div>
            <div class="tr-flow-price sensitive" style="color:var(--red)">$${fmtPrice(tr.stop)}</div>
            <div class="tr-flow-sub">${stopDist!==null?fmt(stopDist,1)+'% '+t('tile_from_entry'):''}</div>
          </div>
          <div class="tr-flow-arrow">→</div>
          <div class="tr-flow-block">
            <div class="tr-flow-label">${t('tile_exit')}</div>
            <div class="tr-flow-price sensitive" style="color:${isWin?'var(--green)':'var(--red)'}">$${fmtPrice(tr.exitPrice||tr.entryPrice)}</div>
            <div class="tr-flow-sub">${tr.closeDate?fmtDate(tr.closeDate):''}</div>
          </div>
          ${tr.t&&tr.t.length?`<div class="tr-flow-arrow" style="color:var(--text3)">|</div>
          <div class="tr-flow-block">
            <div class="tr-flow-label">${t('tile_partial_tgt')}</div>
            <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:4px">${tgtsHtml}</div>
          </div>`:''}
          ${mcSafe?`<div class="tr-flow-arrow" style="color:var(--text3)">|</div>
          <div class="tr-flow-block">
            <div class="tr-flow-label">${t('tile_market_cond')}</div>
            <div class="tr-flow-price" style="font-size:13px;color:var(--text2)">${mcLabel[mcSafe]}</div>
          </div>`:''}
        </div>

        <!-- Notes -->
        ${noteKeep||noteImp||noNotes?`<div class="tr-notes-row">${noteKeep}${noteImp}${noNotes}</div>`:''}

      </div>
    </td>
  </tr>`;
}

function renderTable(type) {
  if (type === 'stock') {
    const pillsEl = document.getElementById('trades-scope-pills');
    if (pillsEl) {
      const opts = [
        { key:'stock',  label: t('comp_stocks')?.replace(/^[^\s]+\s/,'') || 'מניות' },
        { key:'crypto', label: t('comp_crypto')?.replace(/^[^\s]+\s/,'') || 'קריפטו' },
      ];
      pillsEl.innerHTML = opts.map(o =>
        `<button class="comp-scope-pill${o.key===_tradesScope?' active':''}" onclick="_setTradesScope('${o.key}')">${o.label}</button>`
      ).join('');
    }
  }
  const p = type==='stock' ? 'st' : 'cr';
  const wrap = document.getElementById(type==='stock' ? 'stocks-wrap' : 'crypto-wrap');

  // Update toggle button icon
  const toggleBtn = document.getElementById(p+'-view-toggle');
  if (toggleBtn) {
    const isCalMode = tableViewMode[type] === 'calendar';
    toggleBtn.innerHTML = isCalMode ? TBL_ICON + ' ' + t('view_table') : CAL_ICON + ' ' + t('view_calendar');
  }

  // Calendar mode
  if (tableViewMode[type] === 'calendar') { renderCalendar(type); return; }

  const {month, year} = getFilter(p);
  let trades = filterTrades(type, month, year);
  trades = applySearch(trades, type);
  trades = applySort(trades, type);
  const { col: sc, dir: sd } = sortState[type];

  // stats bar
  const st = stats(trades);
  const el = document.getElementById(p+'-stats');
  if (el) {
    const totalColor = st.total >= 0 ? 'var(--green)' : 'var(--red)';
    el.innerHTML = `${trades.length} trades &nbsp;|&nbsp; P&amp;L: <strong style="color:${totalColor}">${fmtUSD(st.total)}</strong> &nbsp;|&nbsp; Win: <strong>${fmt(st.wr,1)}%</strong> &nbsp;|&nbsp; ${st.wins}W / ${st.losses}L`;
  }

  // info
  const info = document.getElementById(p+'-filter-info');
  if (info) info.textContent = (month||year) ? `${month ? months()[+month-1] : ''} ${year||''}`.trim() : '';

  if (!trades.length) {
    const _emptyIcon = type==='stock'
      ? `<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>`
      : `<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M9.5 9a3 3 0 0 1 5 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>`;
    const dbArr = type === 'stock' ? db.stocks : db.crypto;
    const isFirstUse = dbArr.filter(tr => !tr.deleted).length === 0;
    wrap.innerHTML = isFirstUse
      ? `<div class="empty-state">
           <div class="empty-icon">${_emptyIcon}</div>
           <p style="font-size:15px;font-weight:600;color:var(--text);margin-bottom:0">${type === 'stock' ? 'עדיין אין עסקאות מניות' : 'עדיין אין עסקאות קריפטו'}</p>
           <p style="font-size:13px;margin-top:8px;max-width:260px">תעד את הפוזיציה הראשונה שלך ותתחיל לעקוב אחרי הביצועים</p>
           <button onclick="openModal('${type}')" style="margin-top:20px;padding:9px 22px;background:var(--accent);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit;transition:opacity .15s;" onmouseenter="this.style.opacity='.85'" onmouseleave="this.style.opacity='1'">+ הוסף עסקה ראשונה</button>
         </div>`
      : `<div class="empty-state"><div class="empty-icon">${_emptyIcon}</div><p>${t('no_trades')}</p>
           <button onclick="resetFilter('${p}')" style="margin-top:16px;padding:8px 18px;background:transparent;color:var(--accent);border:1px solid var(--accent);border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;" onmouseenter="this.style.background='var(--accent)';this.style.color='#fff'" onmouseleave="this.style.background='transparent';this.style.color='var(--accent)'">${_lang==='he'?'נקה סינון':'Clear filter'}</button>
         </div>`;
    return;
  }

  let h = `<table><colgroup>
    <col style="width:44px"><col style="width:110px"><col style="width:54px">
    <col style="width:90px"><col style="width:110px">
    <col style="width:90px"><col style="width:90px"><col style="width:80px">
    <col style="width:80px"><col style="width:70px"><col style="width:110px">
    <col style="width:100px"><col style="width:90px"><col style="width:70px">
    <col style="width:80px"><col style="width:90px"><col style="width:70px">
    <col style="width:60px"><col style="min-width:100px">
  </colgroup><thead><tr>
    <th>#</th>
    ${thSort(type,'entryDate',t('col_entry_date'),sc,sd)}
    <th>L/S</th>
    <th>${t('col_status')}</th>
    <th>${t('col_reason')}</th>
    ${thSort(type,'symbol',t('col_symbol'),sc,sd)}
    <th>${t('col_entry')}</th>
    <th>${t('col_shares')}</th>
    <th>${t('col_stop')}</th>
    <th>${t('col_targets')}</th>
    <th>${t('col_close_date')}</th>
    <th>${t('col_closed_shares')}</th>
    <th>${t('col_exit')}</th>
    <th>${t('col_sector')}</th>
    <th>${t('col_commission')}</th>
    <th class="calc-cell">${thSort(type,'total',t('col_total'),sc,sd).replace('<th','<span').replace('</th>','</span>')}</th>
    <th class="calc-cell">${thSort(type,'pct','%',sc,sd).replace('<th','<span').replace('</th>','</span>')}</th>
    <th class="calc-cell">${thSort(type,'r','R',sc,sd).replace('<th','<span').replace('</th>','</span>')}</th>
    <th>${t('col_actions')}</th>
  </tr></thead><tbody>`;

  // Pre-compute per-year stats when no year filter (for group headers)
  let yearStatsMap = {};
  if (!year) {
    trades.forEach(tr => {
      const y = tr.entryDate ? tr.entryDate.slice(0,4) : '—';
      if (!yearStatsMap[y]) yearStatsMap[y] = [];
      yearStatsMap[y].push(tr);
    });
  }
  let lastRenderedYear = null;

  // Build per-year sequential trade numbers based on chronological entry date
  // Use all trades of this type (not just filtered) for accurate year numbering
  const allOfType = type === 'stock' ? db.stocks : db.crypto;
  const _fullIds = new Set(allOfType.filter(t => !t.deleted).map(t => t.id));
  const _prevIds = _prevTradeIds[type];
  const yearTradeNum = {};
  [...allOfType]
    .filter(t => !t.deleted)
    .sort((a, b) => (a.entryDate || '').localeCompare(b.entryDate || ''))
    .forEach(t => {
      const y = t.entryDate ? t.entryDate.slice(0, 4) : '—';
      if (!yearTradeNum[y]) yearTradeNum[y] = { next: 1 };
      yearTradeNum[y][t.id] = yearTradeNum[y].next++;
    });

  trades.forEach(tr => {
    // Year group header when no year filter is active
    if (!year) {
      const trYear = tr.entryDate ? tr.entryDate.slice(0,4) : '—';
      if (trYear !== lastRenderedYear) {
        lastRenderedYear = trYear;
        const yst = stats(yearStatsMap[trYear]);
        const ytc = yst.total >= 0 ? 'var(--green)' : 'var(--red)';
        h += `<tr class="year-group-row"><td colspan="20">
          <span class="year-group-label">📅 ${trYear}</span>
          <span class="year-group-stats">${yearStatsMap[trYear].length} ${t('trades')} &nbsp;|&nbsp; P&L: <strong style="color:${ytc}">${fmtUSD(yst.total)}</strong> &nbsp;|&nbsp; Win: <strong>${fmt(yst.wr,1)}%</strong> &nbsp;|&nbsp; ${yst.wins}W / ${yst.losses}L</span>
        </td></tr>`;
      }
    }

    const pl = calcPL(tr);
    const tot = calcTotal(tr);
    const risk = calcRisk(tr);
    const pct = calcPct(tr);
    const rowCls = tot > 0 ? 'profit' : tot < 0 ? 'loss' : '';
    const key = type+'-'+tr.id;
    const isExp = expanded[key];

    const trYear = tr.entryDate ? tr.entryDate.slice(0,4) : '—';
    const trNum = yearTradeNum[trYear]?.[tr.id] ?? '—';
    const _flash = _prevIds && !_prevIds.has(tr.id) ? ' row-flash' : '';
    h += `<tr class="data-row ${rowCls}${_flash}" data-rowkey="${key}" onclick="toggleTradeRow('${type}',${tr.id})">
      <td style="color:var(--text);font-size:12px;font-weight:600;">${trNum}</td>
      <td>${fmtDate(tr.entryDate)}</td>
      <td><span class="badge badge-${tr.ls}">${tr.ls}</span></td>
      <td>${tradeStatus(tr)}</td>
      <td>${erBadge(tr.entry_reason)}</td>
      <td><strong>${esc(tr.symbol)}</strong></td>
      <td class="sensitive">$${fmtPrice(tr.entryPrice)}</td>
      <td>${tr.shares}</td>
      <td class="sensitive">$${fmtPrice(tr.stop)}</td>
      <td>${tr.t&&tr.t.length ? `<span style="color:var(--purple);font-weight:700;">T${tr.t.length}</span>` : '<span style="color:var(--text3)">—</span>'}</td>
      <td>${fmtDate(tr.closeDate)}</td>
      <td>${tr.closedShares||'—'}</td>
      <td class="sensitive">$${fmtPrice(tr.exitPrice)}</td>
      <td>${tradeSector(tr)}</td>
      <td class="sensitive">$${fmt(tr.commission)}</td>
      <td class="calc-cell"><span class="${clr(tot)} sensitive">${fmtUSD(tot)}</span></td>
      <td class="calc-cell"><span class="${clr(pct)} sensitive">${fmtPct(pct)}</span></td>
      <td class="calc-cell sensitive">${fmtR(tot,calcStopRisk(tr))}</td>
      <td onclick="event.stopPropagation()">
        <div style="display:flex;gap:5px;align-items:center;">
          <button class="btn-icon" title="ערוך" onclick="editTrade('${tr._tt||type}','${tr.id}')" aria-label="ערוך עסקה"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>
          <button class="btn-icon danger" title="מחק" onclick="deleteTrade('${tr._tt||type}','${tr.id}')" aria-label="מחק עסקה"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg></button>
          <button class="btn-camera" id="cam-btn-${key}" title="צילומי מסך" onclick="openSSModal('${key}','${esc(tr.symbol)}')" aria-label="צילומי מסך"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg><span class="screenshot-badge" id="ss-count-${key}" style="display:none">0</span></button>
        </div>
      </td>
    </tr>`;

    if (isExp) h += _expandedRowHTML(tr, key);
  });

  h += '</tbody></table>';
  _prevTradeIds[type] = _fullIds;
  wrap.innerHTML = h;
  wrap.querySelectorAll('tr.data-row').forEach((row, i) => {
    row.style.setProperty('--i', Math.min(i, 14));
    row.classList.add('animate-in');
  });
  // Load screenshot counts for each trade row
  trades.forEach(tr => {
    const key = type+'-'+tr.id;
    refreshScreenshotCount(key);
  });

  // Recycle bin hidden — deleted trades are excluded from view

  applyPrivacy();
  _fillMissingSectors(type);
}

const _sectorCache = {};
// Persist sector holdings across reloads so re-opening a sector is instant
// (stale-while-revalidate): show the saved data immediately, refresh in the bg.
const _SECTOR_LS = 'sector_cache_v1';
function _sectorLoadLS() {
  try { return JSON.parse(localStorage.getItem(_SECTOR_LS) || '{}'); } catch { return {}; }
}
function _sectorSaveLS(ticker, holdings) {
  try {
    const all = _sectorLoadLS();
    all[ticker] = { ts: Date.now(), holdings };
    localStorage.setItem(_SECTOR_LS, JSON.stringify(all));
  } catch (e) {}
}
async function _fillMissingSectors(type) {
  const tabEl = document.getElementById('tab-'+(type==='stock'?'stocks':'crypto'));
  if (!tabEl) return;
  const cells = tabEl.querySelectorAll('.sector-cell[data-sym]');
  const seen = new Set();
  for (const cell of cells) {
    const sym = cell.dataset.sym;
    if (!sym || seen.has(sym)) { if (seen.has(sym) && _sectorCache[sym]) cell.textContent = _sectorCache[sym]; continue; }
    seen.add(sym);
    if (_sectorCache[sym]) { cell.textContent = _sectorCache[sym]; cell.style.color = 'var(--text2)'; cell.removeAttribute('data-sym'); continue; }
    try {
      const token = await _getToken();
      if (!token) break;
      const res = await fetch(`${SUPABASE_URL}/functions/v1/finnhub?path=stock%2Fprofile2&symbol=${encodeURIComponent(sym)}`,
        { headers: { 'Authorization': `Bearer ${token}` } });
      const d = await res.json();
      const sec = d.finnhubIndustry || '';
      if (sec) {
        _sectorCache[sym] = sec;
        tabEl.querySelectorAll(`.sector-cell[data-sym="${sym}"]`).forEach(el => {
          el.textContent = sec; el.style.color = 'var(--text2)'; el.removeAttribute('data-sym');
        });
      }
    } catch { /* silent */ }
  }
}

function toggleTradeRow(type, id) {
  const key = type+'-'+id;
  const wasOpen = !!expanded[key];
  expanded[key] = !wasOpen;

  // Partial DOM update — avoid rebuilding the whole table (and re-running
  // entrance animations / screenshot-count fetches) just to open one row.
  const rowEl = document.querySelector(`tr.data-row[data-rowkey="${key}"]`);
  if (!rowEl) { renderTable(type); return; }

  if (wasOpen) {
    const exp = rowEl.nextElementSibling;
    if (exp && exp.classList.contains('expanded-row') && exp.dataset.expkey === key) exp.remove();
    return;
  }

  const tr = (type === 'stock' ? db.stocks : db.crypto).find(t => t.id == id && !t.deleted);
  if (!tr) { renderTable(type); return; }
  const tmp = document.createElement('tbody');
  tmp.innerHTML = _expandedRowHTML(tr, key);
  const expRow = tmp.firstElementChild;
  rowEl.after(expRow);
  applyPrivacy();
}

function showCalDayModal(ds) {
  const all = [...db.stocks, ...db.crypto].filter(t => !t.deleted && t.entryDate?.slice(0,10) === ds);
  if (!all.length) return;
  const dayTotal = all.reduce((s,t) => s+calcTotal(t), 0);
  const dtStyle = dayTotal >= 0 ? 'color:var(--green)' : 'color:var(--red)';
  const [y,mo,d] = ds.split('-');
  const title = `${+d}/${+mo}/${y}`;
  document.getElementById('cal-trade-modal-title').textContent = `${title} · ${all.length} ${t('trades')} · <span style="${dtStyle}">${fmtUSD(dayTotal)}</span>`;
  document.getElementById('cal-trade-modal-title').innerHTML = `${title} &nbsp;·&nbsp; ${all.length} ${t('trades')} &nbsp;·&nbsp; <span style="${dtStyle}">${fmtUSD(dayTotal)}</span>`;
  document.getElementById('cal-trade-modal-body').innerHTML = all.map(tr => {
    const pl = calcTotal(tr); const pct = calcPct(tr);
    const plStyle = pl >= 0 ? 'color:var(--green)' : 'color:var(--red)';
    return `<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);cursor:pointer;" onclick="closeCalTradeModal();setTimeout(()=>showCalTradeModal('${tr.type}','${tr.id}'),120)">
      <div style="display:flex;align-items:center;gap:10px;">
        <span style="font-size:14px;font-weight:700;color:var(--text)">${esc(tr.symbol)}</span>
        <span style="font-size:11px;color:var(--text3)">${tr.ls === 'L' ? 'Long' : 'Short'}</span>
      </div>
      <div style="text-align:left;">
        <div class="sensitive" style="font-size:14px;font-weight:700;${plStyle}">${(pl>=0?'+':'')+fmtUSD(pl)}</div>
        ${pct !== null ? `<div class="sensitive" style="font-size:11px;color:var(--text3)">${(pct>=0?'+':'')+pct.toFixed(2)}%</div>` : ''}
      </div>
    </div>`;
  }).join('');
  document.getElementById('cal-trade-modal').classList.add('open');
}

function showCalTradeModal(type, id) {
  const arr = type === 'stock' ? db.stocks : db.crypto;
  const tr = arr.find(x => String(x.id) === String(id));
  if (!tr) return;

  const tot   = calcTotal(tr);
  const risk  = calcRisk(tr);
  const pct   = calcPct(tr);
  const stopR = calcStopRisk(tr);
  const rVal  = stopR ? tot / stopR : null;
  const stopDist = tr.entryPrice && tr.stop
    ? Math.abs((tr.entryPrice - tr.stop) / tr.entryPrice * 100)
    : null;
  const commission = +(tr.commission || 0);
  const isWin = tot > 0;

  const tile = (label, val, col) =>
    `<div class="tr-tile"><div class="tr-tile-val" style="color:${col||'var(--text)'}">${val}</div><div class="tr-tile-label">${label}</div></div>`;

  const tgtsHtml = tr.t && tr.t.length
    ? tr.t.map((tg,i)=>`<span class="tr-target-pill"><strong>T${i+1}</strong> ${tg.shares} @ $${fmtPrice(tg.price)}</span>`).join('')
    : `<span style="color:var(--text3);font-size:12px;">${t('tile_no_targets')}</span>`;

  const mcLabel = {'green':t('mc_green'),'orange':t('mc_orange'),'red':t('mc_red'),'easy':t('mc_easy'),'hard':t('mc_hard'),'up':t('mc_up'),'press':t('mc_press'),'down':t('mc_down')};
  const mcSafe = Object.prototype.hasOwnProperty.call(mcLabel, tr.market_cond) ? tr.market_cond : '';

  const noteKeep = tr.notes_keep
    ? `<div class="tr-note tr-note-keep"><div class="tr-note-label">${t('tile_keep')}</div><div class="tr-note-text">${esc(tr.notes_keep)}</div></div>` : '';
  const noteImp = tr.notes_improve
    ? `<div class="tr-note tr-note-imp"><div class="tr-note-label">${t('tile_improve')}</div><div class="tr-note-text">${esc(tr.notes_improve)}</div></div>` : '';
  const noNotes = !tr.notes_keep && !tr.notes_improve
    ? `<span style="color:var(--text3);font-size:12px;">${t('tile_no_notes')}</span>` : '';

  document.getElementById('cal-trade-modal-title').textContent = `${tr.symbol} · ${fmtDate(tr.entryDate)}`;
  document.getElementById('cal-trade-edit-btn').onclick = () => { closeCalTradeModal(); editTrade(type, id); };
  document.getElementById('cal-trade-modal-body').innerHTML = `<div class="tr-review">
    <div class="tr-tiles">
      ${tile(t('tile_net_pl'), `<span class="sensitive">${fmtUSD(tot)}</span>`, tot>=0?'var(--green)':'var(--red)')}
      ${tile(t('tile_return'), `<span class="sensitive">${fmtPct(pct)}</span>`, pct>=0?'var(--green)':'var(--red)')}
      ${tile(t('tile_r_mult'), rVal!==null ? fmtR(tot,stopR) : '—', rVal===null?'var(--text3)':rVal>=1?'var(--green)':rVal>=0?'var(--yellow)':'var(--red)')}
      ${tile(t('tile_risk'), risk>0?`<span class="sensitive">${fmtUSD(risk)}</span>`:'—', 'var(--text)')}
      ${tile(t('tile_stop_dist'), stopDist!==null?`${fmt(stopDist,1)}%`:'—', 'var(--text)')}
      ${tile(t('tile_commission'), `<span class="sensitive">$${fmt(commission)}</span>`, 'var(--text3)')}
    </div>
    <div class="tr-flow-row">
      <div class="tr-flow-block">
        <div class="tr-flow-label">${t('tile_entry')}</div>
        <div class="tr-flow-price sensitive">$${fmtPrice(tr.entryPrice)}</div>
        <div class="tr-flow-sub">${fmtDate(tr.entryDate)}</div>
      </div>
      <div class="tr-flow-arrow">→</div>
      <div class="tr-flow-block">
        <div class="tr-flow-label">${t('tile_stop')}</div>
        <div class="tr-flow-price sensitive" style="color:var(--red)">$${tr.stop ? fmtPrice(tr.stop) : '—'}</div>
        <div class="tr-flow-sub">${stopDist!==null?fmt(stopDist,1)+'% '+t('tile_from_entry'):''}</div>
      </div>
      <div class="tr-flow-arrow">→</div>
      <div class="tr-flow-block">
        <div class="tr-flow-label">${t('tile_exit')}</div>
        <div class="tr-flow-price sensitive" style="color:${isWin?'var(--green)':'var(--red)'}">$${fmtPrice(tr.exitPrice||tr.entryPrice)}</div>
        <div class="tr-flow-sub">${tr.closeDate?fmtDate(tr.closeDate):''}</div>
      </div>
    </div>
    ${tr.t&&tr.t.length?`<div style="display:flex;flex-wrap:wrap;gap:6px;padding:10px 14px;background:rgba(255,255,255,0.025);border:1px solid rgba(255,255,255,0.06);border-radius:10px;">
      <span style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);width:100%;margin-bottom:4px;">${t('tile_partial_tgt')}</span>
      ${tgtsHtml}
    </div>`:''}
    ${mcSafe?`<div style="padding:10px 14px;background:rgba(255,255,255,0.025);border:1px solid rgba(255,255,255,0.06);border-radius:10px;">
      <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.8px;color:var(--text3);margin-bottom:4px;">${t('tile_market_cond')}</div>
      <div style="font-size:13px;font-weight:600;color:var(--text2)">${mcLabel[mcSafe]}</div>
    </div>`:''}
    ${noteKeep||noteImp||noNotes?`<div class="tr-notes-row">${noteKeep}${noteImp}${noNotes}</div>`:''}
  </div>`;
  document.getElementById('cal-trade-modal').classList.add('open');
  applyPrivacy();
}

function closeCalTradeModal() {
  document.getElementById('cal-trade-modal').classList.remove('open');
}

// ══════════════════════════════════════════════
// ARCHIVE — שנים קודמות
// ══════════════════════════════════════════════
const _ICON_ARCHIVE = `<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></svg>`;
function renderArchive() {
  const wrap = document.getElementById('archive-wrap');
  if (!wrap) return;
  const curYear = new Date().getFullYear();

  // Collect all past-year trades grouped by year
  const byYear = {};
  ['stock','crypto'].forEach(type => {
    const arr = type==='stock' ? db.stocks : db.crypto;
    arr.filter(t => !t.deleted && t.entryDate).forEach(t => {
      const y = +t.entryDate.slice(0,4);
      if (y >= curYear) return; // skip current year
      if (!byYear[y]) byYear[y] = { stock: [], crypto: [] };
      byYear[y][type].push(t);
    });
  });

  const years = Object.keys(byYear).map(Number).sort((a,b)=>b-a);

  if (!years.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="empty-icon">${_ICON_ARCHIVE}</div><p>אין עסקאות בארכיון — כל העסקאות הן משנת ${curYear}</p></div>`;
    return;
  }

  let h = `<div style="padding:4px 0 16px;font-size:12px;color:var(--text3);">ארכיון מכיל עסקאות מלפני שנת ${curYear}. לחץ על שנה לפתיחה.</div>`;

  years.forEach(y => {
    const stTrades = byYear[y].stock;
    const crTrades = byYear[y].crypto;
    const allTrades = [...stTrades, ...crTrades];
    const yst = stats(allTrades);
    const stSt = stats(stTrades);
    const crSt = stats(crTrades);
    const tc = yst.total >= 0 ? 'var(--green)' : 'var(--red)';
    const uid = 'arc-'+y;

    h += `<div class="archive-year-block" id="${uid}-block">
      <div class="archive-year-header" onclick="archiveToggle('${uid}')">
        <span class="archive-year-label">📅 ${y}</span>
        <span class="archive-year-summary">
          ${allTrades.length} עסקאות &nbsp;|&nbsp;
          P&L: <strong style="color:${tc}">${fmtUSD(yst.total)}</strong> &nbsp;|&nbsp;
          Win: <strong>${fmt(yst.wr,1)}%</strong> &nbsp;|&nbsp;
          ${yst.wins}W / ${yst.losses}L
        </span>
        <span class="archive-chevron" id="${uid}-chev">▼</span>
      </div>
      <div class="archive-year-body" id="${uid}-body" style="display:none;">`;

    // Stats cards for the year
    h += `<div class="archive-stats-row">`;
    // Combined
    h += archiveStatCard('סה"כ השנה', fmtUSD(yst.total), tc, allTrades.length+' עסקאות | Win '+fmt(yst.wr,1)+'%');
    if (stTrades.length) h += archiveStatCard('מניות', fmtUSD(stSt.total), stSt.total>=0?'var(--green)':'var(--red)', stTrades.length+' עסקאות | Win '+fmt(stSt.wr,1)+'%');
    if (crTrades.length) h += archiveStatCard('קריפטו', fmtUSD(crSt.total), crSt.total>=0?'var(--green)':'var(--red)', crTrades.length+' עסקאות | Win '+fmt(crSt.wr,1)+'%');
    if (allTrades.length) h += archiveStatCard('עסקה הטובה', fmtUSD(yst.best), 'var(--green)', '');
    if (allTrades.length) h += archiveStatCard('עסקה הגרועה', fmtUSD(yst.worst), 'var(--red)', '');
    h += `</div>`;

    // Stocks table
    if (stTrades.length) {
      h += `<div class="archive-type-label">📋 מניות — ${y}</div>`;
      h += archiveTradeTable(stTrades, 'stock');
    }
    // Crypto table
    if (crTrades.length) {
      h += `<div class="archive-type-label">₿ קריפטו — ${y}</div>`;
      h += archiveTradeTable(crTrades, 'crypto');
    }

    h += `</div></div>`; // body + block
  });

  wrap.innerHTML = h;
}

function archiveStatCard(label, value, color, sub) {
  return `<div class="archive-stat-card">
    <div class="archive-stat-label">${label}</div>
    <div class="archive-stat-value" style="color:${color}">${value}</div>
    ${sub ? `<div class="archive-stat-sub">${sub}</div>` : ''}
  </div>`;
}

function archiveTradeTable(trades, type) {
  const sorted = [...trades].sort((a,b)=> (b.entryDate||'').localeCompare(a.entryDate||''));
  let h = `<div class="table-wrap" style="margin-bottom:16px;"><table><thead><tr>
    <th>#</th><th>תאריך</th><th>L/S</th><th>סטטוס</th><th>סימבול</th>
    <th>כניסה</th><th>מניות</th><th>יציאה</th><th>עמלה</th>
    <th class="calc-cell">סה"כ</th><th class="calc-cell">%</th><th class="calc-cell">R</th>
  </tr></thead><tbody>`;
  sorted.forEach((tr,i) => {
    const tot = calcTotal(tr);
    const pct = calcPct(tr);
    const rowCls = tot > 0 ? 'profit' : tot < 0 ? 'loss' : '';
    h += `<tr class="data-row ${rowCls}">
      <td>${i+1}</td>
      <td>${fmtDate(tr.entryDate)}</td>
      <td><span class="badge badge-${tr.ls}">${tr.ls}</span></td>
      <td>${tradeStatus(tr)}</td>
      <td><strong>${esc(tr.symbol)}</strong></td>
      <td>$${fmtPrice(tr.entryPrice)}</td>
      <td>${tr.shares}</td>
      <td>$${fmtPrice(tr.exitPrice)}</td>
      <td>$${fmt(tr.commission)}</td>
      <td class="calc-cell"><span class="${clr(tot)}">${fmtUSD(tot)}</span></td>
      <td class="calc-cell"><span class="${clr(pct)}">${fmtPct(pct)}</span></td>
      <td class="calc-cell">${fmtR(tot,calcStopRisk(tr))}</td>
    </tr>`;
  });
  h += '</tbody></table></div>';
  return h;
}

function archiveToggle(uid) {
  const body = document.getElementById(uid+'-body');
  const chev = document.getElementById(uid+'-chev');
  if (!body) return;
  const open = body.style.display !== 'none';
  body.style.display = open ? 'none' : 'block';
  if (chev) chev.textContent = open ? '▼' : '▲';
}

function toggleInlineArchive(type) {
  const wrapId = type === 'stock' ? 'st-archive-wrap' : 'cr-archive-wrap';
  const btnId  = type === 'stock' ? 'st-archive-btn'  : 'cr-archive-btn';
  const wrap = document.getElementById(wrapId);
  const btn  = document.getElementById(btnId);
  if (!wrap) { toast('שגיאת מערכת — נסה לרענן את הדף', 'error'); return; }
  const isOpen = wrap.dataset.open === '1';
  if (isOpen) {
    wrap.style.display = 'none';
    wrap.dataset.open = '0';
    if (btn) btn.classList.remove('active');
  } else {
    renderInlineArchive(type);
    wrap.style.display = 'block';
    wrap.dataset.open = '1';
    if (btn) btn.classList.add('active');
    wrap.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

function renderInlineArchive(type) {
  const wrapId = type === 'stock' ? 'st-archive-wrap' : 'cr-archive-wrap';
  const wrap = document.getElementById(wrapId);
  if (!wrap) return;
  const curYear = new Date().getFullYear();
  const arr = type === 'stock' ? db.stocks : db.crypto;

  const byYear = {};
  arr.filter(t => !t.deleted && t.entryDate).forEach(t => {
    const y = +t.entryDate.slice(0, 4);
    if (y >= curYear) return;
    if (!byYear[y]) byYear[y] = [];
    byYear[y].push(t);
  });

  const years = Object.keys(byYear).map(Number).sort((a, b) => b - a);

  if (!years.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="empty-icon">${_ICON_ARCHIVE}</div><p>אין עסקאות בארכיון — כל העסקאות הן משנת ${curYear}</p></div>`;
    return;
  }

  const typeLabel = type === 'stock' ? 'מניות' : 'קריפטו';
  const uidPfx = type === 'stock' ? 'st-arc' : 'cr-arc';
  let h = `<div style="padding:4px 0 16px;font-size:12px;color:var(--text3);">ארכיון ${typeLabel} מכיל עסקאות מלפני שנת ${curYear}. לחץ על שנה לפתיחה.</div>`;

  years.forEach(y => {
    const trades = byYear[y];
    const yst = stats(trades);
    const tc = yst.total >= 0 ? 'var(--green)' : 'var(--red)';
    const uid = uidPfx + '-' + y;

    h += `<div class="archive-year-block" id="${uid}-block">
      <div class="archive-year-header" onclick="archiveToggle('${uid}')">
        <span class="archive-year-label">📅 ${y}</span>
        <span class="archive-year-summary">
          ${trades.length} עסקאות &nbsp;|&nbsp;
          P&L: <strong style="color:${tc}">${fmtUSD(yst.total)}</strong> &nbsp;|&nbsp;
          Win: <strong>${fmt(yst.wr, 1)}%</strong> &nbsp;|&nbsp;
          ${yst.wins}W / ${yst.losses}L
        </span>
        <span class="archive-chevron" id="${uid}-chev">▼</span>
      </div>
      <div class="archive-year-body" id="${uid}-body" style="display:none;">
        <div class="archive-stats-row">`;
    h += archiveStatCard(typeLabel + ' ' + y, fmtUSD(yst.total), tc, trades.length + ' עסקאות | Win ' + fmt(yst.wr, 1) + '%');
    if (trades.length) h += archiveStatCard('עסקה הטובה', fmtUSD(yst.best), 'var(--green)', '');
    if (trades.length) h += archiveStatCard('עסקה הגרועה', fmtUSD(yst.worst), 'var(--red)', '');
    h += `</div>`;
    h += archiveTradeTable(trades, type);
    h += `</div></div>`;
  });

  wrap.innerHTML = h;
}

// ─────────────────────────────────────────────
// OVERVIEW
// ─────────────────────────────────────────────
const charts = {};

// ══════════════════════════════════════════════
// ENTRY REASON HELPERS
// ══════════════════════════════════════════════
const ER_OPTIONS = ['LPS','Low Cheat','Cheat','Handle','Breakout'];
const ER_CLASS   = {'LPS':'lps','Low Cheat':'cheatl','Cheat':'cheath','Handle':'handle','Breakout':'bo'};

function erBadge(er) {
  if (!er) return '<span style="color:var(--text3)">—</span>';
  const cls = ER_CLASS[er] || '';
  return `<span class="er-badge ${cls}">${esc(er)}</span>`;
}

let qaER = '';
function qaSetER(val) {
  qaER = qaER === val ? '' : val; // toggle off on second click
  document.querySelectorAll('#qa-er-pills .er-pill').forEach(p => {
    const base = p.dataset.er;
    p.className = 'er-pill' + (base === qaER ? ' active-' + (ER_CLASS[base]||'') : '');
  });
}

let modalER = '';
function modalSetER(val) {
  modalER = modalER === val ? '' : val;
  document.getElementById('m-entry-reason').value = modalER;
  document.querySelectorAll('#m-er-pills .er-pill').forEach(p => {
    const base = p.dataset.er;
    p.className = 'er-pill' + (base === modalER ? ' active-' + (ER_CLASS[base]||'') : '');
  });
}

function erSetPills(containerId, val) {
  // used when opening modal with existing trade
  document.querySelectorAll('#'+containerId+' .er-pill').forEach(p => {
    const base = p.dataset.er;
    p.className = 'er-pill' + (base === val ? ' active-' + (ER_CLASS[base]||'') : '');
  });
}

// ══════════════════════════════════════════════
// MOOD HELPERS
// ══════════════════════════════════════════════
const MOOD_OPTIONS = ['focused','calm','confident','stressed','impatient','doubtful'];

// ══════════════════════════════════════════════
// MINERVINI — PROCESS SCORE & MARKET CONDITION
// ══════════════════════════════════════════════
let qaPS = 0;
let modalPS = 0;

function psSetStars(containerId, val) {
  document.querySelectorAll('#'+containerId+' span').forEach(s => {
    s.className = parseInt(s.dataset.v) <= val ? 'on' : '';
  });
}

// ══════════════════════════════════════════════
// QUICK ADD WIDGET
// ══════════════════════════════════════════════
let qaLS = 'L';
let qaCollapsed = false; // managed by modal open/close

function qaInit() {
  const today = new Date().toISOString().split('T')[0];
  const el = document.getElementById('qa-date');
  if (el && !el.value) el.value = today;
}

function qaToggle() { fabToggle(); }

function fabToggle() {
  const modal = document.getElementById('qa-modal');
  const isOpen = modal.classList.toggle('open');
  document.getElementById('fab-btn')?.classList.toggle('open', isOpen);
  document.body.style.overflow = isOpen ? 'hidden' : '';
  if (isOpen) {
    const d = document.getElementById('qa-date');
    if (d && !d.value) d.value = new Date().toISOString().split('T')[0];
    setTimeout(() => document.getElementById('qa-symbol')?.focus(), 80);
  }
}

// Known crypto base symbols that would otherwise be mistaken for stocks
const CRYPTO_SYMBOLS = new Set([
  // ── Layer 1 ──
  'BTC','ETH','SOL','XRP','ADA','AVAX','DOT','ATOM','NEAR','APT',
  'SUI','SEI','TON','TIA','INJ','TRX','EOS','XTZ','ALGO','ONE',
  'EGLD','FTM','CELO','KAVA','ROSE','CFX','CORE','HBAR','VET','ICX',
  'IOST','IOTA','NANO','QTUM','WAN','ZEN','ZEC','ZIL','WAVES','LSK',
  'STEEM','ARDR','XEM','NXT','BURST','SC','DCR','DGB','RVN','KMD',
  // ── Layer 2 & Scaling ──
  'OP','ARB','MATIC','IMX','METIS','BOBA','CKB','STRK','MANTA','ZK',
  'ZETA','TAIKO','SCROLL','BASE','BLAST','MODE','MANTLE','LINEA',
  // ── DeFi Blue Chips ──
  'UNI','AAVE','MKR','CRV','CVX','BAL','COMP','SNX','YFI','SUSHI',
  'CAKE','DYDX','GMX','GNS','PERP','PENDLE','RDNT','VELO','AERO',
  'LDO','RPL','FXS','FRAX','LUSD','RAI','VOLT','FOLD','TOKE','KNC',
  'BNT','ZRX','1INCH','COW','PSP','DODO','MDX','EPS','ALPACA',
  // ── Exchange Tokens ──
  'BNB','OKB','HT','KCS','LEO','FTT','CRO','GT','WRX','MEXC',
  // ── Meme Coins ──
  'DOGE','SHIB','PEPE','FLOKI','BONK','WIF','BOME','MYRO','POPCAT',
  'MEW','TURBO','MEME','HIPPO','RATS','SATS','ORDI','NOT','WEN',
  'SLERF','TURT','NEIRO','DOGS','HMSTR','CATI','MOODENG','PNUT',
  'ACT','GOAT','KEKIUS','BRETT','ANDY','GIGA','MOG','APU','CHEEMS',
  // ── AI & Data ──
  'FET','AGIX','OCEAN','CTXC','NMR','GRT','BAND','API3','DIA',
  'RLC','LINK','TRB','UMA','FLUX','AKT','HMT','RNDR','AR','TAO',
  // ── Gaming & Metaverse ──
  'AXS','SAND','MANA','ENJ','GALA','ILV','YGG','MAGIC','TLM','SLP',
  'ALICE','STARL','GHST','ATLAS','POLIS','DEAPL','NAKA','CWAR',
  // ── Infrastructure & Storage ──
  'FIL','AR','STORJ','ROSE','SKL','LRC','OMG','OXT','ANKR','BICO',
  'API3','POKT','HNT','MOBILE','IOT','PRCL','HONEY','WIFI',
  // ── Privacy ──
  'XMR','ZEC','DASH','SCRT','DUSK','NYM','OXEN','RAILGUN',
  // ── Stablecoins & Wrapped ──
  'USDT','USDC','DAI','BUSD','TUSD','PAXG','LUSD','GUSD','FRAX',
  'WBTC','WETH','STETH','RETH','CBETH','BBTC','RENBTC','HBTC',
  // ── BNB Chain Ecosystem ──
  'CAKE','XVS','BSW','BAKE','BURGER','CHESS','DEGO','FOR','LINA',
  'MBOX','MIR','NEXO','ONG','QKC','REEF','SFP','STMX','SXP','TCT',
  'TROY','TWT','UNFI','UTK','VIDT','WING','XNO','BETA','COCOS',
  // ── Cosmos Ecosystem ──
  'OSMO','JUNO','EVMOS','STARS','STRD','UMEE','AXL','MARS','KUJI',
  'SCRT','DVPN','CMDX','HUAHUA','SOMM','NTRN','DYDX','PYTH','JUP',
  // ── Solana Ecosystem ──
  'RAY','SRM','FIDA','MNGO','COPE','TULIP','STEP','ORCA','PORT',
  'SLND','SONAR','MEAN','MEDIA','MIMO','SAMO','CATO','TNSR','JTO',
  'JITO','DRIFT','ZETA','PYUSD','BONK','WIF','JUP','BOME',
  // ── Other Notable ──
  'LTC','BCH','BSV','XLM','VET','THETA','FTM','HBAR','ICP','EGLD',
  'FLOW','NEAR','RUNE','NEXO','CEL','HEX','PLS','PLSX','INC',
  'CHZ','ENS','BLUR','X2Y2','LOOKS','RARE','SUPER','NFTY',
  'GAL','GTC','MASK','DAO','BIT','OX','CYBER','ID','EDU','ACH',
  'AUDIO','SPELL','TRIBE','ALCX','TOKE','BOND','IDLE','ROOK','FOX',
  'TORN','BADGER','DIGG','BOR','MTA','DCHF','OUSD','FRAXBP',
  'NXRA','ATH','ZKJ','ZKSYNC','EIGEN','ETHFI','RENZO','PUFFER',
  'SSV','OBOL','DVT','LSETH','RSETH','EETH','OSETH','WEETH',
]);

// ── CoinGecko live symbol list ─────────────────────────────────
const CGECKO_CACHE_KEY = 'cg-symbols-v1';
const CGECKO_TTL_MS    = 24 * 60 * 60 * 1000; // 24 hours

async function loadCryptoSymbolsFromCoinGecko() {
  // 1. Load from cache immediately for instant availability
  let cachedCount = 0, cachedTs = 0;
  try {
    const raw = localStorage.getItem(CGECKO_CACHE_KEY);
    if (raw) {
      const { ts, symbols } = JSON.parse(raw);
      if (Array.isArray(symbols) && symbols.length) {
        symbols.forEach(s => CRYPTO_SYMBOLS.add(s));
        cachedCount = symbols.length;
        cachedTs = ts;
        updateCryptoStatus('cache', cachedCount, cachedTs);
      }
    }
  } catch(e) {}

  // 2. Always fetch fresh on every session (background). CoinGecko's free API
  //    throttles server IPs intermittently, so retry a few times with backoff.
  updateCryptoStatus('loading', cachedCount, cachedTs);
  const DELAYS = [0, 2000, 5000];
  for (let i = 0; i < DELAYS.length; i++) {
    if (DELAYS[i]) await new Promise(r => setTimeout(r, DELAYS[i]));
    try {
      const controller = new AbortController();
      const tid = setTimeout(() => controller.abort(), 30000);
      const _cgToken = await _getToken();
      const res = await fetch(
        `${SUPABASE_URL}/functions/v1/coingecko`,
        { signal: controller.signal, headers: { 'Authorization': `Bearer ${_cgToken}` } }
      );
      clearTimeout(tid);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const coins = await res.json();
      const symbols = coins
        .map(c => (c.symbol || '').toUpperCase().trim())
        .filter(s => s && s.length <= 10 && /^[A-Z0-9]+$/.test(s));
      const unique = [...new Set(symbols)];
      unique.forEach(s => CRYPTO_SYMBOLS.add(s));
      // Save to cache
      try { localStorage.setItem(CGECKO_CACHE_KEY, JSON.stringify({ ts: Date.now(), symbols: unique })); } catch(e) { console.warn('[CoinGecko] cache save failed:', e); }
      updateCryptoStatus('live', unique.length, Date.now());
      return;
    } catch(e) {
      console.warn(`[CoinGecko] attempt ${i + 1}/${DELAYS.length} failed:`, e.message);
    }
  }
  // All attempts failed — keep the cached list if we have one (calmer status).
  updateCryptoStatus(cachedCount ? 'cache' : 'error', cachedCount, cachedTs);
}

function updateCryptoStatus(state, count, ts) {
  const el = document.getElementById('crypto-sym-status');
  if (!el) return;
  const age = ts ? Math.round((Date.now() - ts) / 3600000) : 0;
  const he = _lang === 'he';
  const ageStr = ts ? (age < 1 ? (he ? 'עכשיו' : 'just now') : (he ? `לפני ${age}ש׳` : `${age}h ago`)) : '';
  const map = {
    loading: { icon: '🔄', text: count ? `${count.toLocaleString()} ${he?'מטבעות':'coins'} (${he?'מרענן ברקע...':'refreshing...'})` : (he?'טוען מ-CoinGecko...':'Loading from CoinGecko...'), cls: '' },
    live:    { icon: '🟢', text: `${count.toLocaleString()} ${he?'מטבעות':'coins'} (${he?'עודכן עכשיו':'updated now'})`, cls: 'live' },
    cache:   { icon: '🔵', text: `${count.toLocaleString()} ${he?'מטבעות':'coins'} (${ageStr})`, cls: 'cache' },
    error:   { icon: '🔴', text: he?'טעינה נכשלה — משתמש ברשימה מקומית':'Load failed — using local list', cls: 'error' },
  };
  const m = map[state] || map.error;
  el.innerHTML = `<span class="cg-status-icon">${m.icon}</span> ${m.text}
    ${state !== 'loading' ? `<button class="cg-refresh-btn" onclick="cgRefresh()" title="${he?'רענן רשימה':'Refresh'}">↺</button>` : ''}`;
  el.className = `cg-status ${m.cls}`;
}

async function cgRefresh() {
  localStorage.removeItem(CGECKO_CACHE_KEY);
  await loadCryptoSymbolsFromCoinGecko();
}
// ────────────────────────────────────────────────────────────────

// ── Stock symbol list — Finnhub (daily) with SEC EDGAR fallback ──
const SEC_CACHE_KEY     = 'sec-symbols-v1';
const FINNHUB_CACHE_KEY = 'fh-symbols-v1';
const SEC_TTL_MS        = 7 * 24 * 60 * 60 * 1000;
const FINNHUB_TTL_MS    = 24 * 60 * 60 * 1000;
const FINNHUB_KEY_LS    = 'finnhub-api-key';
let STOCK_SYMBOLS       = new Set();

// In-memory user settings cache (populated by loadUserSettings on login)
let _userSettings = {};

async function loadUserSettings() {
  if (!_currentUser) return;
  const { data } = await _sb.from('user_settings')
    .select('groq_api_key, groq_inv_key, finnhub_key, fmp_key, av_key, flex_token, flex_query_id, portfolio_total, bybit_api_key')
    .eq('user_id', _currentUser.id)
    .single();
  _userSettings = data || {};
  const av = _currentUser?.user_metadata?.avatar;
  if (av) _setAvatar(av);

  // Show saved status without exposing key value
  if (_userSettings.groq_api_key) {
    const el = document.getElementById('ai-api-key');
    if (el) { el.value = ''; el.placeholder = 'מפתח שמור ✓'; }
  }
  if (_userSettings.groq_inv_key) {
    const el = document.getElementById('inv-groq-key-input');
    if (el) { el.value = ''; el.placeholder = 'מפתח שמור ✓'; }
  }
  if (_userSettings.finnhub_key) {
    const el = document.getElementById('finnhub-key-input');
    if (el) { el.value = ''; el.placeholder = 'מפתח שמור ✓'; }
  }
  if (_userSettings.av_key) {
    const el = document.getElementById('av-key-input');
    if (el) { el.value = ''; el.placeholder = 'מפתח שמור ✓'; }
  }
  if (_userSettings.flex_token) {
    const el = document.getElementById('flex-token');
    if (el) { el.value = _userSettings.flex_token; el.placeholder = ''; }
    _brokerBadgeFromStore('ibkr', true);
  }
  if (_userSettings.flex_query_id) {
    const el = document.getElementById('flex-query-id');
    if (el) { el.value = _userSettings.flex_query_id; el.placeholder = ''; }
  }
  if (_userSettings.bybit_api_key) {
    const el = document.getElementById('bybit-api-key');
    if (el) { el.value = _userSettings.bybit_api_key; el.placeholder = ''; }
    // Security: the API secret is never returned to the browser — it lives only
    // in the DB and is read server-side by the Bybit edge function.
    const el2 = document.getElementById('bybit-api-secret');
    if (el2) { el2.value = ''; el2.placeholder = '•••••••• (שמור בשרת)'; }
    _brokerBadgeFromStore('bybit', true);
  }
  renderFmpKeyStatus();
  if (_userSettings.portfolio_total != null) {
    const ptEl = document.getElementById('inv-portfolio-total');
    if (ptEl) { ptEl.value = _userSettings.portfolio_total; invRecalc(); }
  }
}

async function _saveUserSettings(patch) {
  if (!_currentUser) return;
  Object.assign(_userSettings, patch);
  await _sb.from('user_settings').upsert(
    { user_id: _currentUser.id, ...patch },
    { onConflict: 'user_id' }
  );
}

function getFinnhubKey() { return _userSettings.finnhub_key || ''; }

async function saveFinnhubKey() {
  const val = (document.getElementById('finnhub-key-input')?.value || '').trim();
  await _saveUserSettings({ finnhub_key: val || null });
  localStorage.removeItem(FINNHUB_CACHE_KEY);
  const inp = document.getElementById('finnhub-key-input');
  if (inp) { inp.value = ''; inp.placeholder = val ? 'מפתח שמור ✓' : 'Finnhub API Key'; }
  toast(val ? 'מפתח Finnhub נשמר 🔐' : 'מפתח הוסר — משתמש ב-SEC EDGAR', 'success');
  STOCK_SYMBOLS = new Set();
  loadStockSymbols();
}

function getFmpKey() { return _userSettings.fmp_key || ''; }
function getAvKey()  { return _userSettings.av_key  || ''; }

async function saveFmpKey() {
  const val = (document.getElementById('fmp-key-input')?.value || '').trim();
  await _saveUserSettings({ fmp_key: val || null });
  document.getElementById('fmp-key-input').value = '';
  toast(val ? 'מפתח FMP נשמר 🔐' : 'מפתח FMP הוסר', 'success');
  renderFmpKeyStatus();
}

function renderFmpKeyStatus() {
  const el = document.getElementById('fmp-key-status');
  if (!el) return;
  const key = getFmpKey();
  el.textContent = key ? '✓ מפתח שמור' : '';
  el.style.color = key ? 'var(--green)' : 'var(--text3)';
}

async function saveAvKey() {
  const val = (document.getElementById('av-key-input')?.value || '').trim();
  await _saveUserSettings({ av_key: val || null });
  const inp = document.getElementById('av-key-input');
  if (inp) { inp.value = ''; inp.placeholder = val ? 'מפתח שמור ✓' : 'Alpha Vantage API Key'; }
  toast(val ? 'מפתח Alpha Vantage נשמר 🔐' : 'מפתח Alpha Vantage הוסר', 'success');
}

async function loadStockSymbols() {
  const key = getFinnhubKey();
  if (key) await loadFromFinnhub();
  else     await loadFromSEC();
}

async function loadFromFinnhub() {
  // 1. Load from cache immediately
  let cachedCount = 0, cachedTs = 0;
  try {
    const raw = localStorage.getItem(FINNHUB_CACHE_KEY);
    if (raw) {
      const { ts, symbols } = JSON.parse(raw);
      if (Array.isArray(symbols) && symbols.length) {
        symbols.forEach(s => STOCK_SYMBOLS.add(s));
        cachedCount = symbols.length;
        cachedTs = ts;
        updateStockStatus('cache', cachedCount, cachedTs, 'Finnhub');
      }
    }
  } catch(e) {}

  // 2. Always fetch fresh on every session
  updateStockStatus('loading', cachedCount, cachedTs, 'Finnhub');
  try {
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), 20000);
    // Route through Supabase Edge Function (handles auth + token from user_settings)
    const token = await _getToken();
    const [resUS, resTA] = await Promise.all([
      fetch(`${SUPABASE_URL}/functions/v1/finnhub?path=stock%2Fsymbol&exchange=US`,
        { signal: controller.signal, headers: { 'Authorization': `Bearer ${token}` } }),
      fetch(`${SUPABASE_URL}/functions/v1/finnhub?path=stock%2Fsymbol&exchange=TA`,
        { headers: { 'Authorization': `Bearer ${token}` } }).catch(() => null),
    ]);
    clearTimeout(tid);
    if (!resUS.ok) throw new Error('HTTP ' + resUS.status);
    const dataUS = await resUS.json();
    const dataTA = resTA?.ok ? await resTA.json() : [];
    if (!Array.isArray(dataUS)) throw new Error('Bad response');
    const usSymbols = dataUS
      .map(c => (c.symbol || '').toUpperCase().trim().split('.')[0])
      .filter(s => s && /^[A-Z]{1,5}$/.test(s));
    const taSymbols = Array.isArray(dataTA) ? dataTA
      .map(c => (c.symbol || '').toUpperCase().trim())
      .filter(s => s && /^[A-Z0-9]{1,6}$/.test(s))
      .map(s => s + '.TA') : [];
    const unique = [...new Set([...usSymbols, ...taSymbols])];
    unique.forEach(s => STOCK_SYMBOLS.add(s));
    try { localStorage.setItem(FINNHUB_CACHE_KEY, JSON.stringify({ ts: Date.now(), symbols: unique })); } catch(e) { console.warn('[Finnhub] cache save failed:', e); }
    updateStockStatus('live', unique.length, Date.now(), 'Finnhub');
  } catch(e) {
    console.warn('[Finnhub] proxy failed:', e.message);
    updateStockStatus('error', 0, 0, 'Finnhub');
    await loadFromSEC();
  }
}

async function loadFromSEC() {
  // 1. Load from cache immediately
  let cachedCount = 0, cachedTs = 0;
  try {
    const raw = localStorage.getItem(SEC_CACHE_KEY);
    if (raw) {
      const { ts, symbols } = JSON.parse(raw);
      if (Array.isArray(symbols) && symbols.length) {
        symbols.forEach(s => STOCK_SYMBOLS.add(s));
        cachedCount = symbols.length;
        cachedTs = ts;
        updateStockStatus('cache', cachedCount, cachedTs);
      }
    }
  } catch(e) {}

  // 2. Always fetch fresh via Edge Function (avoids browser CORS on SEC.gov)
  updateStockStatus('loading', cachedCount, cachedTs);
  try {
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), 20000);
    const token = await _getToken();
    const res = await fetch(`${SUPABASE_URL}/functions/v1/edgar?tickers=1`,
      { signal: controller.signal, headers: { 'Authorization': `Bearer ${token}` } });
    clearTimeout(tid);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const unique = await res.json();
    if (!Array.isArray(unique)) throw new Error('Bad response');
    unique.forEach(s => STOCK_SYMBOLS.add(s));
    try { localStorage.setItem(SEC_CACHE_KEY, JSON.stringify({ ts: Date.now(), symbols: unique })); } catch(e) { console.warn('[SEC] cache save failed:', e); }
    updateStockStatus('live', unique.length, Date.now());
  } catch(e) {
    console.warn('[SEC] failed:', e.message);
    if (cachedCount) updateStockStatus('cache', cachedCount, cachedTs);
    else updateStockStatus('error', 0, 0, 'SEC');
  }
}

function updateStockStatus(state, count, ts, source) {
  const el = document.getElementById('stock-sym-status');
  if (!el) return;
  const age = ts ? Math.round((Date.now() - ts) / 3600000) : 0;
  const he = _lang === 'he';
  const ageStr = ts ? (age < 1 ? (he?'עכשיו':'just now') : age < 24 ? (he?`לפני ${age}ש׳`:`${age}h ago`) : (he?`לפני ${Math.round(age/24)}י׳`:`${Math.round(age/24)}d ago`)) : '';
  const src = source ? ` <span style="opacity:.6;font-size:10px;">(${source})</span>` : '';
  const map = {
    loading: { icon: '🔄', text: count ? `${count.toLocaleString()} ${he?'מניות':'stocks'} (${he?'מרענן ברקע...':'refreshing...'})${src}` : `${he?'טוען מ-':'Loading from '}${source||''}...`, cls: '' },
    live:    { icon: '🟢', text: `${count.toLocaleString()} ${he?'מניות':'stocks'} — ${he?'עודכן עכשיו':'updated now'}${src}`, cls: 'live' },
    cache:   { icon: '🔵', text: `${count.toLocaleString()} ${he?'מניות':'stocks'} — ${ageStr}${src}`, cls: 'cache' },
    error:   { icon: '🔴', text: he?`שגיאה ב-${source} — עובר ל-SEC EDGAR`:`Error in ${source} — switching to SEC EDGAR`, cls: 'error' },
  };
  const m = map[state] || map.error;
  el.innerHTML = `<span class="cg-status-icon">${m.icon}</span> ${m.text}
    ${state !== 'loading' ? `<button class="cg-refresh-btn" onclick="secRefresh()" title="${he?'רענן רשימה':'Refresh'}">↺</button>` : ''}`;
  el.className = `cg-status ${m.cls}`;
}

async function secRefresh() {
  localStorage.removeItem(SEC_CACHE_KEY);
  localStorage.removeItem(FINNHUB_CACHE_KEY);
  STOCK_SYMBOLS = new Set();
  await loadStockSymbols();
}
// ────────────────────────────────────────────────────────────────

// Shared auto-type logic — returns true if symbol looks like crypto
function symIsCrypto(sym) {
  const s = sym.toUpperCase().trim();
  // 1. Explicit crypto suffix: SOLUSDT.P, ETHUSDT, BTC.P
  if (/USDT\.P$|USDT$|\.P$/i.test(s)) return true;
  // 2. If SEC EDGAR knows it as a stock — it's not crypto
  if (STOCK_SYMBOLS.size > 0 && STOCK_SYMBOLS.has(s)) return false;
  // 3. Longer than 5 chars → likely crypto
  if (s.length > 5) return true;
  // 4. Known crypto base symbols
  if (CRYPTO_SYMBOLS.has(s)) return true;
  return false;
}

// Apply badge UI for stock/crypto type
function applyTypeBadge(badgeEl, isCrypto) {
  if (!badgeEl) return;
  badgeEl.textContent = isCrypto ? t('m_crypto_badge') : t('m_stock_badge');
  badgeEl.className   = 'qa-type-badge ' + (isCrypto ? 'crypto' : 'stock');
}

// Auto-detect trade type from symbol (Quick-Add widget)
function qaAutoType() {
  const sym = (document.getElementById('qa-symbol').value || '').trim().toUpperCase();
  if (!sym) return;
  const isCrypto = symIsCrypto(sym);
  const cb = document.getElementById('qa-crypto');
  if (cb && cb.checked !== isCrypto) {
    cb.checked = isCrypto;
    applyTypeBadge(document.getElementById('qa-type-badge'), isCrypto);
    qaCalc();
  }
}

// Toggle type manually in Quick-Add (badge click)
function qaToggleType() {
  const cb = document.getElementById('qa-crypto');
  if (!cb) return;
  cb.checked = !cb.checked;
  applyTypeBadge(document.getElementById('qa-type-badge'), cb.checked);
  qaCalc();
}

// Auto-detect type in the trade modal
function mAutoType() {
  const sym = (document.getElementById('m-symbol').value || '').trim().toUpperCase();
  if (!sym) return;
  const isCrypto = symIsCrypto(sym);
  const typeInput = document.getElementById('m-type');
  if (typeInput) typeInput.value = isCrypto ? 'crypto' : 'stock';
  applyTypeBadge(document.getElementById('m-type-badge'), isCrypto);
}

// Toggle type manually in modal (badge click)
function mToggleType() {
  const typeInput = document.getElementById('m-type');
  if (!typeInput) return;
  const isCrypto = typeInput.value !== 'crypto';
  typeInput.value = isCrypto ? 'crypto' : 'stock';
  applyTypeBadge(document.getElementById('m-type-badge'), isCrypto);
}

function qaSetLS(ls) {
  qaLS = ls;
  document.getElementById('qa-l-btn').className = 'qa-ls-btn' + (ls==='L' ? ' active-l' : '');
  document.getElementById('qa-s-btn').className = 'qa-ls-btn' + (ls==='S' ? ' active-s' : '');
  qaCalc();
}

function qaCalc() {
  const entry = +document.getElementById('qa-entry').value || 0;
  const stop  = +document.getElementById('qa-stop').value  || 0;
  const shares= +document.getElementById('qa-shares').value|| 0;
  const comm  = +document.getElementById('qa-commission').value || 0;

  // % סטופ מהכניסה
  const stopPctEl = document.getElementById('qa-stop-pct');
  if (entry && stop) {
    const pct = ((stop - entry) / entry * 100);
    stopPctEl.textContent = (pct >= 0 ? '+' : '') + pct.toFixed(2) + '%';
    stopPctEl.className = 'qa-stop-pct' + (pct < 0 ? ' neg' : '');
  } else {
    stopPctEl.textContent = '';
  }

  // תצוגה מקדימה גודל פוזיציה + סיכון
  const preview = document.getElementById('qa-preview');
  if (entry && shares) {
    preview.style.display = 'flex';
    const posSize = entry * shares;
    document.getElementById('qa-prev-pl').textContent = '$' + posSize.toFixed(0);
    const stopRisk = stop && shares ? Math.abs(stop - entry) * shares : 0;
    const pctEl = document.getElementById('qa-prev-pct');
    pctEl.textContent = stopRisk ? '$' + stopRisk.toFixed(2) : '—';
  } else {
    preview.style.display = 'none';
  }
}

function qaSave() {
  const symbol = sanitizeText(document.getElementById('qa-symbol').value.toUpperCase().replace(/[^A-Z0-9._\-]/g,''), 20);
  const entryPrice = sanitizeNumber(document.getElementById('qa-entry').value, 0);
  const shares     = sanitizeNumber(document.getElementById('qa-shares').value, 0, 1e7);
  const stop       = sanitizeNumber(document.getElementById('qa-stop').value, 0);
  const commission = sanitizeNumber(document.getElementById('qa-commission').value, 0, 1e6);
  const entryDate  = document.getElementById('qa-date').value.slice(0, 10);
  const note       = sanitizeText(document.getElementById('qa-note').value, 200);
  const isCrypto   = document.getElementById('qa-crypto').checked;

  if (!symbol)     { toast('נא להזין סימבול', 'error'); return; }
  const symInpEl = document.getElementById('qa-symbol');
  if (symInpEl && symInpEl.dataset.symValid === '0') {
    toast('⚠️ הסימבול "' + symbol + '" לא נמצא — בדוק ושנה לפני שמירה', 'error'); return;
  }
  if (!entryDate)  { toast('נא לבחור תאריך', 'error'); return; }
  if (!entryPrice) { toast('נא להזין מחיר כניסה', 'error'); return; }
  if (!shares)     { toast('נא להזין מספר מניות', 'error'); return; }

  const type = isCrypto ? 'crypto' : 'stock';
  const arr  = isCrypto ? db.crypto : db.stocks;
  const newId = arr.length ? Math.max(...arr.map(t => t.id)) + 1 : 1;

  const trade = {
    id: newId, type,
    entryDate, ls: qaLS, symbol, entryPrice, shares, stop,
    t: [], closeDate: '', closedShares: 0, exitPrice: 0,
    ecn: 0, commission,
    notes_keep: '', notes_improve: note,
    entry_reason: ER_OPTIONS.includes(qaER) ? qaER : '',
    market_cond:  document.getElementById('qa-market-cond').value || '',
    process_score: qaPS || 0,
    mood: sanitizeText(document.getElementById('qa-mood').value, 300)
  };

  arr.push(trade);
  saveDB();
  auditLog('trade_added', symbol + ' (quick-add)');
  toast('✅ עסקה נוספה: ' + symbol, 'success');

  // איפוס שדות (שמור תאריך ועמלה)
  const _symEl = document.getElementById('qa-symbol');
  _symEl.value = ''; _symEl.dataset.symValid = ''; _symEl.dataset.symPrice = '';
  const _stEl = document.getElementById('qa-sym-status');
  if (_stEl) { _stEl.textContent = ''; _stEl.className = 'sym-status'; }
  document.getElementById('qa-entry').value  = '';
  document.getElementById('qa-shares').value = '';
  document.getElementById('qa-stop').value   = '';
  document.getElementById('qa-note').value   = '';
  document.getElementById('qa-mood').value   = '';
  document.getElementById('qa-stop-pct').textContent = '';
  document.getElementById('qa-preview').style.display = 'none';
  document.getElementById('qa-market-cond').value = '';
  qaPS = 0; document.querySelectorAll('#qa-ps-stars span').forEach(s => s.className = '');
  qaER = ''; document.querySelectorAll('#qa-er-pills .er-pill').forEach(p => p.className = 'er-pill');

  renderOverview();
  initFilters();
  fabToggle(); // סגור מודל אחרי שמירה
}

function tradeDays(t) {
  if (!t.entryDate || !t.closeDate) return 0;
  const diff = new Date(t.closeDate+'T00:00:00') - new Date(t.entryDate+'T00:00:00');
  return Math.max(0, Math.round(diff / (1000 * 60 * 60 * 24)));
}

function advancedStats(trades) {
  const winners = trades.filter(t => calcPL(t) > 0);
  const losers  = trades.filter(t => calcPL(t) < 0);
  const avgWin     = winners.length ? winners.reduce((s,t) => s + calcPL(t), 0) / winners.length : 0;
  const avgLoss    = losers.length  ? losers.reduce((s,t)  => s + calcPL(t), 0) / losers.length  : 0;
  const avgWinDays = winners.length ? winners.reduce((s,t) => s + tradeDays(t), 0) / winners.length : 0;
  const avgLossDays= losers.length  ? losers.reduce((s,t)  => s + tradeDays(t), 0) / losers.length  : 0;
  return { avgWin, avgLoss, avgWinDays, avgLossDays };
}

const MONTHS_SHORT = MONTHS_SHORT_HE;

function _tradePct(t) {
  const base = t.entryPrice * (t.closedShares || t.shares);
  return base > 0 ? calcTotal(t) / base * 100 : null;
}

function renderMonthlyTracker(trades) {
  const wrap = document.getElementById('monthly-tracker-wrap');
  if (!wrap) return;
  const effectiveYear = +(document.getElementById('stats-year')?.value) || +(document.getElementById('ov-year')?.value) || new Date().getFullYear();
  const lbl = document.getElementById('mt-year-label');
  if (lbl) lbl.textContent = effectiveYear;
  const closed = trades.filter(t =>
    t.exitPrice > 0 && t.closedShares > 0 &&
    +(t.entryDate||'').slice(0,4) === effectiveYear
  );

  // Build per-month data
  const byMonth = {}; // key = "MM" (01-12)
  closed.forEach(t => {
    const m = (t.entryDate || '').slice(5, 7);
    if (!m) return;
    if (!byMonth[m]) byMonth[m] = [];
    byMonth[m].push(t);
  });

  const MONTH_KEYS = ['01','02','03','04','05','06','07','08','09','10','11','12'];

  function monthStats(arr) {
    if (!arr || !arr.length) return null;
    const winners = arr.filter(t => calcPL(t) > 0);
    const losers  = arr.filter(t => calcPL(t) < 0);
    const avgGainPct = winners.length ? winners.reduce((s,t)=>{ const p=_tradePct(t); return p!==null?s+p:s; },0) / winners.length : null;
    const avgLossPct = losers.length  ? losers.reduce((s,t)=>{ const p=_tradePct(t); return p!==null?s+p:s; },0) / losers.length  : null;
    const winRate    = arr.length ? winners.length / arr.length * 100 : 0;
    const lgGain     = winners.length ? Math.max(...winners.map(t=>calcPL(t))) : null;
    const lgLoss     = losers.length  ? Math.min(...losers.map(t=>calcPL(t)))  : null;
    const avgDaysWin = winners.length ? winners.reduce((s,t)=>s+tradeDays(t),0)/winners.length : null;
    const avgDaysLoss= losers.length  ? losers.reduce((s,t)=>s+tradeDays(t),0)/losers.length   : null;
    return { n: arr.length, avgGainPct, avgLossPct, winRate, lgGain, lgLoss, avgDaysWin, avgDaysLoss };
  }

  function pct(v) { return v === null ? '<span class="mt-empty">—</span>' : `${v>=0?'+':''}${v.toFixed(2)}%`; }
  function usd(v) { return v === null ? '<span class="mt-empty">—</span>' : fmtUSD(v); }
  function days(v){ return v === null ? '<span class="mt-empty">—</span>' : Math.round(v); }
  function clrPct(v, el) { return v === null ? '' : v >= 0 ? 'color:var(--green)' : 'color:var(--red)'; }

  let rows = '';
  const validMonths = [];
  MONTH_KEYS.forEach((mk, i) => {
    const arr = byMonth[mk];
    const s = monthStats(arr);
    if (!s) {
      rows += `<tr><td>${monthsShort()[i]}</td><td class="mt-empty">—</td><td class="mt-empty">—</td><td class="mt-empty">—</td><td class="mt-empty">—</td><td class="mt-empty">—</td><td class="mt-empty">—</td><td class="mt-empty">—</td><td class="mt-empty">—</td></tr>`;
      return;
    }
    validMonths.push(s);
    rows += `<tr>
      <td>${monthsShort()[i]}</td>
      <td class="${s.avgGainPct!==null?(s.avgGainPct>=0?'cl-green':'cl-red'):''} sensitive">${pct(s.avgGainPct)}</td>
      <td class="${s.avgLossPct!==null?(s.avgLossPct>=0?'cl-green':'cl-red'):''} sensitive">${pct(s.avgLossPct)}</td>
      <td class="${s.winRate>=50?'cl-green':'cl-red'} sensitive">${fmt(s.winRate,1)}%</td>
      <td class="sensitive">${s.n}</td>
      <td class="cl-green sensitive">${usd(s.lgGain)}</td>
      <td class="cl-red sensitive">${usd(s.lgLoss)}</td>
      <td class="sensitive">${days(s.avgDaysWin)}</td>
      <td class="sensitive">${days(s.avgDaysLoss)}</td>
    </tr>`;
  });

  // AVG row
  let avgRow = `<tr><td>${t('mt_avg_row')}</td>`;
  if (validMonths.length) {
    const avg = f => { const vals=validMonths.filter(s=>s[f]!==null); return vals.length?vals.reduce((a,s)=>a+s[f],0)/vals.length:null; };
    const avgWR = validMonths.reduce((a,s)=>a+s.winRate,0)/validMonths.length;
    const avgN  = Math.round(validMonths.reduce((a,s)=>a+s.n,0)/validMonths.length);
    const agp = avg('avgGainPct'), alp = avg('avgLossPct');
    avgRow += `<td class="${agp!==null?(agp>=0?'cl-green':'cl-red'):''} sensitive">${pct(agp)}</td>`;
    avgRow += `<td class="${alp!==null?(alp>=0?'cl-green':'cl-red'):''} sensitive">${pct(alp)}</td>`;
    avgRow += `<td class="${avgWR>=50?'cl-green':'cl-red'} sensitive">${fmt(avgWR,1)}%</td>`;
    avgRow += `<td class="sensitive">${avgN}</td>`;
    avgRow += `<td class="cl-green sensitive">${usd(avg('lgGain'))}</td>`;
    avgRow += `<td class="cl-red sensitive">${usd(avg('lgLoss'))}</td>`;
    avgRow += `<td class="sensitive">${days(avg('avgDaysWin'))}</td>`;
    avgRow += `<td class="sensitive">${days(avg('avgDaysLoss'))}</td>`;
  } else {
    avgRow += '<td colspan="8" class="mt-empty">—</td>';
  }
  avgRow += '</tr>';

  wrap.innerHTML = `<table class="mt-table">
    <thead><tr>
      <th></th>
      <th>${t('mt_avg_gain')}</th>
      <th>${t('mt_avg_loss')}</th>
      <th>WIN %</th>
      <th>${t('mt_total_trades')}</th>
      <th>${t('mt_max_gain')}</th>
      <th>${t('mt_max_loss')}</th>
      <th>${t('mt_avg_days_win')}</th>
      <th>${t('mt_avg_days_loss')}</th>
    </tr></thead>
    <tbody>${rows}${avgRow}</tbody>
  </table>`;
}

function renderTradingSummary(trades) {
  const wrap = document.getElementById('trading-summary-wrap');
  if (!wrap) return;
  const closed = trades.filter(t => t.exitPrice > 0 && t.closedShares > 0);
  if (!closed.length) { wrap.innerHTML = `<div style="color:var(--text3);font-size:13px;padding:8px 0;">${t('ts_no_closed')}</div>`; return; }

  const winners = closed.filter(t => calcPL(t) > 0);
  const losers  = closed.filter(t => calcPL(t) < 0);
  const wr = closed.length ? winners.length / closed.length * 100 : 0;
  const lossRate = 100 - wr;

  const avgGainPct = winners.length ? winners.reduce((s,t)=>{ const p=_tradePct(t); return p!==null?s+p:s; },0)/winners.length : 0;
  const avgLossPct = losers.length  ? Math.abs(losers.reduce((s,t)=>{ const p=_tradePct(t); return p!==null?s+p:s; },0)/losers.length) : 0;
  const wlRatio    = avgLossPct > 0 ? avgGainPct / avgLossPct : null;
  const adjWL      = (avgLossPct > 0 && lossRate > 0) ? (wr/100 * avgGainPct) / (lossRate/100 * avgLossPct) : null;

  const row = (label, val, cls='') => `<tr><td>${label}</td><td class="${cls} sensitive">${val}</td></tr>`;

  wrap.innerHTML = `<table class="ts-table">
    <tbody>
      ${row(t('ts_win_rate'), fmt(wr,2)+'%', wr>=50?'green':'red')}
      ${row(t('ts_avg_gain_pct'), '+'+fmt(avgGainPct,2)+'%', 'green')}
      ${row(t('ts_avg_loss_pct'), '-'+fmt(avgLossPct,2)+'%', 'red')}
      ${row(t('ts_gl_ratio'), wlRatio!==null?fmt(wlRatio,2)+'x':'—', wlRatio!==null&&wlRatio>=1?'green':'red')}
      ${row(t('ts_adj_wl'), adjWL!==null?fmt(adjWL,2):'—', adjWL!==null&&adjWL>=1?'green':'red')}
    </tbody>
  </table>`;
}

// ─────────────────────────────────────────────
// PROFILE
// ─────────────────────────────────────────────
function profileLoad() {
  if (!_currentUser) return;
  const m = _currentUser.user_metadata || {};
  document.getElementById('profile-first').value   = m.first_name   || '';
  document.getElementById('profile-last').value    = m.last_name    || '';
  document.getElementById('profile-email').value   = _currentUser.email || '';
  document.getElementById('profile-save-btn').style.display = 'none';
}

function profileMarkDirty() {
  document.getElementById('profile-save-btn').style.display = 'inline-flex';
}

async function profileSave() {
  const first   = document.getElementById('profile-first').value.trim();
  const last    = document.getElementById('profile-last').value.trim();
  const display = [first, last].filter(Boolean).join(' ') || _currentUser.email.split('@')[0];
  const btn = document.getElementById('profile-save-btn');
  btn.textContent = 'Saving...';
  btn.disabled = true;
  try {
    await _sb.auth.updateUser({ data: { first_name: first, last_name: last, full_name: display } });
    if (_currentUser?.user_metadata) { _currentUser.user_metadata.first_name = first; _currentUser.user_metadata.full_name = display; }
    _setHeaderGreeting(first || display.split(/\s+/)[0]);
    const el = document.getElementById('header-user-name');
    if (el) el.textContent = display;
    btn.style.display = 'none';
    toast('פרופיל נשמר ✓', 'success');
  } catch {
    toast('שגיאה בשמירת הפרופיל', 'error');
  } finally {
    btn.textContent = 'Save Changes';
    btn.disabled = false;
  }
}

async function avatarUpload(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) { toast('תמונה גדולה מדי — מקסימום 2MB', 'error'); return; }
  const dataURL = await compressImage(file);
  if (!dataURL) { toast('שגיאה בטעינת התמונה', 'error'); return; }
  const { error } = await _sb.auth.updateUser({ data: { avatar: dataURL } });
  if (error) { toast('שגיאה בשמירה: ' + error.message, 'error'); return; }
  _setAvatar(dataURL);
  toast('תמונת פרופיל עודכנה ✓', 'success');
}

// ─────────────────────────────────────────────
// LANGUAGE
// ─────────────────────────────────────────────
let _lang = localStorage.getItem('tj_lang') || 'he';
function t(k) { return (LANG_STRINGS[_lang] || LANG_STRINGS.en)[k] || k; }

const LANG_STRINGS = {
  en: {
    nav_overview:'Home', nav_stocks:'Stocks / Crypto', nav_crypto:'Crypto',
    nav_statistics:'Statistics', nav_settings:'Settings', nav_themes:'Market Pulse',
    nav_ai:'Minervini', nav_missed:'Missed', nav_investments:'Investments',
    nav_section:'Navigation', add_trade:'Add Trade',
    filter_label:'Filter:', all_time:'All Time', archive:'📅 Archive',
    search:'Search symbol...',
    add_new_trade:'+ Add New Trade', clean_dupes:'🧹 Clean Duplicates',
    col_entry_date:'Entry Date', col_status:'Status', col_reason:'Entry Reason',
    col_symbol:'Symbol', col_entry:'Entry', col_shares:'Shares', col_stop:'Stop',
    col_targets:'Targets', col_close_date:'Close Date', col_closed_shares:'Closed Shares',
    col_exit:'Exit', col_sector:'Sector', col_commission:'Commission',
    col_total:'Total', col_actions:'Actions',
    kpi_pnl:'Total P&L', kpi_winrate:'Win Rate', kpi_trades:"Trades",
    kpi_rr:'Risk/Reward', kpi_live:'Live P&L',
    kpi_with_stop:'trades with stop', kpi_add_stop:'Add stop',
    kpi_open_pos:'open positions', kpi_no_open:'No open positions',
    kpi_calculating:'Calculating...', kpi_vs_prev:'vs last month',
    kpi_updated:'Updated now',
    tile_net_pl:'Net P&L', tile_return:'Return', tile_r_mult:'R Multiple',
    tile_risk:'Trade Risk', tile_stop_dist:'Stop Distance', tile_commission:'Commission',
    tile_entry:'Entry', tile_stop:'Stop', tile_exit:'Exit',
    tile_partial_tgt:'Partial Targets', tile_market_cond:'Market Condition',
    tile_no_targets:'No targets', tile_from_entry:'% from entry',
    tile_keep:'What to keep', tile_improve:'What to improve',
    tile_no_notes:'No notes recorded',
    trades:'trades', no_trades:'No trades for this period',
    modal_add:'Add Trade', modal_edit:'Edit Trade',
    modal_open_trade:'Trade Entry', modal_targets:'🎯 Partial Targets (T1–T5)',
    modal_close_trade:'🔒 Trade Close', modal_fees:'Fees',
    modal_calc:'🧮 Auto Calculation', modal_notes:'📝 Notes & Quality',
    add_target:'+ Add Target', m_entry_date:'Entry Date',
    m_symbol:'Symbol', m_entry_price:'Entry Price', m_num_shares:'Shares',
    m_stop:'Stop', m_close_date:'Close Date', m_closed_shares:'Closed Shares',
    m_exit_price:'Exit Price', m_mood:'Emotional State', m_reason:'Entry Reason',
    m_market_cond:'Market Condition', m_keep:'What worked well',
    m_improve:'What to improve', m_save:'💾 Save Trade', m_cancel:'Cancel',
    m_stock_badge:'Stock', m_crypto_badge:'Crypto',
    m_keep_ph:'What worked well in this trade...',
    m_improve_ph:'What could be improved...',
    m_mood_ph:'How did you feel before entry...',
    qa_type:'Type', qa_entry_date:'Entry Date', qa_entry_price:'Entry Price',
    qa_shares:'Shares', qa_stop:'Stop (SL)', qa_commission:'Commission',
    qa_reason:'Entry Reason', qa_market_cond:'Market Condition',
    qa_mood:'Emotional State', qa_note:'Note', qa_save:'💾 Save Trade',
    qa_pos_size:'Position', qa_risk_pct:'Risk %', qa_stop_from:'Stop from Entry',
    qa_select:'— Select —', qa_mood_ph:'How did you feel...', qa_note_ph:'Trade description...',
    inv_title:'Investment Portfolio', inv_portfolio_total:'Portfolio Total', inv_cash_label:'Cash',
    inv_free_cash:'Free Cash', inv_total_value:'Total',
    inv_allocated:'Invested', inv_alloc_title:'Portfolio Allocation — Target',
    inv_available:'Available:', inv_donut_allocated:'Allocated',
    inv_blue:'🔵 Blue Chips — Target', inv_green:'🟢 Growth — Target',
    inv_yellow:'🟡 Speculative — Target',
    inv_col_symbol:'Symbol', inv_col_sector:'Sector', inv_col_category:'Category',
    inv_col_avg:'Average', inv_col_value:'Value',
    inv_col_portfolio_pct:'% Portfolio', inv_col_remaining:'Remaining',
    inv_add_holding:'+ Add Holding', inv_save:'💾 Save',
    inv_deposits:'Monthly Deposits', inv_add_deposit:'+ Add Deposit',
    inv_total_dep:'Total Deposited', inv_portfolio_now:'Portfolio Value Now',
    inv_pnl:'P&L vs Deposits', inv_unrealized:'Unrealized P&L', inv_refresh_prices:'Refresh Prices', inv_over:'Exceeded', inv_overby:'Exceeded by', inv_free:'Available', inv_saved:'Portfolio saved ✓', inv_cash_label:'Cash', inv_sum_invested:'Total Invested', inv_sum_value:'Current Value', inv_sum_pnl:'Unrealized P&L', inv_sum_updated:'Prices updated', inv_just_now:'just now', inv_dep_month:'Month', inv_dep_amount:'Deposit',
    inv_dep_cumulative:'Cumulative', inv_cash:'Cash',
    inv_legend_blue:'Blue Chips', inv_legend_green:'Growth', inv_legend_yellow:'Speculative',
    missed_title:'Missed Opportunities', missed_symbol:'Symbol',
    missed_date:'Date', missed_price:'Price ($)', missed_sector:'Sector',
    missed_note:'Note (optional)', missed_add:'+ Add',
    missed_empty:'No opportunities recorded yet — add the first one above',
    missed_why:'Why missed?', missed_sector_ph:'Technology',
    chart_cum:'Cumulative P&L',
    settings_profile:'Profile', settings_first:'First Name',
    settings_last:'Last Name', settings_display:'Display Name',
    settings_first_ph:'First name', settings_last_ph:'Last name',
    settings_pw_new_ph:'New password', settings_pw_confirm_ph:'Confirm password',
    set_pw_new:'New Password', set_pw_confirm:'Confirm Password',
    settings_email:'Email', settings_save_profile:'Save Profile',
    settings_lang:'Language', settings_export:'Export Data',
    export_stocks:'Export Stocks', export_crypto:'Export Crypto', export_all:'Export All',
    mc_green:'🟢 Green', mc_orange:'🟠 Orange', mc_red:'🔴 Red',
    mc_easy:'Easy Market', mc_hard:'Hard Market', mc_up:'Uptrend',
    mc_press:'Pressure', mc_down:'Downtrend',
    cal_no_trades:'No trades', view_table:'Table', view_calendar:'Monthly',
    filter_all_months:'All Months', filter_all_years:'All Years',
    set_stocks:'Stocks', set_crypto:'Crypto', set_security:'Security',
    set_ibkr_sync:'Broker Connection', set_file_import:'File Import',
    set_export:'Export Data', set_broker_import:'Broker Import',
    set_2fa:'Two-Factor Authentication',
    set_ibkr_desc:'Enables automatic trade import from Interactive Brokers.',
    set_ibkr_how:'How to configure:',
    set_ibkr_steps:'Create an Activity Flex Query → Period: Last 365 Calendar Days, Format: XML, Trades section with the "Trade ID" field → Copy the Token and Query ID',
    set_sync:'Sync', m_save_short:'Save',
    set_tlg_drop:'Drag .tlg file or click to select',
    set_export_desc:'Export all trades to a CSV file for external analysis.',
    set_broker_desc:'Import trades from your broker\'s export file. Select broker, upload CSV, and confirm column mapping.',
    set_broker_label:'Broker', set_broker_select:'Select broker...',
    set_csv_drop:'Drag CSV file or click to select',
    set_import_btn:'Import Trades',
    set_loading:'Loading...',
    set_finnhub_key:'Finnhub Key (Admin only)',
    set_av_key:'Alpha Vantage Key — financial data for all stocks including small caps',
    set_get_free_key:'Get free key',
    set_page_title:'Settings', set_page_sub:'Manage your account, security, and data preferences.',
    set_grp_account:'Account', set_grp_account_sub:'Name, email',
    set_grp_prefs:'Preferences', set_grp_prefs_sub:'Language and display',
    set_security_sub:'PIN, 2FA, password',
    set_avatar_label:'Profile Picture', set_avatar_sub:'JPG or PNG, max 2MB', set_avatar_btn:'Change Photo',
    set_grp_data:'Data Sources & Security', set_grp_import:'Broker Connection',
    st_best:'Best Trade', st_worst:'Worst Trade', st_avg_trade:'Avg per Trade',
    st_avg_win:'Avg Win', st_avg_loss:'Avg Loss', st_expectancy:'Expectancy',
    st_wl_ratio:'W/L Ratio', st_max_win_streak:'Max Win Streak', st_max_loss_streak:'Max Loss Streak',
    st_avg_hold_win:'Avg Hold (Win)', st_avg_hold_loss:'Avg Hold (Loss)',
    st_avg_r:'Avg R', st_win_rate:'Win Rate',
    mt_avg_gain:'Avg Gain %', mt_avg_loss:'Avg Loss %', mt_total_trades:'Trades',
    mt_max_gain:'Max Gain', mt_max_loss:'Max Loss',
    mt_avg_days_win:'Days (Win)', mt_avg_days_loss:'Days (Loss)', mt_avg_row:'Average',
    donut_win:'Win', donut_loss:'Loss', donut_best:'Best Trade', donut_worst:'Worst Trade',
    donut_win_streak:'Win Streak', donut_loss_streak:'Loss Streak',
    ts_no_closed:'No closed trades', ts_win_rate:'Win Rate',
    ts_avg_gain_pct:'Avg Gain %', ts_avg_loss_pct:'Avg Loss %',
    ts_gl_ratio:'Gain/Loss Ratio', ts_adj_wl:'Adjusted W/L',
    comp_trades:'trades', comp_total_pl:'Total P&L',
    comp_avg_win:'Avg Win', comp_avg_loss:'Avg Loss',
    comp_best:'Best', comp_worst:'Worst', comp_avg_trade:'Avg per Trade',
    comp_stocks:'📈 Stocks', comp_crypto:'₿ Crypto',
  },
  he: {
    nav_overview:'ראשי', nav_stocks:'מניות / קריפטו', nav_crypto:'קריפטו',
    set_crypto_desc:'CoinGecko · ללא מפתח, עובד אוטומטית',
    set_finnhub_desc:'נדרש לנתוני מחיר מניות בזמן אמת. הרשם חינם ב-finnhub.io — הכנס את המפתח ולחץ Save.',
    set_av_desc:'נתוני פיננסים לכל המניות כולל Small Cap.',
    nav_statistics:'סטטיסטיקות', nav_settings:'הגדרות', nav_themes:'Market Pulse',
    nav_ai:'Minervini', nav_missed:'פוספסו', nav_investments:'השקעות',
    nav_section:'ניווט', add_trade:'הוסף עסקה',
    filter_label:'סינון:', all_time:'כל הזמן', archive:'📅 ארכיון',
    search:'חיפוש סימבול...',
    add_new_trade:'+ הוסף עסקה חדשה', clean_dupes:'🧹 נקה כפילויות',
    col_entry_date:'תאריך כניסה', col_status:'סטטוס', col_reason:'סיבת כניסה',
    col_symbol:'סימבול', col_entry:'כניסה', col_shares:'מניות', col_stop:'סטופ',
    col_targets:'יעדים', col_close_date:'תאריך סגירה', col_closed_shares:'מניות סגירה',
    col_exit:'יציאה', col_sector:'סקטור', col_commission:'עמלה',
    col_total:'סה"כ', col_actions:'פעולות',
    kpi_pnl:'P&L כולל', kpi_winrate:'אחוז הצלחה', kpi_trades:"מס' עסקאות",
    kpi_rr:'יחס סיכוי/סיכון', kpi_live:'רווח/הפסד בזמן אמת',
    kpi_with_stop:'עסקאות עם סטופ', kpi_add_stop:'הוסף סטופ',
    kpi_open_pos:'פוזיציות פתוחות', kpi_no_open:'אין פוזיציות פתוחות',
    kpi_calculating:'מחשב...', kpi_vs_prev:'vs חודש קודם',
    kpi_updated:'עודכן עכשיו',
    tile_net_pl:'P&L נטו', tile_return:'תשואה', tile_r_mult:'R Multiple',
    tile_risk:'סיכון בעסקה', tile_stop_dist:'מרחק סטופ', tile_commission:'עמלה',
    tile_entry:'כניסה', tile_stop:'סטופ', tile_exit:'יציאה',
    tile_partial_tgt:'יעדים חלקיים', tile_market_cond:'תנאי שוק',
    tile_no_targets:'אין יעדים', tile_from_entry:'% מהכניסה',
    tile_keep:'מה לשמר', tile_improve:'מה לשפר',
    tile_no_notes:'לא נרשמו הערות',
    trades:'עסקאות', no_trades:'אין עסקאות להצגה בתקופה זו',
    modal_add:'הוסף עסקה', modal_edit:'ערוך עסקה',
    modal_open_trade:'פתיחת עסקה', modal_targets:'🎯 יעדים חלקיים (T1–T5)',
    modal_close_trade:'🔒 סגירת עסקה', modal_fees:'עמלות',
    modal_calc:'🧮 חישוב אוטומטי', modal_notes:'📝 הערות ואיכות',
    add_target:'+ הוסף יעד', m_entry_date:'תאריך כניסה',
    m_symbol:'סימבול', m_entry_price:'שער כניסה', m_num_shares:"מס' מניות",
    m_stop:'סטופ', m_close_date:'תאריך סגירה', m_closed_shares:'מניות סגירה',
    m_exit_price:'מחיר יציאה', m_mood:'מצב רגשי לפני הכניסה', m_reason:'סיבת כניסה',
    m_market_cond:'תנאי שוק בכניסה', m_keep:'מה אפשר לשמר',
    m_improve:'מה לשפר להבא', m_save:'💾 שמור עסקה', m_cancel:'ביטול',
    m_stock_badge:'מניה', m_crypto_badge:'קריפטו',
    m_keep_ph:'מה עבד טוב בעסקה הזו...',
    m_improve_ph:'מה ניתן לשפר...',
    m_mood_ph:'איך הרגשת לפני הכניסה...',
    qa_type:'סוג', qa_entry_date:'תאריך כניסה', qa_entry_price:'מחיר כניסה',
    qa_shares:'מניות', qa_stop:'סטופ (SL)', qa_commission:'עמלה',
    qa_reason:'סיבת כניסה', qa_market_cond:'תנאי שוק',
    qa_mood:'מצב רגשי', qa_note:'הערה', qa_save:'💾 שמור עסקה',
    qa_pos_size:"גודל פוז'", qa_risk_pct:'סיכון %', qa_stop_from:'סטופ מ-כניסה',
    qa_select:'— בחר —', qa_mood_ph:'איך הרגשת...', qa_note_ph:'תיאור הכניסה...',
    inv_title:'תיק השקעות', inv_portfolio_total:'סך התיק', inv_cash_label:'מזומן',
    inv_free_cash:'מזומן פנוי', inv_total_value:'סך התיק',
    inv_allocated:'מושקע', inv_alloc_title:'הקצאת תיק — יעד',
    inv_available:'זמין:', inv_donut_allocated:'מוקצה',
    inv_blue:'🔵 כחולות — יעד', inv_green:'🟢 ירוקות — יעד',
    inv_yellow:'🟡 צהובות — יעד',
    inv_col_symbol:'סימבול', inv_col_sector:'סקטור', inv_col_category:'קטגוריה',
    inv_col_avg:'ממוצע', inv_col_value:'שווי',
    inv_col_portfolio_pct:'% תיק', inv_col_remaining:'נותר',
    inv_add_holding:'+ הוסף אחזקה', inv_save:'💾 שמור',
    inv_deposits:'הפקדות חודשיות', inv_add_deposit:'+ הוסף הפקדה',
    inv_total_dep:'סה"כ הופקד', inv_portfolio_now:'שווי תיק כעת',
    inv_pnl:'רווח/הפסד vs הפקדות', inv_unrealized:'רווח לא ממומש', inv_refresh_prices:'רענן מחירים', inv_over:'חרגת', inv_overby:'חרגת ב-', inv_free:'פנוי', inv_saved:'תיק ההשקעות נשמר ✓', inv_cash_label:'מזומן', inv_sum_invested:'סה"כ הושקע', inv_sum_value:'שווי נוכחי', inv_sum_pnl:'רווח לא ממומש', inv_sum_updated:'מחירים עודכנו', inv_just_now:'הרגע', inv_dep_month:'חודש', inv_dep_amount:'הפקדה',
    inv_dep_cumulative:'מצטבר', inv_cash:'מזומן',
    inv_legend_blue:'כחולות', inv_legend_green:'ירוקות', inv_legend_yellow:'צהובות',
    missed_title:'הזדמנויות שפוספסו', missed_symbol:'סימבול',
    missed_date:'תאריך', missed_price:'מחיר ($)', missed_sector:'סקטור',
    missed_note:'הערה (אופציונלי)', missed_add:'+ הוסף',
    missed_empty:'אין הזדמנויות שנרשמו עדיין — הוסף את הראשונה למעלה',
    missed_why:'למה פוספסה?', missed_sector_ph:'טכנולוגיה',
    chart_cum:'P&L מצטבר',
    settings_profile:'פרופיל', settings_first:'שם פרטי',
    settings_last:'שם משפחה', settings_display:'שם תצוגה',
    settings_first_ph:'שם פרטי', settings_last_ph:'שם משפחה',
    settings_pw_new_ph:'סיסמה חדשה', settings_pw_confirm_ph:'אישור סיסמה',
    set_pw_new:'סיסמה חדשה', set_pw_confirm:'אישור סיסמה',
    settings_email:'אימייל', settings_save_profile:'שמור פרופיל',
    settings_lang:'שפה', settings_export:'ייצוא נתונים',
    export_stocks:'ייצא מניות', export_crypto:'ייצא קריפטו', export_all:'ייצא הכל',
    mc_green:'🟢 ירוק', mc_orange:'🟠 כתום', mc_red:'🔴 אדום',
    mc_easy:'שוק קל', mc_hard:'שוק קשה', mc_up:'מגמה עולה',
    mc_press:'לחץ', mc_down:'מגמה יורדת',
    cal_no_trades:'אין עסקאות', view_table:'טבלה', view_calendar:'חודשי',
    filter_all_months:'כל החודשים', filter_all_years:'כל השנים',
    set_stocks:'מניות', set_crypto:'קריפטו', set_security:'אבטחה',
    set_ibkr_sync:'חיבור לברוקר', set_file_import:'ייבוא קובץ',
    set_export:'ייצוא נתונים', set_broker_import:'ייבוא מברוקר',
    set_2fa:'אימות דו-שלבי',
    set_ibkr_desc:'מאפשר ייבוא עסקאות אוטומטי מ-Interactive Brokers.',
    set_ibkr_how:'איך להגדיר:',
    set_ibkr_steps:'צור Activity Flex Query → Period: Last 365 Calendar Days, פורמט: XML, סעיף Trades עם השדה "Trade ID" → העתק את Token ו-Query ID',
    set_sync:'סנכרן', m_save_short:'שמור',
    set_tlg_drop:'גרור קובץ .tlg או לחץ לבחירה',
    set_export_desc:'ייצוא כל העסקאות לקובץ CSV לניתוח חיצוני.',
    set_broker_desc:'ייבוא עסקאות מקובץ ייצוא של הברוקר. בחר ברוקר, העלה קובץ CSV, ואשר את מיפוי העמודות.',
    set_broker_label:'ברוקר', set_broker_select:'בחר ברוקר...',
    set_csv_drop:'גרור קובץ CSV או לחץ לבחירה',
    set_import_btn:'ייבא עסקאות',
    set_loading:'טוען...',
    set_finnhub_key:'מפתח Finnhub (Admin בלבד)',
    set_av_key:'מפתח Alpha Vantage — נתונים פיננסיים לכל מניה כולל סמולקאפ',
    set_get_free_key:'קבל מפתח חינמי',
    set_page_title:'הגדרות', set_page_sub:'נהל את החשבון, האבטחה והעדפות הנתונים שלך.',
    set_grp_account:'חשבון', set_grp_account_sub:'שם, אימייל',
    set_grp_prefs:'העדפות', set_grp_prefs_sub:'שפה ותצוגה',
    set_security_sub:'PIN, 2FA, סיסמה',
    set_avatar_label:'תמונת פרופיל', set_avatar_sub:'JPG או PNG, עד 2MB', set_avatar_btn:'שנה תמונה',
    set_grp_data:'מקורות נתונים ואבטחה', set_grp_import:'חיבור ברוקר',
    st_best:'עסקה הטובה ביותר', st_worst:'עסקה הגרועה ביותר', st_avg_trade:'ממוצע לעסקה',
    st_avg_win:'ממוצע רווח', st_avg_loss:'ממוצע הפסד', st_expectancy:'ציפיה (Expectancy)',
    st_wl_ratio:'יחס W/L', st_max_win_streak:'רצף ניצחון מקסימלי', st_max_loss_streak:'רצף הפסד מקסימלי',
    st_avg_hold_win:'ימי החזקה ממוצע (זכייה)', st_avg_hold_loss:'ימי החזקה ממוצע (הפסד)',
    st_avg_r:'ממוצע R', st_win_rate:'אחוז הצלחה',
    mt_avg_gain:'ממוצע רווח %', mt_avg_loss:'ממוצע הפסד %', mt_total_trades:'סה"כ עסקאות',
    mt_max_gain:'רווח מקסימלי', mt_max_loss:'הפסד מקסימלי',
    mt_avg_days_win:'ימים ממוצע (רווח)', mt_avg_days_loss:'ימים ממוצע (הפסד)', mt_avg_row:'ממוצע',
    donut_win:'ניצחון', donut_loss:'הפסד', donut_best:'עסקה הטובה', donut_worst:'עסקה הגרועה',
    donut_win_streak:'רצף ניצחונות', donut_loss_streak:'רצף הפסדים',
    ts_no_closed:'אין עסקאות סגורות להצגה', ts_win_rate:'אחוז ניצחון',
    ts_avg_gain_pct:'ממוצע רווח %', ts_avg_loss_pct:'ממוצע הפסד %',
    ts_gl_ratio:'יחס רווח/הפסד', ts_adj_wl:'יחס מותאם',
    comp_trades:'עסקאות', comp_total_pl:'P&L כולל',
    comp_avg_win:'ממוצע ניצחון', comp_avg_loss:'ממוצע הפסד',
    comp_best:'הטובה', comp_worst:'הגרועה', comp_avg_trade:'ממוצע לעסקה',
    comp_stocks:'📈 מניות', comp_crypto:'₿ קריפטו',
  }
};

function setLang(lang) {
  _lang = lang;
  localStorage.setItem('tj_lang', lang);
  document.documentElement.setAttribute('lang', lang);
  document.documentElement.setAttribute('dir', lang === 'he' ? 'rtl' : 'ltr');
  const s = LANG_STRINGS[lang] || LANG_STRINGS.en;

  // Top nav
  const tnav = document.querySelectorAll('#top-nav .tnav-btn');
  const tnavKeys = ['nav_overview','nav_stocks','nav_statistics','nav_themes','nav_ai','nav_missed','nav_investments','nav_settings'];
  tnav.forEach((btn, i) => { if (tnavKeys[i]) btn.textContent = s[tnavKeys[i]]; });

  // Sidebar nav-labels
  const sideKeys = ['nav_overview','nav_stocks','nav_statistics','nav_settings','nav_themes','nav_ai','nav_missed','nav_investments'];
  document.querySelectorAll('.sidebar-nav .nav-label').forEach((el, i) => { if (sideKeys[i]) el.textContent = s[sideKeys[i]]; });

  // Sidebar section label
  const sectionEl = document.querySelector('.sidebar-section-label');
  if (sectionEl) sectionEl.textContent = s.nav_section;

  // Add trade button handled via data-i18n on the inner span

  // data-i18n elements
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const k = el.dataset.i18n;
    if (s[k]) el.textContent = s[k];
  });
  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    const k = el.dataset.i18nPh;
    if (s[k]) el.placeholder = s[k];
  });

  // Toggle buttons
  document.getElementById('lang-en')?.classList.toggle('active', lang === 'en');
  document.getElementById('lang-he')?.classList.toggle('active', lang === 'he');
  const desc = document.getElementById('lang-desc');
  if (desc) desc.textContent = lang === 'he' ? 'ממשק בעברית' : 'Interface in English';

  // Re-populate filter dropdowns with localized month names
  if (typeof initFilters === 'function') initFilters();

  // Re-render active tab content
  const activeTab = document.querySelector('.tab-content.active');
  if (activeTab) {
    const id = activeTab.id;
    if (id === 'tab-overview') renderOverview();
    else if (id === 'tab-stocks') renderTable('stock');
    else if (id === 'tab-crypto') renderTable('crypto');
    else if (id === 'tab-statistics') renderStatistics();
    else if (id === 'tab-investments') invInit();
    else if (id === 'tab-missed') missedRender();
  }
  // Also update modal/quick-add labels dynamically
  _applyModalLang(s);
}

function _applyModalLang(s) {
  // Type badge (dynamic, not covered by data-i18n)
  const qaBadge = document.getElementById('qa-type-badge');
  if (qaBadge) {
    const isCrypto = document.getElementById('qa-crypto')?.checked;
    qaBadge.textContent = isCrypto ? s.m_crypto_badge : s.m_stock_badge;
  }
  const mBadge = document.getElementById('m-type-badge');
  if (mBadge) {
    mBadge.textContent = mBadge.classList.contains('crypto') ? s.m_crypto_badge : s.m_stock_badge;
  }
  // Select options (option text not covered by data-i18n)
  const updateSelect = id => {
    const sel = document.getElementById(id);
    if (!sel || sel.options.length < 2) return;
    sel.options[0].textContent = s.qa_select;
    sel.options[1].textContent = s.mc_green;
    sel.options[2].textContent = s.mc_orange;
    sel.options[3].textContent = s.mc_red;
  };
  updateSelect('qa-market-cond');
  updateSelect('m-market-cond');
  // Donut SVG text (SVG text elements can't use data-i18n textContent update)
  const dotEl = document.getElementById('donut-allocated-label');
  if (dotEl) dotEl.textContent = s.inv_donut_allocated;
}

function langInit() {
  const saved = localStorage.getItem('tj_lang') || 'he';
  _lang = saved;
  setLang(saved);
}

// ── Fear & Greed Index ──────────────────────────
let _fgTimer = null;
const FG_COLORS = {
  'extreme fear': ['#ff6b8a', '#c0405c'],
  'fear':         ['#f97316', '#ea580c'],
  'neutral':      ['#eab308', '#ca8a04'],
  'greed':        ['#84cc16', '#65a30d'],
  'extreme greed':['#2dd4a0', '#1d9678'],
};
const FG_LABELS = {
  'extreme fear':  'Extreme Fear',
  'fear':          'Fear',
  'neutral':       'Neutral',
  'greed':         'Greed',
  'extreme greed': 'Extreme Greed',
};

async function loadFearGreed() {
  const el = document.getElementById('fear-greed-widget');
  if (!el) return;
  const R = 33, C = 40, FULL = 2 * Math.PI * R;
  el.innerHTML = `<div class="fg-gauge-wrap"><svg width="80" height="80" viewBox="0 0 80 80"><circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="6"/></svg><div class="fg-gauge-text"><span class="fg-score" style="color:var(--text2)">…</span></div></div><div class="fg-info"><div class="fg-label">Fear & Greed</div><div class="fg-rating" style="color:var(--text2);font-size:13px;">Loading</div></div>`;
  try {
    const jwt = await _getToken();
    const res = await fetch(`${SUPABASE_URL}/functions/v1/fear-greed`,
      jwt ? { headers: { 'Authorization': `Bearer ${jwt}` } } : {}
    );
    const d = await res.json();
    if (!d.score) throw new Error('no data');
    const score  = Math.round(d.score);
    const key    = (d.rating || '').toLowerCase();
    const colors = FG_COLORS[key] || ['#8faac8','#64748b'];
    const label  = FG_LABELS[key] || d.rating;
    const now    = new Date().toLocaleDateString('en-US', { month:'short', day:'numeric' });
    const dash   = (score / 100) * FULL;
    el.innerHTML = `
      <div class="fg-gauge-wrap">
        <svg width="80" height="80" viewBox="0 0 80 80">
          <circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="6"/>
          <circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="${colors[0]}" stroke-width="6"
            stroke-dasharray="${dash} ${FULL}" stroke-linecap="round"
            style="filter:drop-shadow(0 0 6px ${colors[0]}80)"/>
        </svg>
        <div class="fg-gauge-text">
          <span class="fg-score" style="color:${colors[0]}">${score}</span>
          <span class="fg-score-sub">/100</span>
        </div>
      </div>
      <div class="fg-info">
        <div class="fg-label">Fear & Greed Index</div>
        <div class="fg-rating" style="color:${colors[0]}">${label}</div>
        <div class="fg-source">CNN · Updated ${now}</div>
      </div>`;
  } catch {
    el.innerHTML = `<div class="fg-gauge-wrap"><svg width="80" height="80" viewBox="0 0 80 80"><circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="6"/></svg><div class="fg-gauge-text"><span class="fg-score" style="color:var(--text2)">—</span></div></div><div class="fg-info"><div class="fg-label">Fear & Greed</div><div class="fg-rating" style="color:var(--text2);font-size:13px;">Unavailable</div></div>`;
  }
  clearTimeout(_fgTimer);
  _fgTimer = setTimeout(loadFearGreed, 24 * 60 * 60 * 1000);
}

let _cfgTimer = null;
async function loadCryptoFearGreed() {
  const el = document.getElementById('crypto-fear-greed-widget');
  if (!el) return;
  const R = 33, C = 40, FULL = 2 * Math.PI * R;
  el.innerHTML = `<div class="fg-gauge-wrap"><svg width="80" height="80" viewBox="0 0 80 80"><circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="6"/></svg><div class="fg-gauge-text"><span class="fg-score" style="color:var(--text2)">…</span></div></div><div class="fg-info"><div class="fg-label">Crypto Fear & Greed</div><div class="fg-rating" style="color:var(--text2);font-size:13px;">Loading</div></div>`;
  try {
    const jwt = await _getToken();
    const res = await fetch(`${SUPABASE_URL}/functions/v1/crypto-fear-greed`,
      jwt ? { headers: { 'Authorization': `Bearer ${jwt}` } } : {}
    );
    const d = await res.json();
    if (!d.score) throw new Error('no data');
    const score  = Math.round(d.score);
    const key    = (d.rating || '').toLowerCase();
    const colors = FG_COLORS[key] || ['#8faac8','#64748b'];
    const label  = FG_LABELS[key] || d.rating;
    const now    = new Date().toLocaleDateString('en-US', { month:'short', day:'numeric' });
    const dash   = (score / 100) * FULL;
    el.innerHTML = `
      <div class="fg-gauge-wrap">
        <svg width="80" height="80" viewBox="0 0 80 80">
          <circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="6"/>
          <circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="${colors[0]}" stroke-width="6"
            stroke-dasharray="${dash} ${FULL}" stroke-linecap="round"
            style="filter:drop-shadow(0 0 6px ${colors[0]}80)"/>
        </svg>
        <div class="fg-gauge-text">
          <span class="fg-score" style="color:${colors[0]}">${score}</span>
          <span class="fg-score-sub">/100</span>
        </div>
      </div>
      <div class="fg-info">
        <div class="fg-label">Crypto Fear & Greed</div>
        <div class="fg-rating" style="color:${colors[0]}">${label}</div>
        <div class="fg-source">CoinMarketCap · ${now}</div>
      </div>`;
  } catch {
    el.innerHTML = `<div class="fg-gauge-wrap"><svg width="80" height="80" viewBox="0 0 80 80"><circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="6"/></svg><div class="fg-gauge-text"><span class="fg-score" style="color:var(--text2)">—</span></div></div><div class="fg-info"><div class="fg-label">Crypto Fear & Greed</div><div class="fg-rating" style="color:var(--text2);font-size:13px;">Unavailable</div></div>`;
  }
  clearTimeout(_cfgTimer);
  _cfgTimer = setTimeout(loadCryptoFearGreed, 24 * 60 * 60 * 1000);
}

function renderOverview() {
  const now = new Date();
  const om = document.getElementById('ov-month');
  const oy = document.getElementById('ov-year');
  if (om && !om.value) om.value = now.getMonth() + 1;
  if (oy && !oy.value) oy.value = now.getFullYear();
  const {month, year} = getFilter('ov');
  const info = document.getElementById('ov-filter-info');
  if (info) info.textContent = (month||year) ? `${month?months()[+month-1]:''} ${year||''}`.trim() : '';

  let stTrades = filterTrades('stock', month, year);
  let crTrades = filterTrades('crypto', month, year);
  let trades;
  if (ovScope==='stock') trades = stTrades;
  else if (ovScope==='crypto') trades = crTrades;
  else trades = [...stTrades, ...crTrades];

  trades = [...trades].sort((a,b) => new Date(a.entryDate)-new Date(b.entryDate));
  const st    = stats(trades);
  const adv = advancedStats(trades);

  // Trend
  const byMon = {};
  trades.forEach(t => { const k=(t.entryDate||'').slice(0,7); if(k) byMon[k]=(byMon[k]||0)+calcTotal(t); });
  const monKeys = Object.keys(byMon).sort();
  let trendCls='flat', trendLbl='—';
  if (monKeys.length >= 2) {
    const diff = byMon[monKeys[monKeys.length-1]] - byMon[monKeys[monKeys.length-2]];
    trendCls = diff > 0 ? 'up' : diff < 0 ? 'down' : 'flat';
    trendLbl = (diff > 0 ? '▲ ' : diff < 0 ? '▼ ' : '') + fmtUSD(Math.abs(diff)) + ' ' + t('kpi_vs_prev');
  }

  // Avg R
  const withR = trades.filter(tr2 => calcStopRisk(tr2) > 0);
  const avgR  = withR.length ? withR.reduce((s,tr2) => s + calcPL(tr2)/calcStopRisk(tr2), 0) / withR.length : null;

  // Open positions
  const openTrades = [...db.stocks, ...db.crypto].filter(tr2 => !tr2.deleted && !tr2.exitPrice);

  // 5 KPI cards
  const _noTrades = db.stocks.filter(tr=>!tr.deleted).length + db.crypto.filter(tr=>!tr.deleted).length === 0;
  if (_noTrades) {
    document.getElementById('kpi-grid').innerHTML = `
      <div style="grid-column:1/-1;padding:28px 24px;text-align:center;border:1px dashed rgba(129,140,248,0.2);border-radius:14px;background:rgba(129,140,248,0.03);">
        <div style="font-size:15px;font-weight:600;color:var(--text);margin-bottom:6px;">הוסף את הפוזיציה הראשונה שלך</div>
        <div style="font-size:13px;color:var(--text3);line-height:1.6;margin-bottom:18px;">לאחר רישום עסקאות תוכל לצפות כאן בנתוני הביצועים שלך</div>
        <div style="display:flex;justify-content:center;gap:10px;">
          <button onclick="openModal('stock')" style="padding:9px 20px;background:var(--accent);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit;transition:opacity .15s;" onmouseenter="this.style.opacity='.85'" onmouseleave="this.style.opacity='1'">+ מניה</button>
          <button onclick="openModal('crypto')" style="padding:9px 20px;background:rgba(255,255,255,0.07);color:var(--text);border:1px solid rgba(255,255,255,0.1);border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit;transition:opacity .15s;" onmouseenter="this.style.opacity='.85'" onmouseleave="this.style.opacity='1'">+ קריפטו</button>
        </div>
      </div>`;
  } else {
    document.getElementById('kpi-grid').innerHTML = `
    <div class="kpi-card ${st.total>=0?'c-green':'c-red'}">
      <div class="kpi-label">${t('kpi_pnl')}</div>
      <div class="kpi-value ${st.total>=0?'green':'red'} sensitive">${fmtUSD(st.total)}</div>
      <div class="kpi-sub">${st.n} ${t('trades')}</div>
      ${monKeys.length>=2 ? `<div class="kpi-trend ${trendCls} sensitive">${trendLbl}</div>` : ''}
    </div>
    <div class="kpi-card c-yellow" id="kpi-live-card">
      <div class="kpi-label">${t('kpi_live')}</div>
      <div class="kpi-value" id="kpi-live-pl">${t('kpi_calculating')}</div>
      <div class="kpi-sub" id="kpi-live-sub">${openTrades.length} ${t('kpi_open_pos')}</div>
    </div>
    <div class="kpi-card c-blue">
      <div class="kpi-label">${t('kpi_winrate')}</div>
      <div class="kpi-value ${st.wr>=50?'green':'red'} sensitive">${fmt(st.wr,1)}%</div>
      <div class="kpi-sub">${st.wins}W / ${st.losses}L</div>
      <div class="kpi-progress-track"><div class="kpi-progress-bar" style="width:${Math.min(st.wr,100)}%;background:${st.wr>=50?'#2dd4a0':'#ff6b8a'}"></div></div>
    </div>
    <div class="kpi-card ${avgR!==null&&avgR>=0?'c-green':'c-yellow'}">
      <div class="kpi-label">${t('kpi_rr')}</div>
      <div class="kpi-value ${avgR!==null?(avgR>=0?'green':'red'):''} sensitive">${avgR!==null?avgR.toFixed(2)+'R':'—'}</div>
      <div class="kpi-sub">${withR.length ? withR.length+' '+t('kpi_with_stop') : ''}</div>
    </div>
    <div class="kpi-card c-blue">
      <div class="kpi-label">${t('kpi_trades')}</div>
      <div class="kpi-value">${st.n}</div>
    </div>
  `;
    document.querySelectorAll('#kpi-grid .kpi-card').forEach((el, i) => {
      el.style.setProperty('--i', i);
      el.classList.add('animate-in');
    });
  }

  // Calendar
  calendarNav.overview = { year: year ? +year : now.getFullYear(), month: month ? +month : now.getMonth()+1 };
  renderCalendar('all');

  renderCumChart(trades);

  // Live P&L refresh
  if (_ovLiveTimer) clearInterval(_ovLiveTimer);
  _updateLivePL();
  _ovLiveTimer = setInterval(_updateLivePL, 60000);

  applyPrivacy();
}

async function _updateLivePL() {
  const el  = document.getElementById('kpi-live-pl');
  const sub = document.getElementById('kpi-live-sub');
  if (!el) return;
  const open = [...db.stocks, ...db.crypto].filter(t =>
    !t.deleted && (!t.exitPrice || t.exitPrice === 0) && t.symbol && t.entryPrice > 0
  );
  if (!open.length) {
    el.textContent = '$0.00';
    if (sub) sub.textContent = t('kpi_no_open');
    return;
  }
  const key = getFinnhubKey();
  if (!key) { el.textContent = '—'; return; }
  const token = await _getToken();
  const symbols = [...new Set(open.map(t => t.symbol.toUpperCase()))];
  let totalUnreal = 0;
  await Promise.all(symbols.map(async sym => {
    try {
      const r = await fetch(`${SUPABASE_URL}/functions/v1/finnhub?path=quote&symbol=${encodeURIComponent(sym)}`,
        { headers: { 'Authorization': `Bearer ${token}` } });
      const data = await r.json();
      const price = data.c;
      if (!price) return;
      open.filter(t => t.symbol.toUpperCase() === sym).forEach(t => {
        const shares = (t.shares || t.quantity || 0) - (t.closedShares || 0);
        const side = (t.side || '').toLowerCase() === 'short' ? -1 : 1;
        totalUnreal += side * shares * (price - t.entryPrice);
      });
    } catch {}
  }));
  const sign = totalUnreal >= 0 ? '+' : '';
  el.textContent = sign + '$' + Math.abs(totalUnreal).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  el.className = totalUnreal >= 0 ? 'num-green' : 'num-red';
  if (sub) sub.textContent = `${open.length} ${t('kpi_open_pos')} · ${t('kpi_updated')}`;
}

function renderStatistics() {
  _restoreStatsState();
  const { month, year } = getFilter('stats');
  let allTrades = [...db.stocks, ...db.crypto].filter(t => !t.deleted && t.entryDate);
  if (month) allTrades = allTrades.filter(t => +t.entryDate.slice(5, 7) === +month);
  if (year)  allTrades = allTrades.filter(t => +t.entryDate.slice(0, 4) === +year);

  const stTrades = allTrades.filter(t => t.type === 'stock' || !t.type);
  const crTrades = allTrades.filter(t => t.type === 'crypto');

  let trades;
  if (statsScope === 'stock') trades = stTrades;
  else if (statsScope === 'crypto') trades = crTrades;
  else trades = allTrades;

  const st  = stats(trades);
  const adv = advancedStats(trades);

  const closed  = trades.filter(t => t.exitPrice > 0 && t.closedShares > 0);
  const winners = closed.filter(t => calcPL(t) > 0);
  const losers  = closed.filter(t => calcPL(t) <= 0);
  const winSum  = winners.reduce((s, t) => s + calcPL(t), 0);
  const lossSum = Math.abs(losers.reduce((s, t) => s + calcPL(t), 0));
  const pf      = lossSum > 0 ? winSum / lossSum : null;
  const expectancy = closed.length
    ? (st.wr / 100 * adv.avgWin) + ((1 - st.wr / 100) * adv.avgLoss)
    : 0;

  let curW = 0, maxW = 0, curL = 0, maxL = 0;
  [...closed].sort((a, b) => a.entryDate.localeCompare(b.entryDate)).forEach(t => {
    if (calcPL(t) > 0) { curW++; maxW = Math.max(maxW, curW); curL = 0; }
    else               { curL++; maxL = Math.max(maxL, curL); curW = 0; }
  });

  let rSum = 0, rCount = 0;
  closed.forEach(t => {
    const sl = t.stop || 0;
    if (!sl || !t.entryPrice) return;
    const risk = Math.abs(t.entryPrice - sl) * (t.closedShares || t.shares || 0);
    if (risk > 0) { rSum += calcPL(t) / risk; rCount++; }
  });
  const avgR = rCount > 0 ? rSum / rCount : 0;

  // Max Drawdown — equity curve over closed trades, ordered by close date
  const _eqClosed = [...closed].sort((a, b) =>
    (a.closeDate || a.entryDate || '').localeCompare(b.closeDate || b.entryDate || ''));
  let _eq = 0, _peak = 0, maxDD = 0;
  const _ddSeries = [], _ddLabels = [];
  _eqClosed.forEach(t2 => {
    _eq += calcTotal(t2);
    _peak = Math.max(_peak, _eq);
    const dd = _eq - _peak;            // ≤ 0, in $
    maxDD = Math.min(maxDD, dd);
    _ddSeries.push(+dd.toFixed(2));
    _ddLabels.push(fmtDate(t2.closeDate || t2.entryDate));
  });

  const fmt = v => (v >= 0 ? '+' : '') + '$' + Math.abs(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const pct  = v => v.toFixed(1) + '%';

  const kpis = [
    { label: t('st_best'),           value: fmt(st.best),                cls: st.best >= 0 ? 'green' : 'red', sensitive: true },
    { label: t('st_worst'),          value: fmt(st.worst),               cls: st.worst >= 0 ? 'green' : 'red', sensitive: true },
    { label: t('st_avg_trade'),      value: fmt(st.avg),                 cls: st.avg >= 0 ? 'green' : 'red', sensitive: true },
    { label: t('st_avg_win'),        value: fmt(adv.avgWin),             cls: 'green', sensitive: true },
    { label: t('st_avg_loss'),       value: fmt(adv.avgLoss),            cls: 'red', sensitive: true },
    { label: t('st_expectancy'),     value: fmt(expectancy),             cls: expectancy >= 0 ? 'green' : 'red', sensitive: true },
    { label: 'Profit Factor',        value: pf != null ? pf.toFixed(2) : '—', cls: pf != null ? (pf >= 1 ? 'green' : 'red') : '' },
    { label: 'Max Drawdown',         value: maxDD < 0 ? fmt(maxDD) : '$0.00', cls: maxDD < 0 ? 'red' : 'green', sensitive: true },
    { label: t('st_wl_ratio'),       value: adv.avgLoss !== 0 ? Math.abs(adv.avgWin / adv.avgLoss).toFixed(2) + 'x' : '—', cls: '' },
    { label: t('st_max_win_streak'), value: maxW, cls: '' },
    { label: t('st_max_loss_streak'),value: maxL, cls: '' },
    { label: t('st_avg_hold_win'),   value: adv.avgWinDays.toFixed(1) + 'd', cls: '' },
    { label: t('st_avg_hold_loss'),  value: adv.avgLossDays.toFixed(1) + 'd', cls: '' },
    { label: t('st_avg_r'),          value: avgR ? avgR.toFixed(2) + 'R' : '—', cls: avgR >= 1 ? 'green' : '' },
    { label: t('st_win_rate'),       value: pct(st.wr),                  cls: st.wr >= 50 ? 'green' : 'red' },
  ];

  const grid = document.getElementById('stats-kpi-grid');
  if (grid) {
    grid.innerHTML = kpis.map(k => `
      <div class="kpi-card">
        <div class="kpi-label">${k.label}</div>
        <div class="kpi-value ${k.cls}${k.sensitive ? ' sensitive' : ''}">${k.value}</div>
      </div>`).join('');
  }

  renderDonut(st, adv, trades);
  renderDrawdownChart(_ddLabels, _ddSeries);
  renderRHistogram(closed);
  renderMonthlyTracker(trades);
  renderTradingSummary(trades);
  renderComparison(stTrades, crTrades);
  applyPrivacy();
}

// ── Subtle gridline color per design system recommendation ──
// Gridlines: subtle, adapts to both dark/light via dynamic lookup
function getGridColor() { return document.documentElement.getAttribute('data-theme')==='light' ? 'rgba(14,14,18,0.07)' : 'rgba(148,163,184,0.07)'; }
function getTickColor() { return document.documentElement.getAttribute('data-theme')==='light' ? '#64748b' : '#4b6080'; }
const GRID_COLOR  = 'rgba(148,163,184,0.09)';
const TICK_COLOR  = '#8faac8';
const CHART_FONT  = { family: "'Heebo', 'Plus Jakarta Sans', 'Inter', system-ui, sans-serif", size: 12, weight: '500' };

function showChart(skelId, canvasId) {
  const skel = document.getElementById(skelId);
  const canvas = document.getElementById(canvasId);
  if (skel)   skel.style.display = 'none';
  if (canvas) canvas.style.display = '';
}

function chartDefaults(type) {
  const gc = getGridColor(), tc = getTickColor();
  return {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 300 },
    plugins: {
      legend: { labels: { color: tc, font: CHART_FONT } },
      tooltip: { callbacks: {}, backgroundColor: 'rgba(10,18,36,0.92)', titleColor: '#e2e8f0', bodyColor: '#e2e8f0', borderColor: 'rgba(255,255,255,0.1)', borderWidth: 1, padding: 10, cornerRadius: 8 }
    },
    scales: type === 'bar' || type === 'line' ? {
      x: { ticks: { color: tc, font: CHART_FONT }, grid: { color: gc, drawBorder: false } },
      y: { ticks: { color: tc, font: CHART_FONT }, grid: { color: gc, drawBorder: false } }
    } : undefined
  };
}

function destroyChart(id) { if (charts[id]) { charts[id].destroy(); delete charts[id]; } }

let _cumTrades = [];
let _cumMode   = 'pct'; // 'pct' | 'usd'

function setCumMode(mode) {
  _cumMode = mode;
  document.getElementById('cum-mode-pct').style.background = mode === 'pct' ? 'var(--accent)' : 'transparent';
  document.getElementById('cum-mode-pct').style.color      = mode === 'pct' ? '#fff' : 'var(--text3)';
  document.getElementById('cum-mode-usd').style.background = mode === 'usd' ? 'var(--accent)' : 'transparent';
  document.getElementById('cum-mode-usd').style.color      = mode === 'usd' ? '#fff' : 'var(--text3)';
  renderCumChart(_cumTrades);
}

function renderCumChart(trades) {
  _cumTrades = trades;
  destroyChart('cum');

  const f = getFilter('ov');
  const useDaily = !!f.month;

  // Group by day or month
  const byKey = {};
  trades.forEach(t => {
    const d = useDaily ? t.entryDate?.slice(0, 10) : t.entryDate?.slice(0, 7);
    if (!d) return;
    byKey[d] = (byKey[d] || 0) + calcTotal(t);
  });

  const keys = Object.keys(byKey).sort();

  const labelsRaw = keys.map(k => {
    if (useDaily) {
      const [, mo, d] = k.split('-');
      return d + '/' + mo;
    }
    const [y, mo] = k.split('-');
    return months()[+mo-1] + "'" + y.slice(2);
  });
  const labels = ['', ...labelsRaw];

  let cum = 0;
  const cumUsdRaw = keys.map(k => { cum += byKey[k]; return +cum.toFixed(2); });
  const cumUsd = [0, ...cumUsdRaw];

  const base = Math.abs(trades.reduce((s, t) => s + (t.entryPrice || 0) * (t.shares || 0), 0)) || 1;
  let cumPct = 0;
  const cumPctRaw = keys.map(k => { cumPct += byKey[k]; return +(cumPct / base * 100).toFixed(2); });
  const cumPctData = [0, ...cumPctRaw];

  const isPct   = _cumMode === 'pct';
  const data    = isPct ? cumPctData : cumUsd;
  const lastVal = data[data.length - 1] ?? 0;
  const color   = lastVal >= 0 ? '#2dd4a0' : '#ff6b8a';
  const colorRgb = lastVal >= 0 ? '34,197,94' : '239,68,68';

  showChart('skel-cum', 'chart-cum');
  const cumEl = document.getElementById('chart-cum');
  if (!cumEl) return;
  const ctx2d = cumEl.getContext('2d');
  const grad = ctx2d.createLinearGradient(0, 0, 0, cumEl.offsetHeight || 200);
  grad.addColorStop(0,   `rgba(${colorRgb},0.35)`);
  grad.addColorStop(0.5, `rgba(${colorRgb},0.12)`);
  grad.addColorStop(1,   `rgba(${colorRgb},0.00)`);

  charts.cum = new Chart(ctx2d, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: isPct ? 'P&L %' : 'P&L $',
        data,
        borderColor: color,
        backgroundColor: grad,
        tension: 0.4, fill: true,
        pointRadius: data.length > 20 ? 0 : 3,
        pointBackgroundColor: color,
        pointBorderColor: 'rgba(255,255,255,0.6)',
        pointBorderWidth: 1.5,
        pointHoverRadius: 7,
        pointHoverBackgroundColor: color,
        pointHoverBorderColor: '#fff',
        pointHoverBorderWidth: 2,
        borderWidth: 2.5,
      }]
    },
    options: {
      ...chartDefaults('line'),
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(10,18,36,0.95)',
          titleColor: '#94a3b8',
          bodyColor: '#f1f5f9',
          borderColor: 'rgba(255,255,255,0.12)',
          borderWidth: 1,
          padding: 10,
          cornerRadius: 8,
          displayColors: false,
          callbacks: {
            title: c => c[0]?.label || '',
            label: c => {
              const v = +c.raw;
              const sign = v >= 0 ? '+' : '';
              return isPct ? ` ${sign}${v.toFixed(2)}%` : ` ${sign}$${v.toFixed(2)}`;
            }
          }
        }
      },
      layout: { padding: { top: 8, right: 70, bottom: 0, left: 0 } },
      scales: {
        x: { ticks: { color: TICK_COLOR, font: CHART_FONT, maxTicksLimit: 8 }, grid: { color: GRID_COLOR, drawBorder: false } },
        y: { ticks: { color: TICK_COLOR, font: CHART_FONT, callback: v => isPct ? (+v).toFixed(1) + '%' : '$' + (+v).toFixed(2) }, grid: { color: GRID_COLOR, drawBorder: false } }
      }
    }
  });
}

function renderDonut(st, adv, trades) {
  destroyChart('donut');
  showChart('skel-donut', 'chart-donut');
  const donutEl = document.getElementById('chart-donut'); if (!donutEl) return;
  const ctx = donutEl.getContext('2d');
  charts.donut = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: [t('donut_win'), t('donut_loss')],
      datasets: [{
        data: [st.wins || 0, st.losses || 0],
        backgroundColor: ['#2dd4a0', '#ff6b8a'],
        borderColor: 'rgba(0,0,0,0)',
        borderWidth: 0,
        hoverOffset: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: { label: c => ` ${c.label}: ${c.raw} (${st.n ? (c.raw/st.n*100).toFixed(1) : 0}%)` }
        }
      },
      cutout: '70%',
      animation: { duration: 300 }
    }
  });

  // ── Compute extra stats ──────────────────────────
  const sorted = [...(trades||[])].sort((a,b) => (a.entryDate||'').localeCompare(b.entryDate||''));
  let maxWinStreak=0, maxLossStreak=0, curW=0, curL=0;
  sorted.forEach(t => {
    const pl = calcPL(t);
    if (pl > 0) { curW++; curL=0; maxWinStreak=Math.max(maxWinStreak,curW); }
    else if (pl < 0) { curL++; curW=0; maxLossStreak=Math.max(maxLossStreak,curL); }
  });
  const winSum  = sorted.reduce((s,t)=>{ const v=calcPL(t); return v>0?s+v:s; },0);
  const lossSum = Math.abs(sorted.reduce((s,t)=>{ const v=calcPL(t); return v<0?s+v:s; },0));
  const pf = lossSum > 0 ? (winSum/lossSum) : null;
  const wlRatio = adv && adv.avgLoss && adv.avgLoss !== 0 ? Math.abs(adv.avgWin / adv.avgLoss) : null;

  const none = '—';
  const pfStr  = pf    !== null ? pf.toFixed(2)    : none;
  const pfCls  = pf    !== null ? (pf >= 1 ? 'green' : 'red') : '';
  const wlStr  = wlRatio !== null ? wlRatio.toFixed(2)+'x' : none;
  const wlCls  = wlRatio !== null ? (wlRatio >= 1 ? 'green' : 'red') : '';
  const bestStr  = st.n ? fmtUSD(st.best)  : none;
  const worstStr = st.n ? fmtUSD(st.worst) : none;

  const el = document.getElementById('donut-stats');
  if (el) el.innerHTML = `
    <div class="donut-stat">
      <div class="donut-stat-label">Profit Factor</div>
      <div class="donut-stat-value ${pfCls} sensitive">${pfStr}</div>
    </div>
    <div class="donut-stat">
      <div class="donut-stat-label">W/L Ratio</div>
      <div class="donut-stat-value ${wlCls} sensitive">${wlStr}</div>
    </div>
    <div class="donut-stat">
      <div class="donut-stat-label">${t('donut_best')}</div>
      <div class="donut-stat-value green sensitive">${bestStr}</div>
    </div>
    <div class="donut-stat">
      <div class="donut-stat-label">${t('donut_worst')}</div>
      <div class="donut-stat-value red sensitive">${worstStr}</div>
    </div>
    <div class="donut-stat">
      <div class="donut-stat-label">${t('donut_win_streak')}</div>
      <div class="donut-stat-value sky">${maxWinStreak || none}</div>
    </div>
    <div class="donut-stat">
      <div class="donut-stat-label">${t('donut_loss_streak')}</div>
      <div class="donut-stat-value gold">${maxLossStreak || none}</div>
    </div>`;
  applyPrivacy();
}

let _compScopeData = { st: [], cr: [] };
let _compScope = 'all';

function _renderCompBody(scope) {
  const tr = scope === 'stock' ? _compScopeData.st
           : scope === 'crypto' ? _compScopeData.cr
           : [..._compScopeData.st, ..._compScopeData.cr];
  const accentColor = scope === 'stock' ? '#818cf8' : scope === 'crypto' ? '#f59e0b' : '#4f83ff';
  const st = stats(tr);
  const adv = advancedStats(tr);
  const winSum  = tr.reduce((s,x)=>{ const v=calcPL(x); return v>0?s+v:s; },0);
  const lossSum = Math.abs(tr.reduce((s,x)=>{ const v=calcPL(x); return v<0?s+v:s; },0));
  const pf    = lossSum>0 ? (winSum/lossSum).toFixed(2) : '—';
  const pfCls = lossSum>0 ? (winSum/lossSum>=1?'num-green':'num-red') : '';
  const wl    = adv.avgLoss!==0 ? Math.abs(adv.avgWin/adv.avgLoss).toFixed(2)+'x' : '—';
  const pills = [
    { key:'all',    label: t('scope_all')    || 'הכל' },
    { key:'stock',  label: t('comp_stocks')?.replace(/^.*\s/,'') || 'מניות' },
    { key:'crypto', label: t('comp_crypto')?.replace(/^.*\s/,'') || 'קריפטו' },
  ].map(p => `<button class="comp-scope-pill${p.key===scope?' active':''}" onclick="_switchCompScope('${p.key}')">${p.label}</button>`).join('');
  document.getElementById('comp-card-inner').innerHTML = `
    <div class="comp-scope-pills">${pills}</div>
    <div class="comp-stat"><span class="comp-stat-label">${t('comp_total_pl')}</span><span class="comp-stat-val ${clr(st.total)} sensitive">${st.n?fmtUSD(st.total):'—'}</span></div>
    <div class="comp-stat"><span class="comp-stat-label">Win Rate</span>
      <span class="comp-stat-val"><span class="${st.wr>=50?'num-green':'num-red'}">${fmt(st.wr,1)}%</span>
      <span style="color:var(--text3);font-size:11px;margin-right:5px;">${st.wins}W / ${st.losses}L</span></span>
    </div>
    <div class="comp-stat"><span class="comp-stat-label">Profit Factor</span><span class="comp-stat-val ${pfCls} sensitive">${pf}</span></div>
    <div class="comp-stat"><span class="comp-stat-label">W/L Ratio</span><span class="comp-stat-val sensitive">${wl}</span></div>
    <div class="comp-stat"><span class="comp-stat-label">${t('comp_avg_win')}</span><span class="comp-stat-val num-green sensitive">${st.wins?fmtUSD(adv.avgWin):'—'}</span></div>
    <div class="comp-stat"><span class="comp-stat-label">${t('comp_avg_loss')}</span><span class="comp-stat-val num-red sensitive">${st.losses?fmtUSD(adv.avgLoss):'—'}</span></div>
    <div class="comp-stat"><span class="comp-stat-label">${t('comp_best')}</span><span class="comp-stat-val num-green sensitive">${st.n?fmtUSD(st.best):'—'}</span></div>
    <div class="comp-stat"><span class="comp-stat-label">${t('comp_worst')}</span><span class="comp-stat-val num-red sensitive">${st.n?fmtUSD(st.worst):'—'}</span></div>
    <div class="comp-stat"><span class="comp-stat-label">${t('comp_avg_trade')}</span><span class="comp-stat-val ${clr(st.avg)} sensitive">${st.n?fmtUSD(st.avg):'—'}</span></div>
    <div class="comp-stat"><span class="comp-stat-label">${t('comp_trades')}</span><span class="comp-stat-val">${st.n}</span></div>
  `;
  document.getElementById('comp-card-wrap').style.borderTopColor = accentColor;
  applyPrivacy();
}

function _switchCompScope(scope) {
  _compScope = scope;
  _renderCompBody(scope);
}

function renderComparison(stTrades, crTrades) {
  _compScopeData = { st: stTrades, cr: crTrades };
  document.getElementById('comparison-wrap').innerHTML =
    `<div class="comp-card" id="comp-card-wrap" style="border-top:2px solid #4f83ff;"><div id="comp-card-inner"></div></div>`;
  _renderCompBody(_compScope);
}

// ─────────────────────────────────────────────
// MODAL
// ─────────────────────────────────────────────
function openModal(type, tr=null) {
  document.getElementById('tgt-list').innerHTML = '';
  document.getElementById('m-type').value = type;
  document.getElementById('modal-title').textContent = tr ? t('modal_edit') : t('modal_add');
  document.getElementById('m-id').value = tr ? tr.id : '';

  const today = new Date().toISOString().split('T')[0];
  document.getElementById('m-entryDate').value   = tr ? (tr.entryDate||'')    : today;
  document.getElementById('m-ls').value          = tr ? (tr.ls||'L')           : 'L';
  document.getElementById('m-symbol').value      = tr ? (tr.symbol||'')        : '';
  document.getElementById('m-entryPrice').value  = tr ? (tr.entryPrice||'')    : '';
  document.getElementById('m-shares').value      = tr ? (tr.shares||'')        : '';
  document.getElementById('m-stop').value        = tr ? (tr.stop||'')          : '';
  document.getElementById('m-closeDate').value   = tr ? (tr.closeDate||'')     : '';
  document.getElementById('m-closedShares').value= tr ? (tr.closedShares||'')  : '';
  document.getElementById('m-exitPrice').value   = tr ? (tr.exitPrice||'')     : '';
  document.getElementById('m-commission').value  = tr ? (tr.commission!==undefined?tr.commission:'5.00') : '5.00';
  modalER = tr ? (tr.entryReason || '') : '';
  document.getElementById('m-entry-reason').value = modalER;
  erSetPills('m-er-pills', modalER);
  document.getElementById('m-market-cond').value = tr ? (tr.marketCond || '') : '';
  modalPS = tr ? (tr.processScore || 0) : 0;
  const psEl = document.getElementById('m-process-score');
  if (psEl) psEl.value = modalPS;
  psSetStars('m-ps-stars', modalPS);
  const moodEl = document.getElementById('m-mood');
  if (moodEl) moodEl.value = tr ? (tr.mood || '') : '';
  document.getElementById('m-notes-keep').value  = tr ? (tr.notes_keep||'')    : '';
  document.getElementById('m-notes-improve').value = tr ? (tr.notes_improve||'') : '';

  if (tr && tr.t) tr.t.forEach(tg => addTarget(tg));
  updateAddTgtBtn();
  liveCalc();
  mAutoType(); // sync badge with current symbol
  document.getElementById('trade-modal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('trade-modal').classList.remove('open');
  document.body.style.overflow = '';
}

function onOverlayClick(e) {
  if (e.target === document.getElementById('trade-modal')) closeModal();
}

function addTarget(data=null) {
  const list = document.getElementById('tgt-list');
  const n = list.querySelectorAll('.target-row').length;
  if (n >= 5) { toast('מקסימום 5 יעדים','error'); return; }
  const idx = n + 1;
  const div = document.createElement('div');
  div.className = 'target-row';
  div.innerHTML = `
    <div>
      <div class="target-lbl">T${idx} — מס' מניות</div>
      <input type="number" class="form-control" value="${data?data.shares:''}" placeholder="0" oninput="liveCalc()">
    </div>
    <div>
      <div class="target-lbl">T${idx} — מחיר יציאה</div>
      <input type="number" class="form-control" value="${data?data.price:''}" placeholder="0.00" step="0.0001" oninput="liveCalc()">
    </div>
    <button class="target-remove" onclick="removeTarget(this)" title="הסר">✕</button>
  `;
  list.appendChild(div);
  updateAddTgtBtn();
  liveCalc();
}

function removeTarget(btn) {
  btn.closest('.target-row').remove();
  // re-label
  document.querySelectorAll('#tgt-list .target-row').forEach((r,i) => {
    r.querySelectorAll('.target-lbl').forEach((l,j) => {
      l.textContent = `T${i+1} — ${j===0?"מס' מניות":'מחיר יציאה'}`;
    });
  });
  updateAddTgtBtn();
  liveCalc();
}

function updateAddTgtBtn() {
  const btn = document.getElementById('add-tgt-btn');
  const n = document.querySelectorAll('#tgt-list .target-row').length;
  if (btn) btn.style.display = n>=5 ? 'none' : '';
}

function getTargets() {
  const rows = document.querySelectorAll('#tgt-list .target-row');
  const out = [];
  rows.forEach(r => {
    const ins = r.querySelectorAll('input');
    const s = +ins[0].value, p = +ins[1].value;
    if (s > 0 && p > 0) out.push({shares:s, price:p});
  });
  return out;
}

function getFormTrade() {
  // ניקוי וולידציה של כל שדה לפני שמירה
  const rawSymbol = document.getElementById('m-symbol').value.toUpperCase().trim();
  const cleanSymbol = rawSymbol.replace(/[^A-Z0-9._\-]/g, '').slice(0, 20);
  const ls = document.getElementById('m-ls').value;
  const safeLs = ['L','S'].includes(ls) ? ls : 'L';

  return {
    entryDate:    document.getElementById('m-entryDate').value.slice(0,10),
    ls:           safeLs,
    symbol:       cleanSymbol,
    entryPrice:   sanitizeNumber(document.getElementById('m-entryPrice').value, 0),
    shares:       sanitizeNumber(document.getElementById('m-shares').value, 0, 1e7),
    stop:         sanitizeNumber(document.getElementById('m-stop').value, 0),
    t:            getTargets(),
    closeDate:    document.getElementById('m-closeDate').value.slice(0,10),
    closedShares: sanitizeNumber(document.getElementById('m-closedShares').value, 0, 1e7),
    exitPrice:    sanitizeNumber(document.getElementById('m-exitPrice').value, 0),
    ecn:          0,
    commission:   document.getElementById('m-commission').value !== ''
                    ? sanitizeNumber(document.getElementById('m-commission').value, 0, 1e6)
                    : 2.5,
    notes_keep:    sanitizeText(document.getElementById('m-notes-keep').value, 500),
    notes_improve: sanitizeText(document.getElementById('m-notes-improve').value, 500),
    entry_reason:  ER_OPTIONS.includes(modalER) ? modalER : '',
    market_cond:   document.getElementById('m-market-cond').value || '',
    process_score: modalPS || 0,
    mood:          (document.getElementById('m-mood').value || '').trim().slice(0, 300)
  };
}

function liveCalc() {
  const tr = getFormTrade();
  const pl = calcPL(tr);
  const tot = calcTotal(tr);
  const risk = calcRisk(tr);
  const pct = risk ? (tot/risk*100) : 0;

  const set = (id, val, colorFn) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = val;
    if (colorFn !== undefined) el.style.color = colorFn;
  };

  const plColor = pl >= 0 ? 'var(--green)' : 'var(--red)';
  const totColor = tot >= 0 ? 'var(--green)' : 'var(--red)';
  const pctColor = pct >= 0 ? 'var(--green)' : 'var(--red)';

  set('cp-pl', fmtUSD(pl), plColor);
  set('cp-total', fmtUSD(tot), totColor);
  set('cp-risk', risk ? '$'+fmt(risk,0) : '—', 'var(--yellow)');
  set('cp-pct', fmtPct(pct), pctColor);
}

async function saveTrade() {
  const type = document.getElementById('m-type').value;
  const idVal = document.getElementById('m-id').value;
  const data = getFormTrade();

  if (!data.symbol)     { toast('נא להזין סימבול','error'); return; }
  if (!data.entryDate)  { toast('נא להזין תאריך כניסה','error'); return; }
  if (!data.entryPrice) { toast('נא להזין שער כניסה','error'); return; }

  data.type = type;
  const arr = type==='stock' ? db.stocks : db.crypto;

  if (idVal) {
    // Edit existing trade
    const i = arr.findIndex(t=>String(t.id)===String(idVal));
    if (i === -1) { toast('שגיאה: עסקה לא נמצאה','error'); return; }
    const prev = arr[i];
    data.id = prev.id;
    arr[i] = data; // optimistic
    renderTable(type); initFilters(); closeModal();
    const row = _tradeToRow(data);
    const { error } = await _sb.from('trades').update(row).eq('id', data.id).eq('user_id', _currentUser.id);
    if (error) { arr[i] = prev; renderTable(type); toast('שגיאה בעדכון עסקה','error'); console.error(error); return; }
    auditLog('trade_edited', data.symbol);
    toast('עסקה עודכנה','success');
  } else {
    // New trade
    const row = _tradeToRow(data);
    closeModal();
    const { data: inserted, error } = await _sb.from('trades').insert(row).select().single();
    if (error) { toast('שגיאה בהוספת עסקה','error'); console.error(error); return; }
    data.id = inserted.id;
    arr.push(data);
    auditLog('trade_added', data.symbol);
    renderTable(type); initFilters();
    toast('עסקה נוספה','success');
  }
}

function editTrade(type, id) {
  const arr = type==='stock' ? db.stocks : db.crypto;
  const tr = arr.find(t=>String(t.id)===String(id));
  if (tr) openModal(type, tr);
}

async function deleteTrade(type, id) {
  if (!confirm('למחוק עסקה זו? היא תועבר לאשפה')) return;
  const arr = type==='stock' ? db.stocks : db.crypto;
  const tr = arr.find(t => String(t.id) === String(id));
  if (!tr) return;
  // Optimistic
  tr.deleted = true;
  tr.deletedAt = new Date().toISOString();
  renderTable(type);
  toast('עסקה נמחקה', 'success');
  const { error } = await _sb.from('trades')
    .update({ deleted: true, deleted_at: new Date().toISOString() })
    .eq('id', tr.id).eq('user_id', _currentUser.id);
  if (error) {
    tr.deleted = false; tr.deletedAt = null;
    renderTable(type);
    toast('שגיאה במחיקה','error');
    console.error(error);
    return;
  }
  auditLog('trade_deleted', `${tr.symbol} #${tr.id}`);
}

// ─────────────────────────────────────────────
// CALCULATORS
// ─────────────────────────────────────────────
function calcPS() {
  const account  = +document.getElementById('ps-account').value;
  const riskPct  = +document.getElementById('ps-riskpct').value;
  let   risk     = +document.getElementById('ps-risk').value;
  const entry    = +document.getElementById('ps-entry').value;
  const stop     = +document.getElementById('ps-stop').value;
  const dir      = document.getElementById('ps-dir').value;
  const result   = document.getElementById('ps-result');

  // Auto-fill risk $ from account + risk%
  if (account > 0 && riskPct > 0) {
    risk = account * riskPct / 100;
    document.getElementById('ps-risk').value = risk.toFixed(2);
  }

  if (!risk||!entry||!stop||entry<=0||stop<=0) { result.style.display='none'; return; }
  const stopDist = Math.abs(entry-stop);
  if (!stopDist) { result.style.display='none'; return; }
  if (dir==='L' && stop>=entry) { result.style.display='none'; return; }
  if (dir==='S' && stop<=entry) { result.style.display='none'; return; }

  const shares = Math.floor(risk/stopDist);
  document.getElementById('ps-shares').textContent = shares.toLocaleString();
  document.getElementById('ps-sdollar').textContent = '$'+stopDist.toFixed(4);
  document.getElementById('ps-size').textContent = '$'+(shares*entry).toFixed(2);
  document.getElementById('ps-spct').textContent = (stopDist/entry*100).toFixed(2)+'%';
  result.style.display = 'block';
}

function calcPctChange() {
  const from = +document.getElementById('pct-from').value;
  const to   = +document.getElementById('pct-to').value;
  const result = document.getElementById('pct-result');
  if (!from) { result.style.display='none'; return; }
  const pct = (to-from)/from*100;
  const usd = to-from;
  const pEl = document.getElementById('pct-pct');
  const uEl = document.getElementById('pct-usd');
  pEl.textContent = fmtPct(pct);
  pEl.style.color = pct>=0?'var(--green)':'var(--red)';
  uEl.textContent = fmtUSD(usd);
  uEl.style.color = usd>=0?'var(--green)':'var(--red)';
  result.style.display = 'block';
}

function calcRM() {
  const entry  = +document.getElementById('rm-entry').value;
  const stop   = +document.getElementById('rm-stop').value;
  const target = +document.getElementById('rm-target').value;
  const result = document.getElementById('rm-result');
  if (!entry||!stop||!target) { result.style.display='none'; return; }
  const r = Math.abs(entry-stop);
  const rw = Math.abs(target-entry);
  if (!r) { result.style.display='none'; return; }
  const ratio = rw/r;
  const isLong = entry > stop;

  // Gauge: cap at 4R for visual
  const gaugePct = Math.min(ratio/4*100, 100);
  const gaugeColor = ratio>=3?'var(--green)':ratio>=2?'#2dd4a0':ratio>=1?'var(--yellow)':'var(--red)';
  const gaugeFill = document.getElementById('rm-gauge-fill');
  gaugeFill.style.width = gaugePct+'%';
  gaugeFill.style.background = gaugeColor;

  const rEl = document.getElementById('rm-r');
  rEl.textContent = ratio.toFixed(2)+'R';
  rEl.style.color = gaugeColor;

  // T2 = entry + 2R, T3 = entry + 3R
  const dir = isLong ? 1 : -1;
  const t2 = entry + dir*r*2;
  const t3 = entry + dir*r*3;

  document.getElementById('rm-risk').textContent = '$'+r.toFixed(4)+'/מניה';
  document.getElementById('rm-reward').textContent = '$'+rw.toFixed(4)+'/מניה ('+ratio.toFixed(2)+'R)';
  document.getElementById('rm-t2').textContent = '$'+t2.toFixed(2);
  document.getElementById('rm-t3').textContent = '$'+t3.toFixed(2);
  result.style.display = 'block';
}

function calcBreakeven() {
  const loss = +document.getElementById('be-loss').value || 10;
  document.getElementById('be-pct-display').textContent = loss+'%';
  document.getElementById('be-loss-val').textContent = '-'+loss+'%';

  const needed = (loss/(100-loss)*100);
  document.getElementById('be-need-val').textContent = '+'+needed.toFixed(1)+'%';

  const msgEl = document.getElementById('be-message');
  if (loss <= 5)       msgEl.textContent = 'הפסד קטן — קל להחזיר. שמור על גודל פוזיציה נכון.';
  else if (loss <= 10) msgEl.textContent = 'הפסד ניהול נסבל. מינרוויני: לא לנקום על ההפסד.';
  else if (loss <= 20) msgEl.textContent = 'קשה להחזיר. חשוב לחתוך הפסדים מוקדם.';
  else if (loss <= 30) msgEl.textContent = '⚠ הפסד גדול מאוד. צריך ריצה מצוינת רק כדי לחזור.';
  else                 msgEl.textContent = '🚨 הרסני. כלל מינרוויני: לעולם אל תפסיד יותר מ-7-8% בעסקה.';
}

// ─────────────────────────────────────────────
// EXPORT
// ─────────────────────────────────────────────
const csvSafe = s => {
  const str = String(s == null ? '' : s);
  const escaped = str.replace(/"/g, '""');
  return /^[=+\-@\t]/.test(escaped) ? `"\t${escaped}"` : `"${escaped}"`;
};
function exportCSV(type) {
  const all = type === 'stock'  ? db.stocks.map(t=>({...t,assetType:'stock'}))
            : type === 'crypto' ? db.crypto.map(t=>({...t,assetType:'crypto'}))
            : [
                ...db.stocks.map(t=>({...t,assetType:'stock'})),
                ...db.crypto.map(t=>({...t,assetType:'crypto'}))
              ];
  if (!all.length) { toast('אין נתונים לייצוא','error'); return; }

  const hdrs = ['ID','סוג','תאריך כניסה','L/S','סיבת כניסה','סימבול','שער כניסה','מניות','סטופ','יעדים','תאריך סגירה','מניות סגירה','מחיר יציאה','סקטור','עמלה','P/L','סה"כ','$ בעסקה','% תשואה','מה לשמר','מה לשפר'];
  const rows = all.map(t => {
    const pl  = calcPL(t);
    const tot = calcTotal(t);
    const risk= calcRisk(t);
    const pct = risk ? tot/risk*100 : 0;
    const tgts= (t.t||[]).map((tg,i)=>`T${i+1}:${tg.shares}@${tg.price}`).join(';');
    return [
      t.id, t.assetType, t.entryDate, t.ls, csvSafe(t.entry_reason||''), csvSafe(t.symbol),
      t.entryPrice, t.shares, t.stop, tgts,
      t.closeDate, t.closedShares, t.exitPrice,
      csvSafe(SECTOR_MAP[(t.symbol||'').toUpperCase().replace(/USDT\.P|USDT|\.P$/,'')] || ''), t.commission,
      pl.toFixed(2), tot.toFixed(2), risk.toFixed(2), pct.toFixed(2),
      csvSafe(t.notes_keep||''),
      csvSafe(t.notes_improve||'')
    ];
  });

  const csv = '\uFEFF' + [hdrs, ...rows].map(r=>r.join(',')).join('\n');
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const suffix = type === 'stock' ? '-stocks' : type === 'crypto' ? '-crypto' : '';
  a.href=url; a.download=`trading-journal${suffix}-${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  auditLog('export_csv');
  toast('CSV יוצא בהצלחה','success');
}

// ─────────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────────
function toast(msg, type='success') {
  const c = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  // שימוש ב-textContent ולא innerHTML למניעת XSS
  const icon = document.createElement('span');
  icon.textContent = type === 'success' ? '✅' : '❌';
  el.appendChild(icon);
  el.appendChild(document.createTextNode(' ' + String(msg).slice(0, 100)));
  c.appendChild(el);
  setTimeout(()=>{ el.style.transition='opacity 0.3s, transform 0.3s'; el.style.opacity='0'; el.style.transform='translateX(-16px)'; setTimeout(()=>el.remove(),300); }, 3000);
}

// ─────────────────────────────────────────────
// KEYBOARD
// ─────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (document.getElementById('ss-lightbox')?.classList.contains('open')) { closeLightbox(); return; }
  if (document.getElementById('sector-modal')?.style.display === 'block') { sectorModalClose(); return; }
  if (document.getElementById('inv-position-modal')?.classList.contains('open')) { invClosePositionModal(); return; }
  if (document.getElementById('cal-trade-modal')?.classList.contains('open')) { closeCalTradeModal(); return; }
  if (document.getElementById('ss-modal')?.classList.contains('open')) { closeSSModal(); return; }
  if (document.getElementById('qa-modal')?.classList.contains('open')) { fabToggle(); return; }
  closeModal();
});

// Focus trap (WCAG 2.4.3) — keep keyboard focus inside the open modal.
function _topOpenModal() {
  for (const id of ['trade-modal','qa-modal','cal-trade-modal','ss-modal','inv-position-modal']) {
    const el = document.getElementById(id);
    if (el && el.classList.contains('open')) return el;
  }
  const sm = document.getElementById('sector-modal');
  return (sm && sm.style.display === 'block') ? sm : null;
}
document.addEventListener('keydown', e => {
  if (e.key !== 'Tab') return;
  const modal = _topOpenModal();
  if (!modal) return;
  const list = Array.from(modal.querySelectorAll(
    'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'
  )).filter(el => el.offsetParent !== null);
  if (!list.length) return;
  const first = list[0], last = list[list.length - 1];
  if (!modal.contains(document.activeElement)) { e.preventDefault(); first.focus(); return; }
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
});

// ══════════════════════════════════════════════
// PIN LOCK — נעילת יומן עם קוד PIN
// ══════════════════════════════════════════════
const PIN_KEY        = 'tj-pin-hash';
const PIN_SETUP_KEY  = 'tj-pin-setup';
const AUTO_LOCK_MS   = 10 * 60 * 1000;   // 10 דקות חוסר פעילות
const WARN_BEFORE_MS = 2 * 60 * 1000;     // אזהרה 2 דקות לפני

let pinBuffer        = '';
let pinSetupMode     = false;
let pinSetupFirst    = '';
let lastActivity     = Date.now();
let autoLockTimer    = null;
let countdownTimer   = null;

// PBKDF2 PIN hash via SubtleCrypto — military-grade KDF, 200k iterations
// Format stored: "pbkdf2v3:<hex-salt>:<hex-hash>"
const PIN_PBKDF2_ITERATIONS = 200000;
const PIN_PBKDF2_PREFIX     = 'pbkdf2v3:';

async function hashPIN(pin) {
  // Generate a random 16-byte salt each time (stored alongside hash)
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const km   = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: PIN_PBKDF2_ITERATIONS, hash: 'SHA-256' },
    km, 256
  );
  const hex  = s => Array.from(new Uint8Array(s)).map(b => b.toString(16).padStart(2,'0')).join('');
  return PIN_PBKDF2_PREFIX + hex(salt) + ':' + hex(bits);
}

async function verifyPIN(pin, stored) {
  if (!stored) return false;
  // Legacy v2: plain SHA-256 hex (64 chars) — migrate on verify
  if (!stored.startsWith(PIN_PBKDF2_PREFIX)) {
    // Legacy unsalted hash accepted only during the migration window.
    // After the deadline the hash is wiped and the user re-creates a PIN (PBKDF2).
    if (Date.now() > new Date('2026-09-01T00:00:00Z').getTime()) {
      localStorage.removeItem(PIN_KEY);
      localStorage.removeItem(PIN_SETUP_KEY);
      return false;
    }
    const legacyHash = await _sha256Legacy(pin);
    return legacyHash === stored;
  }
  // v3 PBKDF2 — extract salt and re-derive
  const parts = stored.split(':');
  if (parts.length !== 3) return false;
  const salt = new Uint8Array(parts[1].match(/../g).map(h => parseInt(h, 16)));
  const km   = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(pin), 'PBKDF2', false, ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: PIN_PBKDF2_ITERATIONS, hash: 'SHA-256' },
    km, 256
  );
  const hex  = Array.from(new Uint8Array(bits)).map(b => b.toString(16).padStart(2,'0')).join('');
  return hex === parts[2];
}

// SHA-256 fallback for legacy hash comparison only (not stored)
async function _sha256Legacy(pin) {
  const buf = await crypto.subtle.digest(
    'SHA-256', new TextEncoder().encode('trading-journal-pin-v2:' + pin)
  );
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

// Detect and migrate: FNV-style (≤8 hex chars) and SHA-256 v2 (64 hex chars) → force re-hash on next login
function migrateOldPIN() {
  const stored = localStorage.getItem(PIN_KEY);
  if (!stored) return false;
  // FNV hash (legacy v1) — too weak, force reset
  if (stored.length <= 8) {
    localStorage.removeItem(PIN_KEY);
    localStorage.removeItem(PIN_SETUP_KEY);
    toast('אבטחה שודרגה — נדרש הגדרת קוד PIN מחדש', 'warning');
    return true;
  }
  // SHA-256 v2 (64 hex chars, no prefix) — will be silently upgraded to PBKDF2 on next successful login
  // No action needed here; verifyPIN() handles the comparison and pinUnlock() re-stores with hashPIN()
  return false;
}

function hasPIN() { return !!localStorage.getItem(PIN_KEY); }

function pinUpdateDots(color = null) {
  for (let i = 0; i < 4; i++) {
    const d = document.getElementById('pd' + i);
    d.className = 'pin-dot' + (i < pinBuffer.length ? ' filled' : '') + (color ? ' ' + color : '');
  }
}

function pinMsg(msg) { document.getElementById('pin-msg').textContent = msg; }
function pinClear()     { pinBuffer = ''; pinUpdateDots(); pinMsg(''); }

function pinPress(digit) {
  if (isLockedOut()) { showLockoutMsg(); return; }
  // Anti-bot: block suspiciously fast key presses (< 80ms = automated)
  const now = Date.now();
  if (pinBuffer.length > 0 && now - _lastPinAttempt < 80) return;
  _lastPinAttempt = now;
  if (pinBuffer.length >= 4) return;
  pinBuffer += digit;
  pinUpdateDots();
  if (pinBuffer.length === 4) {
    setTimeout(async () => {
      if (pinSetupMode) {
        if (!pinSetupFirst) {
          pinSetupFirst = pinBuffer;
          pinBuffer = '';
          pinUpdateDots();
          document.getElementById('pin-sub-text').textContent = 'הכנס שוב לאישור';
          pinMsg('');
        } else {
          if (pinBuffer === pinSetupFirst) {
            localStorage.setItem(PIN_KEY, await hashPIN(pinBuffer));
            localStorage.setItem(PIN_SETUP_KEY, '1');
            setPinAttempts(0);
            pinBuffer = ''; pinSetupFirst = '';
            pinSetupMode = false;
            pinMsg('');
            pinUnlock();
            // Re-encrypt stored credentials with new PIN-derived key
            reEncryptCredentials().catch(e => console.warn('[Security] re-encrypt failed:', e));
            toast('קוד PIN הוגדר בהצלחה ✅','success');
          } else {
            pinBuffer = ''; pinSetupFirst = '';
            pinUpdateDots('error');
            pinMsg('הקודים אינם תואמים — נסה שוב');
            document.getElementById('pin-sub-text').textContent = 'הכנס קוד חדש';
            setTimeout(() => pinUpdateDots(), 700);
          }
        }
      } else {
        if (await verifyPIN(pinBuffer, localStorage.getItem(PIN_KEY))) {
          // Silently upgrade legacy SHA-256 hash to PBKDF2 on successful login
          const stored = localStorage.getItem(PIN_KEY);
          if (stored && !stored.startsWith(PIN_PBKDF2_PREFIX)) {
            localStorage.setItem(PIN_KEY, await hashPIN(pinBuffer));
            reEncryptCredentials().catch(e => console.warn('[Security] re-encrypt after upgrade:', e));
          }
          setPinAttempts(0);
          localStorage.removeItem(PIN_LOCKOUT_KEY);
          pinBuffer = '';
          pinMsg('');
          auditLog('pin_correct');
          // If TOTP enabled → second factor step
          if (totpEnabled()) { await totpStep(); }
          else { auditLog('pin_unlocked'); pinUnlock(); }
        } else {
          // Anti-bot: enforce minimum interval between attempts
          const now = Date.now();
          if (now - _lastPinAttempt < MIN_ATTEMPT_INTERVAL_MS) { pinBuffer = ''; return; }
          _lastPinAttempt = now;
          pinUpdateDots('error');
          const attempts = getPinAttempts() + 1;
          setPinAttempts(attempts);
          auditLog('pin_failed', String(attempts));
          if (attempts >= MAX_ATTEMPTS) {
            const lockMs = getLockoutDuration(attempts);
            localStorage.setItem(PIN_LOCKOUT_KEY, String(Date.now() + lockMs));
            // Don't reset attempts — keep accumulating for exponential backoff
            auditLog('pin_lockout', `${Math.round(lockMs/60000)}min`);
            pinMsg('');
            showLockoutMsg();
          } else {
            pinMsg(`קוד שגוי — נסה שוב (${attempts}/${MAX_ATTEMPTS})`);
          }
          pinBuffer = '';
          setTimeout(() => pinUpdateDots(), 700);
        }
      }
    }, 80);
  }
}

function pinBackspace() {
  if (pinBuffer.length > 0) { pinBuffer = pinBuffer.slice(0,-1); pinUpdateDots(); pinMsg(''); }
}

function pinUnlock() {
  const overlay = document.getElementById('pin-overlay');
  if (overlay) overlay.classList.remove('open');
  document.body.style.overflow = '';
  lastActivity = Date.now();
  startAutoLock();
  const link = document.getElementById('pin-toggle-link');
  if (link) link.textContent = hasPIN() ? 'שנה / מחק PIN' : 'הגדר קוד PIN';
  // Auto-sync Flex + Bybit on unlock — runs silently in background
  _autoFlexSync();
  _autoBybitSync();
}

async function _flexFetch(jwt, { debug } = {}) {
  // IBKR temporary error codes — safe to retry (busy / generating / throttled)
  const RETRYABLE = new Set(['1001','1004','1005','1006','1007','1008','1009','1018','1019','1021']);

  // Step 1: SendRequest — usually succeeds first try; retry temporary errors
  // (1001 etc.) with backoff so a brief IBKR "busy" state self-heals.
  const SEND_DELAYS = [0, 6000, 12000, 20000];
  let refCode = '';
  let sendErr = 'שגיאה לא ידועה';
  let sendCode = '';
  let sendTs = '';
  for (let i = 0; i < SEND_DELAYS.length; i++) {
    if (SEND_DELAYS[i] > 0) {
      flexSetStatus('מסנכרן עם IBKR...', 'var(--text2)');
      await new Promise(r => setTimeout(r, SEND_DELAYS[i]));
    }
    const sendRes = await fetch(`${SUPABASE_URL}/functions/v1/ibkr?action=send`, { headers: { 'Authorization': `Bearer ${jwt}` } });
    if (!sendRes.ok) throw new Error(`שגיאת רשת בשליחה: ${sendRes.status}`);
    const sendXml = await sendRes.text();
    refCode = flexExtractTag(sendXml, 'ReferenceCode');
    if (refCode && flexExtractTag(sendXml, 'Status') !== 'Fail') break;
    refCode  = '';
    sendCode = flexExtractTag(sendXml, 'ErrorCode');
    sendErr  = flexExtractTag(sendXml, 'ErrorMessage') || 'שגיאה לא ידועה';
    sendTs   = (sendXml.match(/timestamp='([^']*)'/) || [])[1] || '';
    if (!RETRYABLE.has(sendCode)) throw new Error(`שליחה נכשלה: ${sendErr} [IBKR ${sendCode}] [שעת IBKR: ${sendTs}]`);
  }
  if (!refCode) {
    const isBusy = ['1001', '1009', '1018', '1021'].includes(sendCode);
    const err = new Error(isBusy
      ? 'IBKR עמוס כרגע ולא הצליח להפיק את הדוח. ננסה שוב אוטומטית בקרוב. אם זה חוזר שוב ושוב — ודא שה‑Flex Query מוגדר על "Last 365 Calendar Days" (לא 30).'
      : `שליחה נכשלה: ${sendErr} [IBKR ${sendCode}]`);
    err.busy = isBusy;
    throw err;
  }

  // Step 2: Poll GetStatement — a full 365-day statement can take a few minutes
  // to generate for an active account, so give IBKR up to ~4 minutes.
  const DELAYS = [3000,5000,5000,8000,8000,10000,12000,15000,15000,20000,20000,25000,25000,30000,30000];
  let xml = '';
  let getErr = 'IBKR לא הצליח ליצור את הדוח';
  let getCode = '';
  for (let i = 0; i < DELAYS.length; i++) {
    flexSetStatus('מכין נתונים ב-IBKR...', 'var(--text2)');
    await new Promise(r => setTimeout(r, DELAYS[i]));
    const getRes = await fetch(
      `${SUPABASE_URL}/functions/v1/ibkr?action=get&ref=${encodeURIComponent(refCode)}`,
      { headers: { 'Authorization': `Bearer ${jwt}` } }
    );
    if (!getRes.ok) throw new Error(`שגיאת רשת בקבלה: ${getRes.status}`);
    xml = await getRes.text();
    if (flexExtractTag(xml, 'Status') !== 'Fail') break;
    getCode = flexExtractTag(xml, 'ErrorCode');
    getErr  = flexExtractTag(xml, 'ErrorMessage') || 'שגיאה לא ידועה';
    if (!RETRYABLE.has(getCode)) throw new Error(`קבלת הדוח נכשלה: ${getErr} [IBKR ${getCode}]`);
  }
  if (flexExtractTag(xml, 'Status') === 'Fail') {
    const err = new Error('IBKR עמוס כרגע והדוח לא היה מוכן בזמן. ננסה שוב אוטומטית בקרוב. אם זה חוזר שוב ושוב — ודא שה‑Flex Query מוגדר על "Last 365 Calendar Days" (לא 30).');
    err.busy = true;
    throw err;
  }
  if (debug) return { xml, trades: flexParseXML(xml) };
  return flexParseXML(xml);
}

// Import synced trades into the journal: dedup, persist to Supabase, then
// refresh every view (tables, dashboard, statistics) so data appears with no
// extra clicks. Shared by the automatic sync and the manual Sync button.
let _flexImporting = false;
async function _flexImport(trades) {
  // Re-entrancy guard: if a manual and an automatic import overlap, both could
  // pass the in-memory dedup before either inserts → duplicates. Run one at a time.
  if (_flexImporting) return { imported: 0, updated: 0, newlyImported: [] };
  _flexImporting = true;
  try {
    return await _flexImportInner(trades);
  } finally {
    _flexImporting = false;
  }
}
async function _flexImportInner(trades) {
  let imported = 0, updated = 0;
  const newlyImported = [];
  const toInsert = [];
  const toUpdate = [];

  const sameEntry = (x, t) =>
    x.symbol === t.symbol && x.entryDate === t.entryDate &&
    Math.abs((x.entryPrice || 0) - (t.entryPrice || 0)) < 0.01 &&
    Math.abs((x.shares || 0) - (t.shares || 0)) < 0.01;

  trades.forEach(t => {
    const arr = t.type === 'crypto' ? db.crypto : db.stocks;

    // Orphan close — sell with no matching buy in the window; close any open
    // position with the same symbol.
    if (t._orphanClose) {
      const open = arr.find(x => !x.deleted && x.symbol === t.symbol && !x.exitPrice);
      if (open) {
        open.exitPrice    = t.exitPrice;
        open.closeDate    = t.closeDate;
        open.closedShares = t.closedShares;
        toUpdate.push(open);
        updated++;
      }
      return;
    }

    // Find an already-imported copy of this trade. By IBKR's unique execution id
    // first (idempotent — re-syncs never duplicate, and scale-in lots stay
    // separate because each has its own id); else by entry (manual trades, or
    // trades imported before tagging — those get the id backfilled).
    let existing = null;
    if (t.ibkr_id) {
      existing = arr.find(x => !x.deleted && x.ibkr_id === t.ibkr_id)
              || arr.find(x => !x.deleted && !x.ibkr_id && sameEntry(x, t));
    } else {
      existing = arr.find(x => !x.deleted && sameEntry(x, t));
    }

    if (existing) {
      // Same trade already in the journal → update it in place (corrects the
      // exit on re-sync, backfills the id), never insert a second copy.
      let changed = false;
      if (t.ibkr_id && existing.ibkr_id !== t.ibkr_id) { existing.ibkr_id = t.ibkr_id; changed = true; }
      if (t.exitPrice && (Math.abs((existing.exitPrice || 0) - t.exitPrice) > 1e-9
          || Math.abs((existing.closedShares || 0) - (t.closedShares || 0)) > 1e-9)) {
        existing.exitPrice    = t.exitPrice;
        existing.closeDate    = t.closeDate;
        existing.closedShares = t.closedShares;
        existing.t            = t.t || [];
        existing.commission   = t.commission;
        changed = true;
      }
      if (changed) { toUpdate.push(existing); updated++; }
      return;
    }

    // New trade — honor user deletions (don't re-import something deleted).
    const fp = `${t.symbol}||${t.entryDate}||${Math.round((t.entryPrice||0)*1000)}||${Math.round((t.shares||0)*1000)}`;
    if (db._deletedFingerprints?.has(fp)) return;
    toInsert.push(t);
  });

  for (const trade of toUpdate) {
    const row = _tradeToRow(trade);
    await _sb.from('trades').update(row).eq('id', trade.id).eq('user_id', _currentUser.id);
  }

  for (const t of toInsert) {
    const row = _tradeToRow({ ...t, deleted: false });
    const { data: inserted, error: insErr } = await _sb.from('trades').insert(row).select().single();
    if (insErr) { continue; }
    const newTrade = _rowToTrade(inserted);
    const arr = t.type === 'crypto' ? db.crypto : db.stocks;
    arr.push(newTrade);
    imported++;
    if (!t.exitPrice) newlyImported.push(newTrade);
  }

  await _dedupeTrades(); // sweep any leftover duplicates right after importing

  if (imported > 0 || updated > 0) {
    initFilters();
    // New data just arrived — clear the stocks/crypto period filters so imported
    // trades (including older years) show immediately instead of being hidden.
    if (imported > 0) {
      ['st', 'cr'].forEach(p => {
        const ys = document.getElementById(p + '-year');  if (ys) ys.value = '';
        const ms = document.getElementById(p + '-month'); if (ms) ms.value = '';
      });
    }
    renderTable('stock');
    renderTable('crypto');
    renderOverview();
    // Statistics renders its charts when its tab is opened; calling it here
    // (off-tab) hits null chart containers. The stats tab re-reads db on open.
    if (document.getElementById('tab-statistics')?.classList.contains('active')) renderStatistics();
  }
  return { imported, updated, newlyImported };
}

// Smart sync throttle. Record each attempt's outcome and compute when the next
// automatic attempt is allowed: 6h after success (IBKR activity data updates
// ~once daily), and a backoff after consecutive failures (15min → 30, capped at
// 30min) so a busy token gets some room without leaving the badge stuck for hours.
function _flexMarkSync(ok) {
  if (!_currentUser) return;
  const id = _currentUser.id;
  localStorage.setItem('flex_sync_ts_' + id, String(Date.now()));
  localStorage.setItem('flex_sync_ok_' + id, ok ? '1' : '0');
  const failKey = 'flex_sync_fails_' + id;
  const fails = parseInt(localStorage.getItem(failKey) || '0', 10);
  localStorage.setItem(failKey, ok ? '0' : String(fails + 1));
}

function _flexSyncCooldownLeft() {
  if (!_currentUser) return 0;
  const id = _currentUser.id;
  const last = parseInt(localStorage.getItem('flex_sync_ts_' + id) || '0', 10);
  if (localStorage.getItem('flex_sync_ok_' + id) !== '0') {
    return Math.max(0, 6 * 60 * 60 * 1000 - (Date.now() - last)); // 6h after success
  }
  const fails = parseInt(localStorage.getItem('flex_sync_fails_' + id) || '0', 10);
  const wait = Math.min(15 * 60 * 1000 * Math.pow(2, Math.max(0, fails - 1)), 30 * 60 * 1000);
  return Math.max(0, wait - (Date.now() - last));
}

// Import the statement that the scheduled server job pre-fetched at a good time
// (flex_statement_cache). Reuses the existing parse + import path, so there is
// no live IBKR call and no 1001. Returns true if a fresh cache was used.
async function _flexImportFromCache() {
  if (!_currentUser) return false;
  let row;
  try {
    const { data } = await _sb.from('flex_statement_cache')
      .select('xml, fetched_at, imported_at').eq('user_id', _currentUser.id).maybeSingle();
    row = data;
  } catch (e) { return false; }
  if (!row?.xml) return false;
  // Stale cache (cron gap > 30h) → let the live fallback try instead.
  if (Date.now() - new Date(row.fetched_at).getTime() > 30 * 60 * 60 * 1000) return false;

  const alreadyImported = row.imported_at && new Date(row.imported_at) >= new Date(row.fetched_at);
  if (alreadyImported) { _flexMarkSync(true); _setBrokerBadge('ibkr', 'ok'); flexSetStatus('✓ עדכני', 'var(--text3)'); return true; }

  try {
    const trades = flexParseXML(row.xml);
    const { imported, updated } = await _flexImport(trades);
    await _sb.from('flex_statement_cache').update({ imported_at: new Date().toISOString() }).eq('user_id', _currentUser.id);
    _flexMarkSync(true);
    _setBrokerBadge('ibkr', 'ok');
    if (imported > 0 || updated > 0) {
      const msg = [imported ? `${imported} חדשות` : '', updated ? `${updated} עודכנו` : ''].filter(Boolean).join(' | ');
      flexSetStatus(`✓ ${msg}`, 'var(--green)');
      toast(`✓ IBKR: ${msg}`, 'success');
      auditLog('flex_cache_import', `imported:${imported} updated:${updated}`);
    } else {
      flexSetStatus('✓ סונכרן — אין עסקאות חדשות', 'var(--text3)');
    }
    return true;
  } catch (e) { return false; }
}

// Live Flex generation is only reliable after IBKR's once-daily EOD batch.
// Restrict live attempts to weekday US business hours (the scheduled cron+cache
// covers everything else) so we stop hitting 1001 at bad times.
function _flexLiveWindowOpen() {
  const et = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const day = et.getDay();
  if (day === 0 || day === 6) return false;       // weekend
  return et.getHours() >= 10 && et.getHours() < 23; // after EOD processing
}

async function _autoFlexSync() {
  if (!_currentUser) return;
  if (!_userSettings.flex_token) return;
  // 1) Prefer the server pre-fetched statement — instant, no IBKR call, no 1001.
  if (await _flexImportFromCache()) return;
  // 2) No usable cache → live fallback, throttled and only in a good window.
  if (_flexSyncCooldownLeft() > 0) {
    if (localStorage.getItem('flex_sync_ok_' + _currentUser.id) === '1') _setBrokerBadge('ibkr', 'ok');
    else _brokerBadgeFromStore('ibkr', true);
    return;
  }
  if (!_flexLiveWindowOpen()) { _brokerBadgeFromStore('ibkr', true); return; }
  const jwt = await _getToken();
  if (!jwt) return;
  _setBrokerBadge('ibkr', 'syncing');
  flexSetStatus('מסנכרן עם IBKR...', 'var(--text2)');
  try {
    const trades = await _flexFetch(jwt);
    _flexMarkSync(true);
    _setBrokerBadge('ibkr', 'ok');
    const { imported, updated, newlyImported } = await _flexImport(trades);
    if (imported > 0 || updated > 0) {
      const msg = [imported ? `${imported} חדשות` : '', updated ? `${updated} עודכנו` : ''].filter(Boolean).join(' | ');
      flexSetStatus(`✓ ${msg}`, 'var(--green)');
      toast(`✓ IBKR: ${msg}`, 'success');
      auditLog('flex_auto_import', `imported:${imported} updated:${updated}`);
      const openNeedStop = newlyImported
        .filter(tr => !tr.stop)
        .map(tr => ({ type: tr.type, id: tr.id, symbol: tr.symbol, entryPrice: tr.entryPrice, entryDate: tr.entryDate }));
      if (openNeedStop.length) setTimeout(() => stopPromptShow(openNeedStop), 800);
    } else {
      flexSetStatus('✓ סונכרן — אין עסקאות חדשות', 'var(--text3)');
    }
  } catch(e) {
    // Background sync — record the failure (extends the backoff) and retry later.
    _flexMarkSync(false);
    if (e.busy) _brokerBadgeFromStore('ibkr', true); // busy = still connected
    else _setBrokerBadge('ibkr', 'error');
    // Stay quiet for the odd transient failure, but after several in a row the
    // cause is almost always a mis-set query period — guide the user to fix it.
    const fails = parseInt(localStorage.getItem('flex_sync_fails_' + _currentUser.id) || '0', 10);
    flexSetStatus(
      fails >= 3 ? 'הסנכרון נכשל שוב ושוב — ודא שה‑Flex Query מוגדר על "Last 365 Calendar Days" (לא 30)' : '',
      fails >= 3 ? 'var(--text2)' : 'var(--text3)');
  }
}

async function _autoBybitSync() {
  if (!_currentUser) return;
  if (!_userSettings.bybit_api_key) return;
  const COOLDOWN_MS = 6 * 60 * 60 * 1000;
  const lastKey = 'bybit_sync_ts_' + _currentUser.id;
  const last = parseInt(localStorage.getItem(lastKey) || '0', 10);
  if (Date.now() - last < COOLDOWN_MS) {
    // Skipped by cooldown — the timestamp is only set on success, so reflect 'ok'.
    if (last > 0) _setBrokerBadge('bybit', 'ok');
    return;
  }
  const jwt = await _getToken();
  if (!jwt) return;
  _setBrokerBadge('bybit', 'syncing');
  bybitSetStatus('מסנכרן עם Bybit...', 'var(--text2)');
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/bybit`, {
      headers: { Authorization: `Bearer ${jwt}` }
    });
    const json = await res.json();
    if (!res.ok || json.error) throw new Error(json.error || 'שגיאה');
    localStorage.setItem(lastKey, String(Date.now()));
    _setBrokerBadge('bybit', 'ok');

    const trades = json.trades || [];
    let imported = 0;
    for (const t of trades) {
      const fp = `${t.symbol}||${t.entryDate}||${Math.round((t.entryPrice||0)*1000)}||${Math.round((t.shares||0)*1000)}`;
      if (db._deletedFingerprints?.has(fp)) continue;
      const existing = db.crypto.find(e =>
        `${e.symbol}||${e.entryDate}||${Math.round((e.entryPrice||0)*1000)}||${Math.round((e.shares||0)*1000)}` === fp
      );
      if (existing) continue;
      const { data, error } = await _sb.from('trades').insert(_tradeToRow({ ...t, deleted: false })).select().single();
      if (!error) { db.crypto.unshift(_rowToTrade(data)); imported++; }
    }
    if (imported > 0) {
      initFilters();
      renderTable('crypto');
      renderOverview();
      bybitSetStatus(`✓ ${imported} עסקאות חדשות`, 'var(--green)');
      toast(`✓ Bybit: ${imported} עסקאות יובאו`, 'success');
      auditLog('bybit_auto_import', `imported:${imported}`);
    } else {
      bybitSetStatus('✓ סונכרן — אין עסקאות חדשות', 'var(--text3)');
    }
  } catch(e) {
    _setBrokerBadge('bybit', 'error');
    bybitSetStatus('', 'var(--text3)');
  }
}

// ── Stop Loss Prompt Queue ──────────────────────
let _stopQueue = [];   // [{type, id, symbol, entryPrice, entryDate}, ...]

function stopPromptShow(queue) {
  _stopQueue = queue;
  _stopPromptNext();
}

function _stopPromptNext() {
  if (!_stopQueue.length) return;
  const t = _stopQueue[0];
  document.getElementById('stop-prompt-symbol').textContent = t.symbol;
  document.getElementById('stop-prompt-detail').textContent =
    `כניסה $${fmtPrice(t.entryPrice)} · ${fmtDate(t.entryDate)}`;
  document.getElementById('stop-prompt-input').value = '';
  document.getElementById('stop-prompt-overlay').style.display = 'flex';
  setTimeout(() => document.getElementById('stop-prompt-input').focus(), 80);
}

function _stopPromptClose() {
  document.getElementById('stop-prompt-overlay').style.display = 'none';
  _stopQueue.shift();
  if (_stopQueue.length) setTimeout(_stopPromptNext, 200);
}

function stopPromptSave() {
  const t   = _stopQueue[0];
  const val = parseFloat(document.getElementById('stop-prompt-input').value);
  if (!val || val <= 0) { toast('הכנס מחיר stop תקין', 'error'); return; }
  const arr = t.type === 'crypto' ? db.crypto : db.stocks;
  const tr  = arr.find(x => x.id === t.id);
  if (tr) {
    tr.stop = val;
    renderTable(t.type); // optimistic — מיד
    _sb.from('trades').update({ stop: val }).eq('id', tr.id).eq('user_id', _currentUser.id)
      .then(({ error, data }) => {
        if (error) { toast('שגיאה בשמירת stop', 'error'); }
        else { toast('Stop loss נשמר ✓', 'success'); }
      });
  }
  _stopPromptClose();
}

function stopPromptSkip() { _stopPromptClose(); }
// ────────────────────────────────────────────────

function lockNow() {
  if (!hasPIN()) { toast('הגדר PIN תחילה — לחץ על 🔒','error'); return; }
  stopAutoLock();
  pinBuffer = '';
  pinSetupMode = false;
  pinSetupFirst = '';
  pinUpdateDots();
  pinMsg('');
  document.getElementById('pin-sub-text').textContent = 'הכנס קוד PIN לכניסה';
  document.getElementById('pin-overlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function toggleLock() {
  if (hasPIN()) {
    lockNow();
  } else {
    pinSetupMode = true;
    pinSetupFirst = '';
    pinBuffer = '';
    pinUpdateDots();
    pinMsg('');
    document.getElementById('pin-sub-text').textContent = 'הכנס קוד PIN חדש (4 ספרות)';
    const link = document.getElementById('pin-toggle-link');
    if (link) link.textContent = '';
    document.getElementById('pin-overlay').classList.add('open');
    document.body.style.overflow = 'hidden';
  }
}

function pinToggleSetup() {
  pinSetupMode = true;
  pinSetupFirst = '';
  pinBuffer = '';
  pinUpdateDots();
  pinMsg('');
  document.getElementById('pin-sub-text').textContent = 'הכנס קוד PIN חדש (4 ספרות)';
  const link = document.getElementById('pin-toggle-link');
  if (link) link.textContent = '';
}

function startAutoLock() {
  stopAutoLock();
  const badge   = document.getElementById('inactivity-badge');
  const cdEl    = document.getElementById('inactivity-countdown');

  autoLockTimer = setInterval(() => {
    const idle = Date.now() - lastActivity;
    const remaining = AUTO_LOCK_MS - idle;
    if (remaining <= 0 && hasPIN()) {
      lockNow();
      return;
    }
    if (remaining <= WARN_BEFORE_MS) {
      badge.classList.add('visible');
      const secs = Math.ceil(remaining / 1000);
      cdEl.textContent = secs + ' שניות';
    } else {
      badge.classList.remove('visible');
    }
  }, 1000);
}

function stopAutoLock() {
  if (autoLockTimer) { clearInterval(autoLockTimer); autoLockTimer = null; }
}

// עדכן lastActivity בכל אינטראקציה
['mousemove','mousedown','keydown','touchstart','scroll'].forEach(ev => {
  document.addEventListener(ev, () => { lastActivity = Date.now(); }, { passive: true });
});

// ══════════════════════════════════════════════
// DATA INTEGRITY — checksum על localStorage
// מונע שינוי ידני של הנתונים מחוץ לאפליקציה
// ══════════════════════════════════════════════
const CHECKSUM_KEY = 'tj-checksum';

function dbChecksum(data) {
  const s = JSON.stringify(data);
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  }
  return (h >>> 0).toString(16);
}

function saveDB() { /* no-op — CRUD functions write directly to Supabase */ }

function verifyIntegrity() {
  const raw = localStorage.getItem(KEY);
  const stored = localStorage.getItem(CHECKSUM_KEY);
  if (!raw || !stored) return true; // אין נתונים — לא רלוונטי
  try {
    const parsed = JSON.parse(raw);
    const expected = dbChecksum(parsed);
    if (expected !== stored) {
      console.warn('[Security] Data integrity check FAILED — possible tampering detected');
      toast('⚠️ נתונים שונו מחוץ לאפליקציה! מאפס לנתונים מאובטחים.', 'error');
      return false;
    }
  } catch(e) { return false; }
  return true;
}

// ══════════════════════════════════════════════
// INTERACTIVE ISRAEL — TLG FILE IMPORT
// ══════════════════════════════════════════════
function tlgLoadFile(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => tlgParse(e.target.result);
  reader.readAsText(file, 'utf-8');
}

function tlgParse(text) {
  const status  = document.getElementById('tlg-status');
  const preview = document.getElementById('tlg-preview');
  if (status)  status.textContent = '';
  if (preview) preview.innerHTML  = '';

  const lines = text.split(/\r?\n/).filter(l => l.startsWith('STK_TRD|'));
  if (!lines.length) {
    if (status) status.textContent = '❌ לא נמצאו עסקאות בקובץ';
    return;
  }

  // Parse each row
  const rows = lines.map(line => {
    const p = line.split('|');
    // STK_TRD|OrderID|Symbol|Name|Exchange|Action|OC|Date|Time|Currency|Qty|Mult|Price|Value|Commission|...
    const action = (p[5] || '').toUpperCase();
    const oc     = (p[6] || '').toUpperCase();
    const rawDate = p[7] || '';
    const entryDate = rawDate.length === 8
      ? `${rawDate.slice(0,4)}-${rawDate.slice(4,6)}-${rawDate.slice(6,8)}`
      : '';
    return {
      orderId:    p[1] || '',
      symbol:     (p[2] || '').toUpperCase().replace(/[^A-Z0-9._\-]/g,'').slice(0,10),
      name:       p[3] || '',
      action,
      oc,
      entryDate,
      price:      Math.abs(parseFloat(p[12]) || 0),
      qty:        Math.abs(parseFloat(p[10]) || 0),
      commission: Math.abs(parseFloat(p[14]) || 0),
      isBuy:      action.includes('BUY'),
    };
  }).filter(r => r.symbol && r.price && r.qty);

  // Group by symbol → match buys to sells
  const bySymbol = {};
  rows.forEach(r => {
    if (!bySymbol[r.symbol]) bySymbol[r.symbol] = { buys: [], sells: [] };
    if (r.isBuy) bySymbol[r.symbol].buys.push(r);
    else         bySymbol[r.symbol].sells.push(r);
  });

  // Build trades: each BUY becomes a trade, sells become exits/targets
  const trades = [];
  Object.entries(bySymbol).forEach(([sym, { buys, sells }]) => {
    buys.forEach(buy => {
      // Find matching sells (by date order)
      const matchedSells = sells.filter(s => s.entryDate >= buy.entryDate);
      let remaining = buy.qty;
      const targets = [];
      let closeDate = '', exitPrice = 0, closedShares = 0;

      matchedSells.forEach(sell => {
        if (remaining <= 0) return;
        const used = Math.min(sell.qty, remaining);
        remaining -= used;
        closedShares += used;
        closeDate = sell.entryDate;
        exitPrice = sell.price; // last exit price
        if (matchedSells.length > 1) {
          targets.push({ shares: used, price: sell.price });
        }
      });

      trades.push({
        symbol: sym,
        name: buy.name,
        entryDate: buy.entryDate,
        entryPrice: buy.price,
        shares: buy.qty,
        commission: buy.commission + matchedSells.reduce((s,x) => s + x.commission, 0),
        closeDate: closedShares > 0 ? closeDate : '',
        exitPrice: closedShares > 0 ? exitPrice : 0,
        closedShares,
        targets: targets.length > 1 ? targets : [],
        ls: 'L',
      });
    });
  });

  if (!trades.length) {
    if (status) status.textContent = '❌ לא ניתן לבנות עסקאות מהקובץ';
    return;
  }

  if (status) status.innerHTML = `<span style="color:var(--green)">✅ נמצאו ${trades.length} עסקאות — בחר אילו לייבא:</span>`;

  // Store for confirmation
  window._tlgPending = trades;

  // Render preview
  if (!preview) return;
  preview.innerHTML = '';
  trades.forEach((t, i) => {
    const pnl = t.closedShares > 0 ? ((t.exitPrice - t.entryPrice) * t.closedShares - t.commission).toFixed(2) : null;
    const pnlHtml = pnl !== null
      ? `<span style="color:${+pnl >= 0 ? 'var(--green)' : 'var(--red)'};">${+pnl >= 0 ? '+' : ''}$${pnl}</span>`
      : '<span style="color:var(--text3)">פתוח</span>';
    const safeEntryDate  = /^\d{4}-\d{2}-\d{2}$/.test(t.entryDate) ? t.entryDate : '—';
    const safeEntryPrice = parseFloat(t.entryPrice||0).toFixed(4);
    const safeShares     = parseFloat(t.shares||0);
    const safeTargets    = Number.isInteger(t.targets?.length) ? t.targets.length : 0;
    const div = document.createElement('div');
    div.className = 'ibkr-trade-preview';
    div.innerHTML = `
      <div>
        <span class="sym">${esc(t.symbol)}</span>
        <span style="font-size:11px;color:var(--text3);margin-right:8px;">${esc(t.name)}</span>
      </div>
      <div class="det">
        ${safeEntryDate} &nbsp;|&nbsp; כניסה: $${safeEntryPrice} &nbsp;|&nbsp;
        ${safeShares} מניות &nbsp;|&nbsp; P&L: ${pnlHtml}
        ${safeTargets ? ` &nbsp;|&nbsp; ${safeTargets} יציאות חלקיות` : ''}
      </div>
      <button class="btn btn-primary btn-sm" onclick="tlgConfirm(${i})" id="tlg-btn-${i}">+ ייבא</button>
    `;
    preview.appendChild(div);
  });

  const allBtn = document.createElement('button');
  allBtn.className = 'btn btn-primary';
  allBtn.style.marginTop = '12px';
  allBtn.textContent = `📥 ייבא הכל (${trades.length})`;
  allBtn.onclick = () => trades.forEach((_, i) => tlgConfirm(i));
  preview.appendChild(allBtn);
}

async function deduplicateDB(type) {
  const arr = type === 'stock' ? db.stocks : db.crypto;
  // Group by symbol+entryDate+entryPrice key
  const groups = {};
  arr.filter(t => !t.deleted).forEach(t => {
    const key = `${t.symbol}||${t.entryDate}||${Math.round((t.entryPrice||0)*1000)}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(t);
  });
  const toRemove = [];
  Object.values(groups).forEach(group => {
    if (group.length < 2) return;
    // Keep the one with exit price; if tied keep the one with stop; otherwise keep first
    group.sort((a, b) => {
      if (!!b.exitPrice !== !!a.exitPrice) return b.exitPrice ? 1 : -1;
      if (!!b.stop !== !!a.stop) return b.stop ? 1 : -1;
      return 0;
    });
    group.slice(1).forEach(t => toRemove.push(t.id));
  });
  const removed = toRemove.length;
  if (removed === 0) { toast('לא נמצאו כפילויות', 'success'); return; }
  if (!confirm(`נמצאו ${removed} עסקאות כפולות ב${type==='stock'?'מניות':'קריפטו'}. למחוק לצמיתות?`)) return;
  const keepIds = new Set(toRemove);
  if (type === 'stock') db.stocks = db.stocks.filter(t => !keepIds.has(t.id));
  else db.crypto = db.crypto.filter(t => !keepIds.has(t.id));
  if (_currentUser) {
    const { error } = await _sb.from('trades').update({ deleted: true }).in('id', toRemove).eq('user_id', _currentUser.id);
    if (error) { toast('שגיאה בנקה כפילויות', 'error'); console.error(error); return; }
  }
  renderTable(type);
  toast(`הוסרו ${removed} כפילויות`, 'success');
}

function tlgIsDuplicate(t) {
  const type = symIsCrypto(t.symbol) ? 'crypto' : 'stock';
  const arr  = type === 'crypto' ? db.crypto : db.stocks;
  return arr.some(x =>
    x.symbol === t.symbol &&
    x.entryDate === t.entryDate &&
    Math.abs(x.entryPrice - t.entryPrice) < 0.001
  );
}

function tlgConfirm(idx) {
  const pending = window._tlgPending;
  if (!pending || !pending[idx]) return;
  const t = pending[idx];

  if (tlgIsDuplicate(t)) {
    toast(`${t.symbol} כבר קיים ביומן — דילוג`, 'error');
    const btn = document.getElementById(`tlg-btn-${idx}`);
    if (btn) { btn.disabled = true; btn.textContent = '⚠ כפילות'; }
    return;
  }

  const type = symIsCrypto(t.symbol) ? 'crypto' : 'stock';
  const arr  = type === 'crypto' ? db.crypto : db.stocks;
  const newId = arr.length ? Math.max(...arr.map(x => x.id)) + 1 : 1;

  arr.push({
    id: newId, type,
    entryDate:    t.entryDate,
    ls:           t.ls,
    symbol:       t.symbol,
    entryPrice:   t.entryPrice,
    shares:       t.shares,
    stop:         0,
    t:            t.targets,
    closeDate:    t.closeDate,
    closedShares: t.closedShares,
    exitPrice:    t.exitPrice,
    ecn:          0,
    commission:   t.commission,
    notes_keep:   'יובא מאינטראקטיב ישראל',
    notes_improve: '',
  });
  saveDB();

  const btn = document.getElementById(`tlg-btn-${idx}`);
  if (btn) { btn.disabled = true; btn.textContent = '✓ נוסף'; }
  toast(`${t.symbol} נוסף ל${type === 'crypto' ? 'קריפטו' : 'מניות'}`, 'success');
  auditLog('trade_added', t.symbol + ' (TLG import)');
  initFilters();
}
// ────────────────────────────────────────────────────────────────

// ══════════════════════════════════════════════
// IBKR CLIENT PORTAL GATEWAY INTEGRATION
// ══════════════════════════════════════════════
const IBKR_BASE = 'https://localhost:5000/v1/api';
let ibkrConnected = false;
let _ibkrPending = [];          // module-scoped, not exposed on window
let _ibkrCheckLastMs = 0;       // rate-limit timestamp for ibkrCheckConnection
const _ibkrInFlight = new Map();// deduplication of concurrent requests

// Whitelist of allowed IBKR API paths
const IBKR_ALLOWED_PATHS = new Set([
  '/iserver/auth/status',
  '/portfolio/accounts',
  '/iserver/account/trades',
]);
const IBKR_ACCOUNT_TRADES_RE = /^\/iserver\/account\/[A-Z0-9]{1,20}\/trades$/;

async function ibkrFetch(path) {
  // Path whitelist validation
  if (!IBKR_ALLOWED_PATHS.has(path) && !IBKR_ACCOUNT_TRADES_RE.test(path)) {
    console.warn('[IBKR] Blocked unlisted path:', path);
    return null;
  }

  // Request deduplication — reuse in-flight promise for same path
  if (_ibkrInFlight.has(path)) return _ibkrInFlight.get(path);

  const controller = new AbortController();
  const timeoutId  = setTimeout(() => controller.abort(), 10000); // 10s timeout

  const promise = fetch(IBKR_BASE + path, {
    credentials: 'include',
    headers: { 'User-Agent': 'trading-journal' },
    signal: controller.signal
  })
  .then(res => {
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return res.json();
  })
  .catch(() => null)
  .finally(() => {
    clearTimeout(timeoutId);
    _ibkrInFlight.delete(path);
  });

  _ibkrInFlight.set(path, promise);
  return promise;
}

function ibkrSetStatus(connected, label) {
  ibkrConnected = connected;
  const dot = document.getElementById('ibkr-conn-dot');
  const hdrDot = document.getElementById('ibkr-header-dot');
  const txt = document.getElementById('ibkr-conn-text');
  if (dot) {
    dot.className = 'ibkr-status-dot' + (connected ? ' connected' : ' disconnected');
  }
  if (hdrDot) {
    hdrDot.className = 'ibkr-status-dot' + (connected ? ' connected' : ' disconnected');
    hdrDot.title = connected ? 'IBKR מחובר' : 'IBKR לא מחובר';
  }
  if (txt) txt.textContent = label || (connected ? 'מחובר' : 'לא מחובר');
}

function ibkrLog(msg, cls) {
  const log = document.getElementById('ibkr-log');
  if (!log) return;
  const div = document.createElement('div');
  div.className = 'ibkr-log-entry ' + (cls || 'ibkr-log-info');
  div.textContent = new Date().toLocaleTimeString('he-IL') + ' — ' + msg;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
}

async function ibkrCheckConnection() {
  // Rate limit: 2 seconds between checks
  const now = Date.now();
  if (now - _ibkrCheckLastMs < 2000) return;
  _ibkrCheckLastMs = now;

  const btn = document.getElementById('ibkr-check-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ בודק...'; }
  ibkrSetStatus(false, 'בודק חיבור...');

  const data = await ibkrFetch('/iserver/auth/status');

  if (btn) { btn.disabled = false; btn.textContent = '🔄 בדוק חיבור'; }

  if (!data) {
    ibkrSetStatus(false, 'שגיאת חיבור — Gateway לא זמין');
    toast('IBKR Gateway לא זמין — פתח את localhost:5000 תחילה', 'error');
    return;
  }

  const auth = data.authenticated === true || data.connected === true;
  if (auth) {
    ibkrSetStatus(true, 'מחובר ומאומת');
    auditLog('ibkr_connected');
    toast('IBKR מחובר בהצלחה', 'success');
    const accountCard = document.getElementById('ibkr-account-card');
    const importCard = document.getElementById('ibkr-import-card');
    if (accountCard) accountCard.style.display = '';
    if (importCard) importCard.style.display = '';

    // Set default date range (last 30 days)
    const now = new Date();
    const from = new Date(now);
    from.setDate(from.getDate() - 30);
    const toInput = document.getElementById('ibkr-date-to');
    const fromInput = document.getElementById('ibkr-date-from');
    if (toInput) toInput.value = now.toISOString().split('T')[0];
    if (fromInput) fromInput.value = from.toISOString().split('T')[0];

    const log = document.getElementById('ibkr-log');
    if (log) log.innerHTML = '';
    ibkrLog('מחובר ל-IBKR Gateway', 'ibkr-log-ok');
    await ibkrLoadAccounts();
  } else {
    ibkrSetStatus(false, 'לא מאומת — נדרש התחברות ב-Gateway');
    toast('IBKR Gateway פעיל אך לא מאומת — התחבר דרך localhost:5000', 'error');
  }
}

async function ibkrLoadAccounts() {
  const sel = document.getElementById('ibkr-account-select');
  if (!sel) return;
  const data = await ibkrFetch('/portfolio/accounts');
  if (!data || !Array.isArray(data)) {
    ibkrLog('לא ניתן לטעון חשבונות', 'ibkr-log-err');
    sel.innerHTML = '<option value="">— שגיאה בטעינת חשבונות —</option>';
    return;
  }
  sel.innerHTML = data.map(acc =>
    `<option value="${esc(acc.id||acc.accountId||'')}">${esc(acc.id||acc.accountId||'')} ${acc.alias ? '('+esc(acc.alias)+')' : ''}</option>`
  ).join('');
  if (data.length > 0) {
    ibkrLog('נטענו ' + data.length + ' חשבונות', 'ibkr-log-ok');
  }
}

function ibkrConfirmTrade(idx) {
  // Validate index — must be safe integer within bounds
  if (!Number.isInteger(idx) || idx < 0 || idx >= _ibkrPending.length) return;
  const t = _ibkrPending[idx];
  if (!t) return;

  // Auto-detect type from symbol (same logic as qaAutoType)
  const type = symIsCrypto(t.symbol) ? 'crypto' : 'stock';
  const arr  = type === 'crypto' ? db.crypto : db.stocks;
  const newTrade = {
    id: arr.length ? Math.max(...arr.map(x=>x.id))+1 : 1,
    type,
    entryDate: t.entryDate || new Date().toISOString().split('T')[0],
    ls: t.ls,
    symbol: t.symbol,
    entryPrice: t.entryPrice,
    shares: t.shares,
    stop: 0,
    t: [],
    closeDate: '',
    closedShares: 0,
    exitPrice: 0,
    ecn: 0,
    commission: t.commission || 0,
    notes_keep: 'יובא מ-IBKR',
    notes_improve: ''
  };
  arr.push(newTrade);
  saveDB();
  const journalLabel = type === 'crypto' ? 'יומן קריפטו' : 'יומן מניות';
  ibkrLog('עסקה ' + t.symbol + ' נוספה ל' + journalLabel, 'ibkr-log-ok');
  toast('עסקה ' + t.symbol + ' נוספה ל' + journalLabel, 'success');

  // Remove the import button for this trade
  const preview = document.getElementById('ibkr-trades-preview');
  if (preview) {
    const btns = preview.querySelectorAll('.ibkr-trade-preview');
    if (btns[idx]) {
      btns[idx].style.opacity = '0.4';
      const btn = btns[idx].querySelector('button');
      if (btn) { btn.disabled = true; btn.textContent = '✓ נוסף'; }
    }
  }
  initFilters();
}

// ══════════════════════════════════════════════
// TRADE SCREENSHOTS — IndexedDB
// ══════════════════════════════════════════════
const DB_NAME = 'trading-journal-media';
const DB_VERSION = 1;
let mediaDB = null;
let currentSSKey = '';
let currentSSSymbol = '';

function initMediaDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = e => {
      const db2 = e.target.result;
      if (!db2.objectStoreNames.contains('screenshots')) {
        db2.createObjectStore('screenshots', { keyPath: 'key' });
      }
    };
    req.onsuccess = e => { mediaDB = e.target.result; resolve(); };
    req.onerror = () => reject(req.error);
  });
}

async function saveScreenshot(key, dataObj) {
  if (!mediaDB) return;
  return new Promise((resolve, reject) => {
    const tx = mediaDB.transaction('screenshots', 'readwrite');
    tx.objectStore('screenshots').put(dataObj);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function getScreenshots(tradeKey) {
  if (!mediaDB) return [];
  return new Promise((resolve, reject) => {
    const tx = mediaDB.transaction('screenshots', 'readonly');
    const store = tx.objectStore('screenshots');
    const results = [];
    const req = store.openCursor();
    req.onsuccess = e => {
      const cursor = e.target.result;
      if (cursor) {
        if (cursor.value.tradeKey === tradeKey) results.push(cursor.value);
        cursor.continue();
      } else {
        resolve(results.sort((a,b) => (a.timestamp||0)-(b.timestamp||0)));
      }
    };
    req.onerror = () => reject(req.error);
  });
}

async function getScreenshotCount(tradeKey) {
  if (!mediaDB) return 0;
  const shots = await getScreenshots(tradeKey);
  return shots.length;
}

async function deleteScreenshot(key) {
  if (!mediaDB) return;
  return new Promise((resolve, reject) => {
    const tx = mediaDB.transaction('screenshots', 'readwrite');
    tx.objectStore('screenshots').delete(key);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function refreshScreenshotCount(tradeKey) {
  if (!mediaDB) return;
  const count = await getScreenshotCount(tradeKey);
  const badge = document.getElementById('ss-count-' + tradeKey);
  if (badge) {
    if (count > 0) {
      badge.textContent = count;
      badge.style.display = 'inline-block';
    } else {
      badge.style.display = 'none';
    }
  }
}

async function compressImage(file) {
  return new Promise(resolve => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const MAX = 1200;
      let w = img.width, h = img.height;
      if (w > MAX) { h = Math.round(h * MAX / w); w = MAX; }
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      canvas.getContext('2d').drawImage(img, 0, 0, w, h);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', 0.80));
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(null); };
    img.src = url;
  });
}

function dataURLBytes(dataURL) {
  // Estimate byte size from base64 string
  const base64 = dataURL.split(',')[1] || '';
  return Math.round(base64.length * 0.75);
}

function fmtBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024*1024) return (bytes/1024).toFixed(1) + ' KB';
  return (bytes/(1024*1024)).toFixed(2) + ' MB';
}

// Open Screenshot Modal
async function openSSModal(tradeKey, symbol) {
  currentSSKey = tradeKey;
  currentSSSymbol = symbol;
  const title = document.getElementById('ss-modal-title');
  if (title) title.textContent = 'צילומי מסך — ' + symbol;
  document.getElementById('ss-modal').classList.add('open');
  document.body.style.overflow = 'hidden';
  await renderSSGrid();
}

function closeSSModal() {
  document.getElementById('ss-modal').classList.remove('open');
  document.body.style.overflow = '';
  currentSSKey = '';
}

function onSSOverlayClick(e) {
  if (e.target === document.getElementById('ss-modal')) closeSSModal();
}

async function renderSSGrid() {
  const grid = document.getElementById('ss-grid');
  if (!grid) return;
  const shots = await getScreenshots(currentSSKey);
  if (!shots.length) {
    grid.innerHTML = '<div class="ss-empty">📷<br>אין צילומי מסך עדיין</div>';
    return;
  }
  grid.innerHTML = '';
  shots.forEach(shot => {
    const wrap = document.createElement('div');
    wrap.className = 'ss-thumb-wrap';
    const img = document.createElement('img');
    img.src = shot.dataURL;
    img.alt = 'screenshot';
    img.onclick = () => openLightbox(shot.dataURL);

    const delBtn = document.createElement('button');
    delBtn.className = 'ss-thumb-del';
    delBtn.title = 'מחק';
    delBtn.textContent = '✕';
    delBtn.onclick = async (e) => {
      e.stopPropagation();
      await deleteScreenshot(shot.key);
      await renderSSGrid();
      await refreshScreenshotCount(currentSSKey);
    };

    const info = document.createElement('div');
    info.className = 'ss-thumb-info';
    const bytes = dataURLBytes(shot.dataURL);
    const date = shot.timestamp ? new Date(shot.timestamp).toLocaleDateString('he-IL') : '';
    info.textContent = fmtBytes(bytes) + (date ? ' · ' + date : '');

    wrap.appendChild(img);
    wrap.appendChild(delBtn);
    wrap.appendChild(info);
    grid.appendChild(wrap);
  });
}

// Drag and drop
function ssDragOver(e) {
  e.preventDefault();
  document.getElementById('ss-drop-zone').classList.add('drag-over');
}
function ssDragLeave() {
  document.getElementById('ss-drop-zone').classList.remove('drag-over');
}
async function ssDrop(e) {
  e.preventDefault();
  document.getElementById('ss-drop-zone').classList.remove('drag-over');
  const files = [...(e.dataTransfer.files||[])].filter(f => f.type.startsWith('image/'));
  await ssUploadFiles(files);
}

async function ssFileSelected(e) {
  const files = [...(e.target.files||[])];
  e.target.value = '';
  await ssUploadFiles(files);
}

async function ssUploadFiles(files) {
  if (!files.length) return;
  if (!currentSSKey) { toast('שגיאה: לא נבחרה עסקה', 'error'); return; }
  for (const file of files) {
    const dataURL = await compressImage(file);
    if (!dataURL) { toast('שגיאה בטעינת ' + file.name, 'error'); continue; }
    const key = currentSSKey + '-' + Date.now() + '-' + Math.random().toString(36).slice(2);
    await saveScreenshot(key, { key, tradeKey: currentSSKey, dataURL, timestamp: Date.now(), name: file.name });
    toast('תמונה נשמרה', 'success');
  }
  await renderSSGrid();
  await refreshScreenshotCount(currentSSKey);
}

async function ssCaptureScreen() {
  if (!currentSSKey) { toast('שגיאה: לא נבחרה עסקה', 'error'); return; }
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
    const track = stream.getVideoTracks()[0];
    const imageCapture = new ImageCapture(track);
    const bitmap = await imageCapture.grabFrame();
    track.stop();
    stream.getTracks().forEach(t => t.stop());
    const canvas = document.createElement('canvas');
    canvas.width = bitmap.width; canvas.height = bitmap.height;
    canvas.getContext('2d').drawImage(bitmap, 0, 0);
    const dataURL = canvas.toDataURL('image/jpeg', 0.80);
    const key = currentSSKey + '-' + Date.now();
    await saveScreenshot(key, { key, tradeKey: currentSSKey, dataURL, timestamp: Date.now(), name: 'screen-capture' });
    await renderSSGrid();
    await refreshScreenshotCount(currentSSKey);
    toast('צילום מסך נשמר', 'success');
  } catch(e) {
    toast('לא ניתן לצלם מסך: ' + e.message, 'error');
  }
}

// Lightbox
function openLightbox(src) {
  document.getElementById('ss-lightbox-img').src = src;
  document.getElementById('ss-lightbox').classList.add('open');
}
function closeLightbox() {
  document.getElementById('ss-lightbox').classList.remove('open');
  document.getElementById('ss-lightbox-img').src = '';
}

// ══════════════════════════════════════════════
// FEATURE 1 — PRIVACY MODE
// ══════════════════════════════════════════════
let privacyMode = localStorage.getItem('tj-privacy') === '1';
function applyPrivacy() {
  document.body.classList.toggle('privacy-on', privacyMode);
  const btn = document.getElementById('privacy-btn');
  if (btn) btn.innerHTML = privacyMode
    ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`
    : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
}
function togglePrivacy() {
  privacyMode = !privacyMode;
  localStorage.setItem('tj-privacy', privacyMode ? '1' : '0');
  applyPrivacy();
  auditLog(privacyMode ? 'privacy_on' : 'privacy_off');
}

// ══════════════════════════════════════════════
// FEATURE 2 — PIN RATE LIMITING + BOT PROTECTION
// ══════════════════════════════════════════════
const PIN_ATTEMPTS_KEY = 'tj-pin-attempts';
const PIN_LOCKOUT_KEY  = 'tj-pin-lockout';
const MAX_ATTEMPTS = 5;
// Exponential backoff: after 5 fails → 5min, after 10 → 30min, after 15 → 2hr
function getLockoutDuration(attempts) {
  if (attempts >= 15) return 2 * 60 * 60 * 1000;   // 2 hours
  if (attempts >= 10) return 30 * 60 * 1000;         // 30 minutes
  return 5 * 60 * 1000;                              // 5 minutes
}
// Anti-bot: enforce minimum delay between PIN attempts (human can't press < 300ms)
let _lastPinAttempt = 0;
const MIN_ATTEMPT_INTERVAL_MS = 300;

function getPinAttempts() { return parseInt(localStorage.getItem(PIN_ATTEMPTS_KEY) || '0'); }
function setPinAttempts(n) { localStorage.setItem(PIN_ATTEMPTS_KEY, String(n)); }
function isLockedOut() {
  const until = parseInt(localStorage.getItem(PIN_LOCKOUT_KEY) || '0');
  return Date.now() < until;
}
function getLockoutRemaining() {
  const until = parseInt(localStorage.getItem(PIN_LOCKOUT_KEY) || '0');
  return Math.max(0, Math.ceil((until - Date.now()) / 1000));
}

let lockoutCountdownTimer = null;

function showLockoutMsg() {
  const msg = document.getElementById('pin-lockout-msg');
  const cd  = document.getElementById('pin-lockout-cd');
  if (!msg || !cd) return;
  msg.style.display = 'block';
  // Disable all pin keys
  document.querySelectorAll('.pin-key').forEach(k => k.disabled = true);
  if (lockoutCountdownTimer) clearInterval(lockoutCountdownTimer);
  function update() {
    const rem = getLockoutRemaining();
    if (rem <= 0) {
      clearInterval(lockoutCountdownTimer);
      lockoutCountdownTimer = null;
      msg.style.display = 'none';
      document.querySelectorAll('.pin-key').forEach(k => k.disabled = false);
      pinMsg('');
      return;
    }
    const m = Math.floor(rem / 60);
    const s = rem % 60;
    cd.textContent = m > 0 ? `${m}:${String(s).padStart(2,'0')} דקות` : `${s} שניות`;
  }
  update();
  lockoutCountdownTimer = setInterval(update, 1000);
}

// ══════════════════════════════════════════════
// FEATURE 3 — AUDIT LOG
// ══════════════════════════════════════════════
const AUDIT_KEY = 'tj-audit';

// Dual hash-chain audit log
// h  = FNV-32  — sync, written immediately, provides instant tamper detection
// sh = SHA-256 — async, written after, provides cryptographic non-repudiation
// Any modification of a past record breaks both chains (detectable on verify)
function auditLog(action, details = '') {
  const logs = JSON.parse(localStorage.getItem(AUDIT_KEY) || '[]');
  const prevFnv = logs.length ? (logs[0].h  || '0000000000000000') : '0000000000000000';
  const prevSha = logs.length ? (logs[0].sh || '0'.repeat(64))     : '0'.repeat(64);
  const entry = { ts: Date.now(), action, details: String(details).slice(0, 200) };

  // FNV-32 — synchronous, immediate
  let h = 0x811c9dc5;
  for (const c of (prevFnv + entry.ts + entry.action + entry.details)) {
    h ^= c.charCodeAt(0); h = (h * 0x01000193) >>> 0;
  }
  entry.h = h.toString(16).padStart(8, '0');

  logs.unshift(entry);
  if (logs.length > 500) logs.length = 500;
  localStorage.setItem(AUDIT_KEY, JSON.stringify(logs));
  renderAuditLog();

  // SHA-256 — async, non-blocking enhancement
  const payload = prevSha + String(entry.ts) + entry.action + entry.details;
  crypto.subtle.digest('SHA-256', new TextEncoder().encode(payload))
    .then(buf => {
      const sh = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
      const fresh = JSON.parse(localStorage.getItem(AUDIT_KEY) || '[]');
      if (fresh.length && fresh[0].ts === entry.ts && fresh[0].action === action) {
        fresh[0].sh = sh;
        localStorage.setItem(AUDIT_KEY, JSON.stringify(fresh));
      }
    })
    .catch(() => {});
}

function auditVerifyChain() {
  const logs = JSON.parse(localStorage.getItem(AUDIT_KEY) || '[]');
  if (logs.length < 2) return true;
  for (let i = 0; i < logs.length - 1; i++) {
    const cur  = logs[i];
    const prev = logs[i + 1];
    // Verify FNV chain
    const prevHash = prev.h || '0000000000000000';
    let h = 0x811c9dc5;
    for (const c of (prevHash + cur.ts + cur.action + cur.details)) {
      h ^= c.charCodeAt(0); h = (h * 0x01000193) >>> 0;
    }
    if (h.toString(16).padStart(8, '0') !== cur.h) return false;
  }
  return true;
}

// SHA-256 chain verification (async — call separately for deep audit)
async function auditVerifyChainSHA256() {
  const logs = JSON.parse(localStorage.getItem(AUDIT_KEY) || '[]');
  if (logs.length < 2) return true;
  for (let i = 0; i < logs.length - 1; i++) {
    const cur  = logs[i];
    const prev = logs[i + 1];
    if (!cur.sh || !prev.sh) continue; // skip entries without SHA field
    const payload = (prev.sh || '0'.repeat(64)) + String(cur.ts) + cur.action + cur.details;
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(payload));
    const expected = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
    if (expected !== cur.sh) return false;
  }
  return true;
}

function fmtAuditTs(ts) {
  const d = new Date(ts);
  const pad = n => String(n).padStart(2,'0');
  return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${String(d.getFullYear()).slice(2)} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

const ACTION_LABELS = {
  pin_unlocked: 'PIN — כניסה',
  pin_failed:   'PIN — נכשל',
  pin_lockout:  'PIN — נעילה',
  trade_added:  'עסקה נוספה',
  trade_edited: 'עסקה עודכנה',
  trade_deleted:'עסקה נמחקה',
  privacy_on:   'פרטיות הופעלה',
  privacy_off:  'פרטיות כובה',
  export_csv:   'יוצא CSV',
  ibkr_connected: 'IBKR חובר',
  ibkr_import:  'IBKR ייבוא'
};

function renderAuditLog() {
  const tbody = document.getElementById('audit-tbody');
  if (!tbody) return;
  const logs = JSON.parse(localStorage.getItem(AUDIT_KEY) || '[]').slice(0, 50);
  if (!logs.length) {
    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:var(--text3);padding:16px;">אין רשומות</td></tr>';
    return;
  }
  tbody.innerHTML = logs.map(l => {
    const safeAction = String(l.action||'').replace(/[^a-z0-9_]/g,'');
    const rowCls = `audit-row-${safeAction}`;
    const label = ACTION_LABELS[l.action] || esc(l.action);
    return `<tr class="${rowCls}"><td>${fmtAuditTs(l.ts)}</td><td>${label}</td><td>${esc(l.details)}</td></tr>`;
  }).join('');
}

function clearAuditLog() {
  if (!confirm('למחוק את יומן הביקורת? הפעולה אינה הפיכה')) return;
  localStorage.removeItem(AUDIT_KEY);
  renderAuditLog();
  toast('יומן נוקה', 'success');
}

// ══════════════════════════════════════════════
// FEATURE 4 — SOFT DELETE / RECYCLE BIN
// ══════════════════════════════════════════════
function restoreTrade(type, id) {
  const arr = type==='stock' ? db.stocks : db.crypto;
  const tr = arr.find(t => t.id === id);
  if (tr) { tr.deleted = false; delete tr.deletedAt; saveDB(); }
  renderTable(type);
  renderRecycleBin(type);
  toast('עסקה שוחזרה', 'success');
}

function renderRecycleBin(type) {
  const containerId = type === 'stock' ? 'recycle-stock' : 'recycle-crypto';
  let container = document.getElementById(containerId);
  if (!container) return;
  const arr = type==='stock' ? db.stocks : db.crypto;
  const deleted = arr.filter(t => t.deleted);
  const body = container.querySelector('.recycle-body');
  const header = container.querySelector('.recycle-header');
  if (header) {
    header.querySelector('.recycle-count').textContent = deleted.length ? ` (${deleted.length})` : '';
  }
  if (!body) return;
  if (!deleted.length) {
    body.innerHTML = '<div style="color:var(--text3);font-size:12px;padding:8px 0;">הסל ריק</div>';
    return;
  }
  body.innerHTML = deleted.map(tr => {
    const deletedDate = tr.deletedAt ? new Date(tr.deletedAt).toLocaleDateString('he-IL') : '—';
    return `<div class="recycle-item">
      <span><span class="recycle-sym">${esc(tr.symbol)}</span><span class="recycle-date">${fmtDate(tr.entryDate)}</span></span>
      <span style="color:var(--text3);font-size:11px;">נמחק: ${deletedDate}</span>
      <button class="btn btn-secondary btn-sm" onclick="restoreTrade('${type}',${tr.id})">↩ שחזר</button>
    </div>`;
  }).join('');
}

async function _migrateCommission() {
  const FLAG = 'comm_migrated_5';
  if (localStorage.getItem(FLAG) || !_currentUser) return;
  const { error } = await _sb.from('trades')
    .update({ commission: 5.0 })
    .eq('user_id', _currentUser.id)
    .eq('commission', 2.5);
  if (!error) localStorage.setItem(FLAG, '1');
}

function cleanOldDeleted() {
  const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;
  const cutoff = Date.now() - THIRTY_DAYS;
  let changed = false;
  ['stocks','crypto'].forEach(key => {
    const before = db[key].length;
    db[key] = db[key].filter(t => !(t.deleted && t.deletedAt && t.deletedAt < cutoff));
    if (db[key].length !== before) changed = true;
  });
  if (changed) saveDB();
}

// ─────────────────────────────────────────────
// REAL-TIME MARKET DATA (Yahoo Finance)
// ─────────────────────────────────────────────
const RT_CACHE    = {};   // symbol → { price, name, currency, ts }
const RT_DEBOUNCE = {};   // inputId → timeoutId
const RT_TTL      = 5 * 60 * 1000; // 5 min cache

// Normalize symbol for Yahoo Finance
// Crypto: BTC → BTC-USD, ETH → ETH-USD (unless already has hyphen pair)
function rtYahooSym(raw, isCrypto) {
  const s = raw.toUpperCase().trim();
  if (!s) return '';
  if (isCrypto) {
    if (s.includes('-')) return s;          // already BTC-USD style
    if (s.endsWith('USDT')) return s.slice(0, -4) + '-USD';
    if (s.endsWith('USD'))  return s.slice(0, -3) + '-USD';
    return s + '-USD';
  }
  return s;
}

// Validate symbol against loaded symbol lists (no API call needed)
async function rtFetchQuote(yahooSym) {
  if (!yahooSym) return null;
  const cached = RT_CACHE[yahooSym];
  if (cached && Date.now() - cached.ts < RT_TTL) return cached;

  const s = yahooSym.toUpperCase().trim();

  // Check crypto symbols (BTC-USD → BTC)
  const cryptoBase = s.includes('-') ? s.split('-')[0] : s.replace(/USDT?$/, '');
  const isCryptoSym = CRYPTO_SYMBOLS.has(cryptoBase) || CRYPTO_SYMBOLS.has(s);

  // Check stock symbols
  const stockBase = s.split(':')[0];
  const isStockSym = STOCK_SYMBOLS.has(stockBase) || STOCK_SYMBOLS.has(s);

  if (isCryptoSym || isStockSym) {
    const entry = { symbol: s, price: 0, name: s, currency: 'USD', ts: Date.now() };
    RT_CACHE[yahooSym] = entry;
    return entry;
  }

  return null;
}

// Validate symbol input with 700ms debounce + visual feedback
// isCryptoCheckId: id of crypto checkbox element (or null), isCryptoOverride: boolean override
function rtValidate(inputId, statusId, isCryptoCheckId, isCryptoOverride) {
  clearTimeout(RT_DEBOUNCE[inputId]);
  const inp = document.getElementById(inputId);
  const st  = document.getElementById(statusId);
  if (!inp || !st) return;
  const raw = inp.value.trim();
  if (!raw) { st.textContent = ''; st.className = 'sym-status'; inp.dataset.symValid = ''; return; }

  st.textContent = '⏳ מאמת...';
  st.className = 'sym-status loading';

  RT_DEBOUNCE[inputId] = setTimeout(async () => {
    const isCrypto = isCryptoOverride !== undefined
      ? isCryptoOverride
      : (isCryptoCheckId ? (document.getElementById(isCryptoCheckId)?.checked || false) : false);
    const ySym = rtYahooSym(raw, isCrypto);
    const q = await rtFetchQuote(ySym);
    if (!q) {
      st.innerHTML = '✗ סימבול לא נמצא';
      st.className = 'sym-status invalid';
      inp.dataset.symValid = '0';
    } else {
      st.innerHTML = `✓ סימבול מזוהה`;
      st.className = 'sym-status valid';
      inp.dataset.symValid = '1';
      inp.dataset.symPrice = q.price;
    }
  }, 700);
}

// ─────────────────────────────────────────────
// SYMBOL AUTOCOMPLETE
// ─────────────────────────────────────────────
let _symAcIdx = -1;

function symAcShow(inputId, dropId) {
  const inp = document.getElementById(inputId);
  const drop = document.getElementById(dropId);
  if (!inp || !drop) return;
  const q = inp.value.trim().toUpperCase();
  if (!q || q.length < 1) { drop.style.display = 'none'; return; }

  // Gather matches: stocks first, then crypto
  const stockMatches = [...STOCK_SYMBOLS].filter(s => s.startsWith(q)).slice(0, 8);
  const cryptoMatches = [...CRYPTO_SYMBOLS].filter(s => s.startsWith(q) && !stockMatches.includes(s)).slice(0, 4);
  const all = [
    ...stockMatches.map(s => ({ s, type: 'מניה' })),
    ...cryptoMatches.map(s => ({ s, type: 'קריפטו' }))
  ];

  if (!all.length) { drop.style.display = 'none'; return; }

  drop.innerHTML = all.map((item, i) =>
    `<div class="sym-ac-item" data-sym="${item.s}" onmousedown="symAcPick('${inputId}','${dropId}','${item.s}')">${item.s}<span class="sym-ac-tag">${item.type}</span></div>`
  ).join('');
  drop.style.display = 'block';
  _symAcIdx = -1;
}

function symAcPick(inputId, dropId, sym) {
  const inp = document.getElementById(inputId);
  const drop = document.getElementById(dropId);
  if (inp) { inp.value = sym; inp.dispatchEvent(new Event('input')); }
  if (drop) drop.style.display = 'none';
}

function symAcKey(e, inputId, dropId) {
  const drop = document.getElementById(dropId);
  if (!drop || drop.style.display === 'none') return;
  const items = drop.querySelectorAll('.sym-ac-item');
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    _symAcIdx = Math.min(_symAcIdx + 1, items.length - 1);
    items.forEach((el, i) => el.classList.toggle('active', i === _symAcIdx));
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    _symAcIdx = Math.max(_symAcIdx - 1, 0);
    items.forEach((el, i) => el.classList.toggle('active', i === _symAcIdx));
  } else if (e.key === 'Enter' && _symAcIdx >= 0) {
    e.preventDefault();
    const sym = items[_symAcIdx]?.dataset?.sym;
    if (sym) symAcPick(inputId, dropId, sym);
  } else if (e.key === 'Escape') {
    drop.style.display = 'none';
  }
}

// Close dropdown when clicking outside
document.addEventListener('click', e => {
  document.querySelectorAll('.sym-ac-drop').forEach(d => {
    if (!d.parentElement?.contains(e.target)) d.style.display = 'none';
  });
});

// Auto-fill the price input that's in the same widget as the symbol input
function rtAutoFill(symInputId, statusId) {
  const inp = document.getElementById(symInputId);
  if (!inp || !inp.dataset.symPrice) return;
  const price = parseFloat(inp.dataset.symPrice);
  if (!price) return;
  // Detect which widget: quick-add (qa-) or modal (m-)
  const priceId = symInputId.startsWith('qa-') ? 'qa-entry' : 'm-entry';
  const priceInp = document.getElementById(priceId);
  if (priceInp) {
    priceInp.value = price;
    priceInp.dispatchEvent(new Event('input'));
    toast('📈 מחיר עודכן: $' + fmtPrice(price), 'success');
  }
}

// ─────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────
(async function initApp() {
  // Show auth overlay immediately — hide after session confirmed
  document.getElementById('auth-overlay').style.display = 'flex';

  // Always-on initializations (don't need auth)
  qaInit();
  initMediaDB().catch(e => console.warn('[Screenshots] IndexedDB init failed:', e));
  ttScheduleMidnight();

  // Check for an existing Supabase session (persisted from last visit)
  const { data: { session } } = await _sb.auth.getSession();
  if (session?.user) {
    _currentSession = session;
    await _onAuthSuccess(session.user);
  }
  // else auth overlay stays visible

  // Listen for future auth state changes (sign in / sign out / token refresh)
  _sb.auth.onAuthStateChange(async (event, session) => {
    if (session) _currentSession = session;
    if (event === 'SIGNED_IN' && !_currentUser && session?.user) {
      await _onAuthSuccess(session.user);
    }
    if (event === 'TOKEN_REFRESHED' && session) {
      _currentSession = session;
    }
    if (event === 'SIGNED_OUT') {
      _teardownRealtimeSync();
      _currentUser = null;
      _currentSession = null;
      db = { stocks: [], crypto: [] };
      document.getElementById('auth-overlay').style.display = 'flex';
    }
  });
})();

// ══════════════════════════════════════════════
// FLEX WEB SERVICE — IBKR סנכרון אוטומטי
// ══════════════════════════════════════════════
const FLEX_TOKEN_KEY = 'flex-token';
const FLEX_QID_KEY   = 'flex-query-id';

function toggleReveal(id, btn) {
  const el = document.getElementById(id);
  if (!el) return;
  const hide = el.type === 'password';
  el.type = hide ? 'text' : 'password';
  btn.querySelector('svg').innerHTML = hide
    ? '<path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>'
    : '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
}

// Broker connection badge — reflects the REAL last-sync outcome, not just
// "credentials saved". States: ok (verified), pending (saved, not yet synced),
// error (a real connection/auth failure), none (no credentials → hidden).
function _setBrokerBadge(broker, state) {
  const el = document.getElementById(broker + '-conn-dot');
  if (!el) return;
  // 'syncing' is a transient live state — never persist it.
  if (_currentUser && state !== 'none' && state !== 'syncing') localStorage.setItem(broker + '_conn_' + _currentUser.id, state);
  const map = {
    ok:      { t: 'מחובר',        bg: 'rgba(63,185,80,0.15)',  fg: '#3fb950', bd: 'rgba(63,185,80,0.3)' },
    syncing: { t: 'מסנכרן…',      bg: 'rgba(79,131,255,0.15)', fg: '#4f83ff', bd: 'rgba(79,131,255,0.35)' },
    pending: { t: 'ממתין לסנכרון', bg: 'rgba(210,153,34,0.15)', fg: '#d29922', bd: 'rgba(210,153,34,0.3)' },
    error:   { t: 'בעיית חיבור',   bg: 'rgba(248,81,73,0.15)',  fg: '#f85149', bd: 'rgba(248,81,73,0.3)' },
  };
  const m = map[state];
  // Mirror IBKR (primary broker) status onto the always-visible header dot.
  if (broker === 'ibkr') {
    const hd = document.getElementById('header-broker-dot');
    if (hd) {
      if (!m) hd.style.display = 'none';
      else { hd.style.background = m.fg; hd.style.display = 'inline-block'; }
    }
  }
  if (!m) { el.style.display = 'none'; el.classList.remove('broker-badge-syncing'); return; }
  el.textContent = m.t;
  el.style.background = m.bg;
  el.style.color = m.fg;
  el.style.borderColor = m.bd;
  el.style.display = 'inline-block';
  el.classList.toggle('broker-badge-syncing', state === 'syncing');
}

function _brokerBadgeFromStore(broker, hasCreds) {
  if (!hasCreds) { _setBrokerBadge(broker, 'none'); return; }
  const stored = _currentUser ? localStorage.getItem(broker + '_conn_' + _currentUser.id) : null;
  _setBrokerBadge(broker, stored || 'pending');
}

function flexInit() {
  const hasToken = !!_userSettings.flex_token;
  const statusEl = document.getElementById('flex-status');
  if (statusEl && hasToken) flexSetStatus('פרטי IBKR שמורים ✓', 'var(--green)');
  _brokerBadgeFromStore('ibkr', hasToken);
}

function toggleIbkrCard() {
  document.getElementById('ibkr-sync-card')?.classList.toggle('collapsed');
}

function _setAvatar(url) {
  ['nav-avatar-img','avatar-preview-img','header-avatar-img'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    if (url) { el.src = url; el.style.display = 'block'; }
    else { el.src = ''; el.style.display = 'none'; }
  });
  ['nav-avatar-placeholder','avatar-preview-placeholder','header-avatar-placeholder'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = url ? 'none' : '';
  });
  const hav = document.getElementById('header-avatar');
  if (hav) hav.style.borderColor = url ? 'rgba(129,140,248,0.5)' : 'rgba(129,140,248,0.25)';
}


function switchSettingsPanel(id) {
  document.querySelectorAll('.s-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.s-nav-item').forEach(i => i.classList.remove('active'));
  document.getElementById('s-panel-' + id)?.classList.add('active');
  document.querySelector(`.s-nav-item[data-panel="${id}"]`)?.classList.add('active');
}

async function settingsChangePassword() {
  const pw  = document.getElementById('pw-new')?.value?.trim();
  const pw2 = document.getElementById('pw-confirm')?.value?.trim();
  const st  = document.getElementById('pw-change-status');
  if (!pw) { st.textContent = 'Enter a new password.'; st.style.color = 'var(--red)'; return; }
  if (pw !== pw2) { st.textContent = 'Passwords do not match.'; st.style.color = 'var(--red)'; return; }
  if (pw.length < 6) { st.textContent = 'Minimum 6 characters.'; st.style.color = 'var(--red)'; return; }
  st.textContent = 'Saving…'; st.style.color = 'var(--text3)';
  const { error } = await _sb.auth.updateUser({ password: pw });
  if (error) { st.textContent = error.message; st.style.color = 'var(--red)'; return; }
  st.textContent = 'Password updated.'; st.style.color = 'var(--green)';
  document.getElementById('pw-new').value = '';
  document.getElementById('pw-confirm').value = '';
  setTimeout(() => { st.textContent = ''; }, 3000);
}

function toggleExpand(bodyId, rowId) {
  const body = document.getElementById(bodyId);
  const row  = document.getElementById(rowId);
  if (!body || !row) return;
  const isOpen = body.classList.toggle('open');
  row.classList.toggle('open', isOpen);
}

async function flexSave() {
  const t = document.getElementById('flex-token')?.value.trim();
  const q = document.getElementById('flex-query-id')?.value.trim();
  if (!t || !q) { toast('נא להזין Token ו-Query ID', 'error'); return; }
  if (!/^[a-zA-Z0-9]{6,64}$/.test(t)) { toast('Token לא תקין — מספרים ואותיות בלבד, לפחות 6 תווים', 'error'); return; }
  if (!/^\d{4,15}$/.test(q)) { toast('Query ID לא תקין — מספרים בלבד (לדוגמה: 1462900)', 'error'); return; }
  await _saveUserSettings({ flex_token: t, flex_query_id: q });
  toast('פרטי IBKR נשמרו ✓', 'success');
  flexSetStatus('פרטים נשמרו — יסונכרן אוטומטית', 'var(--text2)');
  _setBrokerBadge('ibkr', 'pending');
}

function flexSetStatus(msg, color) {
  const el = document.getElementById('flex-status');
  if (el) { el.textContent = msg; el.style.color = color || 'var(--text3)'; }
}

async function flexSync() {
  const jwt = await _getToken();
  if (!jwt) { toast('נא להתחבר תחילה', 'error'); return; }

  const btn = document.getElementById('flex-sync-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ מסנכרן...'; }
  _setBrokerBadge('ibkr', 'syncing');
  flexSetStatus('מסנכרן עם IBKR...', 'var(--text2)');

  try {
    // Prefer the server pre-fetched statement — instant, no 1001.
    if (await _flexImportFromCache()) return;
    const trades = await _flexFetch(jwt);
    _flexMarkSync(true);
    _setBrokerBadge('ibkr', 'ok');
    const { imported, updated } = await _flexImport(trades);
    if (imported > 0 || updated > 0) {
      const msg = [imported ? `${imported} נוספו` : '', updated ? `${updated} עודכנו` : ''].filter(Boolean).join(' | ');
      flexSetStatus(`✓ ${msg}`, 'var(--green)');
      toast(`✓ IBKR: ${msg}`, 'success');
    } else {
      flexSetStatus('✓ סונכרן — אין עסקאות חדשות', 'var(--text3)');
    }
  } catch(e) {
    // Record the failure so the background backoff extends too.
    _flexMarkSync(false);
    if (e.busy) {
      // IBKR temporarily busy — calm note, still connected; restore last state.
      _brokerBadgeFromStore('ibkr', true);
      flexSetStatus('IBKR עמוס כרגע — ננסה אוטומטית בקרוב 🕐  (אם זה חוזר: ודא שה‑Query על "Last 365 Calendar Days")', 'var(--text2)');
    } else {
      _setBrokerBadge('ibkr', 'error');
      flexSetStatus('שגיאה: ' + e.message, 'var(--red)');
      toast('סנכרון נכשל: ' + e.message, 'error');
    }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'סנכרן'; }
  }
}

function flexExtractTag(xml, tag) {
  const m = xml.match(new RegExp(`<${tag}>([^<]*)</${tag}>`));
  return m ? m[1].trim() : '';
}

function flexParseXML(xml) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, 'text/xml');
  const tradeEls = [...doc.querySelectorAll('Trade')];

  // Group executions by symbol
  const bySymbol = {};
  tradeEls.forEach(el => {
    const sym   = el.getAttribute('symbol') || '';
    const dt    = el.getAttribute('dateTime') || '';
    const side  = (el.getAttribute('buySell') || '').toUpperCase();
    const qty   = Math.abs(+el.getAttribute('quantity') || 0);
    const price = +el.getAttribute('tradePrice') || 0;
    const comm  = Math.abs(+el.getAttribute('ibCommission') || 0);
    const tid   = el.getAttribute('tradeID') || el.getAttribute('ibExecID') || ''; // IBKR's unique execution id
    if (!sym || !dt || !side || !qty || !price) return;

    // Parse date: yyyyMMdd;HHmmss
    const datePart = dt.split(';')[0] || '';
    const date = datePart.length === 8
      ? `${datePart.slice(0,4)}-${datePart.slice(4,6)}-${datePart.slice(6,8)}`
      : '';
    if (!date) return;

    if (!bySymbol[sym]) bySymbol[sym] = { buys: [], sells: [] };
    const entry = { date, price, qty, comm, dt, tid };
    if (side === 'BUY')  bySymbol[sym].buys.push(entry);
    if (side === 'SELL') bySymbol[sym].sells.push(entry);
  });

  const trades = [];
  const r6 = n => Math.round(n * 1e6) / 1e6;
  Object.entries(bySymbol).forEach(([symbol, { buys, sells }]) => {
    const type = symIsCrypto(symbol) ? 'crypto' : 'stock';

    // Single chronological execution stream so closes are matched to the right
    // opening lot, FIFO. Each BUY opens/adds a long lot; each SELL consumes open
    // long lots (consuming shares so the same sell is never reused). A SELL with
    // no open lot left is an orphan close (position opened before the window).
    const execs = [
      ...buys.map(b  => ({ ...b, side: 'BUY' })),
      ...sells.map(s => ({ ...s, side: 'SELL' })),
    ].sort((a, b) => a.dt.localeCompare(b.dt));

    let lots = []; // open long lots: { qty, remaining, price, comm, date, dt, exits:[] }
    const finalize = lot => {
      const trade = {
        symbol, type, ls: 'L',
        entryDate:  lot.date,
        entryPrice: lot.price,
        shares:     lot.qty,
        commission: r6(lot.comm + lot.exits.reduce((s, e) => s + e.comm, 0)),
        stop: 0, ecn: 0,
        entry_reason: '', market_cond: '', process_score: 0,
        notes_keep: '', notes_improve: '',
      };
      if (lot.tid) trade.ibkr_id = lot.tid; // IBKR's unique entry-execution id
      if (lot.exits.length) {
        const last = lot.exits[lot.exits.length - 1];
        trade.exitPrice    = last.price;
        trade.closeDate    = last.date;
        trade.closedShares = lot.exits.reduce((s, e) => s + e.qty, 0); // total closed
        if (lot.exits.length > 1) trade.t = lot.exits.slice(0, -1).map(e => ({ price: e.price, shares: e.qty }));
      }
      trades.push(trade);
    };

    for (const ex of execs) {
      if (ex.side === 'BUY') {
        lots.push({ qty: ex.qty, remaining: ex.qty, price: ex.price, comm: ex.comm, date: ex.date, dt: ex.dt, tid: ex.tid, exits: [] });
        continue;
      }
      // SELL — close open long lots FIFO, splitting across lots as needed.
      let q = ex.qty;
      while (q > 1e-9 && lots.length) {
        const lot = lots[0];
        const take = Math.min(lot.remaining, q);
        lot.exits.push({ price: ex.price, qty: take, date: ex.date, dt: ex.dt, comm: ex.comm * (take / ex.qty) });
        lot.remaining -= take;
        q -= take;
        if (lot.remaining <= 1e-9) { lots.shift(); finalize(lot); }
      }
      if (q > 1e-9) {
        // No open lot to close — position was opened before the Flex window.
        trades.push({
          symbol, type, _orphanClose: true,
          exitPrice:    ex.price,
          closeDate:    ex.date,
          closedShares: q,
          commission:   r6(ex.comm * (q / ex.qty)),
          _exitDt:      ex.dt,
          ...(ex.tid ? { ibkr_id: ex.tid } : {}),
        });
      }
    }
    lots.forEach(finalize); // leftover open / partially-closed positions
  });

  return trades;
}

function flexIsDuplicate(t) {
  const fp = `${t.symbol}||${t.entryDate}||${Math.round((t.entryPrice||0)*1000)}||${Math.round((t.shares||0)*1000)}`;
  if (db._deletedFingerprints?.has(fp)) return true;
  const arr = t.type === 'crypto' ? db.crypto : db.stocks;
  return arr.some(x =>
    x.symbol === t.symbol &&
    x.entryDate === t.entryDate &&
    Math.abs(x.entryPrice - t.entryPrice) < 0.01 &&
    Math.abs((x.shares || 0) - (t.shares || 0)) < 0.01
  );
}

// Init on tab open — pre-fill saved credentials
document.addEventListener('DOMContentLoaded', flexInit);

// ══════════════════════════════════════════════
// BYBIT SYNC
// ══════════════════════════════════════════════

function bybitInit() {
  const hasKey = !!_userSettings.bybit_api_key;
  if (hasKey) bybitSetStatus('פרטי Bybit שמורים ✓', 'var(--green)');
  _brokerBadgeFromStore('bybit', hasKey);
}

function bybitSetStatus(msg, color) {
  const el = document.getElementById('bybit-status');
  if (el) { el.textContent = msg; el.style.color = color || 'var(--text3)'; }
}

async function bybitSave() {
  const k = document.getElementById('bybit-api-key')?.value.trim();
  const s = document.getElementById('bybit-api-secret')?.value.trim();
  if (!k) { toast('נא להזין API Key', 'error'); return; }
  // Secret is write-only: required on first save, optional afterwards (kept server-side)
  const hasExisting = !!(_userSettings && _userSettings.bybit_api_key);
  if (!s && !hasExisting) { toast('נא להזין API Key ו-Secret', 'error'); return; }
  const payload = { bybit_api_key: k };
  if (s) payload.bybit_api_secret = s;
  await _saveUserSettings(payload);
  toast('פרטי Bybit נשמרו ✓', 'success');
  bybitSetStatus('פרטים נשמרו — יסונכרן אוטומטית', 'var(--text2)');
  _setBrokerBadge('bybit', 'pending');
}

async function bybitSync() {
  const jwt = await _getToken();
  if (!jwt) { toast('נא להתחבר תחילה', 'error'); return; }
  const btn = document.getElementById('bybit-sync-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ מסנכרן...'; }
  _setBrokerBadge('bybit', 'syncing');
  bybitSetStatus('מסנכרן עם Bybit...', 'var(--text2)');
  document.getElementById('bybit-preview').innerHTML = '';
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/bybit`, {
      headers: { Authorization: `Bearer ${jwt}` }
    });
    const json = await res.json();
    if (!res.ok || json.error) throw new Error(json.error || 'שגיאה');
    _setBrokerBadge('bybit', 'ok');
    const trades = json.trades || [];
    bybitSetStatus(`נמצאו ${trades.length} עסקאות`, 'var(--green)');
    bybitRenderPreview(trades);
  } catch(e) {
    _setBrokerBadge('bybit', 'error');
    bybitSetStatus('שגיאה: ' + e.message, 'var(--red)');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Sync'; }
  }
}

function bybitRenderPreview(trades) {
  const container = document.getElementById('bybit-preview');
  if (!trades.length) {
    container.innerHTML = '<div style="font-size:12px;color:var(--text3);padding:10px 0;">לא נמצאו עסקאות סגורות</div>';
    return;
  }
  const rows = trades.map((t, i) => {
    const pnl = t.pnl >= 0 ? `+$${t.pnl.toFixed(2)}` : `-$${Math.abs(t.pnl).toFixed(2)}`;
    const pnlColor = t.pnl >= 0 ? 'var(--green)' : 'var(--red)';
    return `
      <div class="ibkr-trade-preview">
        <div>
          <div class="sym">${esc(t.symbol)}</div>
          <div class="det">${t.ls} · ${t.entryDate} → ${t.closeDate}</div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:12px;color:var(--text2);">${t.shares} @ ${t.entryPrice} → ${t.exitPrice}</div>
          <div style="font-weight:700;color:${pnlColor}">${pnl}</div>
        </div>
        <button class="btn btn-secondary btn-sm" id="bybit-btn-${i}" onclick="bybitImportOne(${i})" style="font-size:11px;padding:4px 10px;">Import</button>
      </div>`;
  }).join('');
  container.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;margin-top:8px;">
      <span style="font-size:12px;color:var(--text2);">${trades.length} עסקאות נמצאו</span>
      <button class="btn btn-primary btn-sm" onclick="bybitImportAll()">Import All</button>
    </div>` + rows;
  window._bybitPendingTrades = trades;
}

async function bybitImportOne(idx) {
  const t = window._bybitPendingTrades?.[idx];
  if (!t) return;
  const btn = document.getElementById(`bybit-btn-${idx}`);
  if (btn) { btn.disabled = true; btn.textContent = '⏳...'; }
  const { data: inserted, error } = await _sb.from('trades').insert(_tradeToRow({ ...t, deleted: false })).select().single();
  if (error) {
    toast('שגיאה בשמירה: ' + error.message, 'error');
    if (btn) { btn.disabled = false; btn.textContent = 'Import'; }
    return;
  }
  db.crypto.unshift(_rowToTrade(inserted));
  renderTable('crypto');
  if (btn) { btn.textContent = '✓ Imported'; }
  toast(`${t.symbol} יובא בהצלחה`, 'success');
}

async function bybitImportAll() {
  const trades = window._bybitPendingTrades || [];
  if (!trades.length) return;
  let imported = 0, dupes = 0;
  for (const t of trades) {
    const fp = `${t.symbol}||${t.entryDate}||${Math.round((t.entryPrice||0)*1000)}||${Math.round((t.shares||0)*1000)}`;
    if (db._deletedFingerprints?.has(fp)) { dupes++; continue; }
    const existing = db.crypto.find(e =>
      `${e.symbol}||${e.entryDate}||${Math.round((e.entryPrice||0)*1000)}||${Math.round((e.shares||0)*1000)}` === fp
    );
    if (existing) { dupes++; continue; }
    const { data, error } = await _sb.from('trades').insert(_tradeToRow({ ...t, deleted: false })).select().single();
    if (!error) { db.crypto.unshift(_rowToTrade(data)); imported++; }
  }
  renderTable('crypto');
  toast(`יובאו ${imported} עסקאות${dupes ? ` (${dupes} כפולות דולגו)` : ''}`, 'success');
}

// ══════════════════════════════════════════════
// TOTP 2FA — RFC 6238 — גורם שני לאימות
// ══════════════════════════════════════════════
const TOTP_KEY         = 'tj-totp-secret';
const TOTP_ENABLED_KEY = 'tj-totp-enabled';
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function b32Encode(bytes) {
  let bits = 0, val = 0, out = '';
  for (const b of bytes) { val = (val<<8)|b; bits+=8; while(bits>=5){out+=B32[(val>>>(bits-5))&31];bits-=5;} }
  if (bits>0) out+=B32[(val<<(5-bits))&31];
  return out;
}
function b32Decode(s) {
  s = s.replace(/=+$/,'').toUpperCase();
  let bits=0,val=0; const out=[];
  for(const c of s){const i=B32.indexOf(c);if(i<0)throw new Error('bad b32');val=(val<<5)|i;bits+=5;if(bits>=8){out.push((val>>>(bits-8))&255);bits-=8;}}
  return new Uint8Array(out);
}
async function _totpCode(secret, ts=Date.now()) {
  const ctr = Math.floor(ts/30000);
  const key = await crypto.subtle.importKey('raw',b32Decode(secret),{name:'HMAC',hash:'SHA-1'},false,['sign']);
  const buf = new ArrayBuffer(8);
  new DataView(buf).setUint32(4,ctr>>>0,false);
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC',key,buf));
  const off = sig[19]&0xf;
  const num = ((sig[off]&0x7f)<<24)|((sig[off+1]&0xff)<<16)|((sig[off+2]&0xff)<<8)|(sig[off+3]&0xff);
  return String(num%1000000).padStart(6,'0');
}
async function totpVerify(secret, code) {
  const now = Date.now();
  for(const d of[-1,0,1]) { if(await _totpCode(secret,now+d*30000)===code) return true; }
  return false;
}
function totpEnabled() { return localStorage.getItem(TOTP_ENABLED_KEY)==='1'; }

// TOTP overlay step (shown after PIN)
let _totpPendingUnlock = false;
async function totpStep() {
  if (!totpEnabled()) { pinUnlock(); return; }
  _totpPendingUnlock = true;
  document.getElementById('pin-sub-text').textContent = 'הכנס קוד 6 ספרות מה-Authenticator';
  document.getElementById('pin-totp-row').style.display = 'flex';
  document.getElementById('totp-input').focus();
}
const TOTP_ATTEMPTS_KEY = 'tj-totp-attempts';
const TOTP_LOCKOUT_KEY  = 'tj-totp-lockout';
const TOTP_MAX_ATTEMPTS = 5;

function getTotpAttempts() { return parseInt(localStorage.getItem(TOTP_ATTEMPTS_KEY)||'0'); }
function setTotpAttempts(n) { localStorage.setItem(TOTP_ATTEMPTS_KEY, String(n)); }
function isTotpLockedOut() {
  const until = parseInt(localStorage.getItem(TOTP_LOCKOUT_KEY)||'0');
  return Date.now() < until;
}

async function totpSubmit() {
  if (!_totpPendingUnlock) return;
  if (isTotpLockedOut()) { pinMsg('2FA נעול — נסה שוב עוד מספר דקות'); return; }
  const code  = (document.getElementById('totp-input')?.value||'').trim();
  const secret= await secLoad(TOTP_KEY);
  if (!secret||code.length!==6) { pinMsg('קוד לא תקין'); return; }
  if (await totpVerify(secret,code)) {
    _totpPendingUnlock = false;
    document.getElementById('pin-totp-row').style.display='none';
    document.getElementById('totp-input').value='';
    setPinAttempts(0);
    setTotpAttempts(0);
    localStorage.removeItem(TOTP_LOCKOUT_KEY);
    auditLog('2fa_unlocked');
    pinUnlock();
  } else {
    pinMsg('קוד שגוי — נסה שוב');
    document.getElementById('totp-input').value='';
    const a = getTotpAttempts() + 1; setTotpAttempts(a);
    auditLog('2fa_failed');
    if (a >= TOTP_MAX_ATTEMPTS) {
      const ms = getLockoutDuration(a);
      localStorage.setItem(TOTP_LOCKOUT_KEY, String(Date.now() + ms));
      showLockoutMsg();
    }
  }
}

// TOTP setup — secret lives only in this closure, not on window
let _totpSetupSecret = null;
async function totpSetupInit() {
  const bytes = crypto.getRandomValues(new Uint8Array(20));
  const secret = b32Encode(bytes);
  _totpSetupSecret = secret;
  const uri = `otpauth://totp/Trading%20Journal%202.0?secret=${secret}&issuer=TradingJournal&algorithm=SHA1&digits=6&period=30`;
  const div = document.getElementById('totp-setup-area');
  if (!div) return;
  div.style.display = 'block';
  div.innerHTML = `
    <div style="font-size:12px;color:var(--text2);margin-bottom:8px;">
      <strong>1.</strong> פתח את Google Authenticator / Authy<br>
      <strong>2.</strong> לחץ "+" → "הכנס מפתח ידנית"<br>
      <strong>3.</strong> הכנס את הסוד הבא:
    </div>
    <div style="font-family:monospace;font-size:14px;background:rgba(0,0,0,0.3);padding:10px;border-radius:6px;letter-spacing:2px;color:var(--accent);word-break:break-all;margin-bottom:10px;">${secret}</div>
    <div style="font-size:11px;color:var(--text3);margin-bottom:10px;">
      <a href="${esc(uri)}" style="color:var(--accent)">לחץ לפתיחה באפליקציה</a> &nbsp;|&nbsp; Algorithm: SHA1 · Digits: 6 · Period: 30s
    </div>
    <div style="display:flex;gap:8px;align-items:center;">
      <input id="totp-verify-input" class="form-control" type="text" inputmode="numeric" maxlength="6"
        placeholder="קוד 6 ספרות לאימות" style="width:160px;font-size:14px;letter-spacing:3px;">
      <button class="btn btn-primary btn-sm" onclick="totpSetupConfirm()">אמת והפעל</button>
      <button class="btn btn-secondary btn-sm" onclick="totpSetupCancel()">ביטול</button>
    </div>
    <div id="totp-verify-msg" style="margin-top:6px;font-size:12px;color:var(--red);"></div>`;
}
async function totpSetupConfirm() {
  const code   = (document.getElementById('totp-verify-input')?.value||'').trim();
  const secret = _totpSetupSecret;
  if (!secret) return;
  if (await totpVerify(secret,code)) {
    await secStore(TOTP_KEY,secret);
    localStorage.setItem(TOTP_ENABLED_KEY,'1');
    _totpSetupSecret=null;
    document.getElementById('totp-setup-area').style.display='none';
    document.getElementById('totp-status-text').textContent='🟢 פעיל';
    document.getElementById('totp-toggle-btn').textContent='🔴 בטל 2FA';
    auditLog('2fa_enabled');
    toast('אימות דו-שלבי הופעל ✅','success');
  } else {
    document.getElementById('totp-verify-msg').textContent='קוד שגוי — נסה שוב';
  }
}
function totpSetupCancel() {
  _totpSetupSecret=null;
  const d=document.getElementById('totp-setup-area'); if(d) d.style.display='none';
}
async function totpToggle() {
  if(totpEnabled()){
    if(!confirm(_lang==='he'?'לבטל אימות דו-שלבי? הגנת החשבון תפחת':'Disable two-factor authentication? This reduces account security.'))return;
    localStorage.removeItem(TOTP_ENABLED_KEY);
    localStorage.removeItem(TOTP_KEY);
    document.getElementById('totp-status-text').textContent='🔴 כבוי';
    document.getElementById('totp-toggle-btn').textContent='🟢 הפעל 2FA';
    auditLog('2fa_disabled');
    toast('2FA בוטל','warning');
  } else {
    if (!hasPIN()) {
      toast('יש להגדיר קוד PIN לפני הפעלת 2FA — האבטחה תלויה ב-PIN', 'error');
      return;
    }
    await totpSetupInit();
  }
}

// ══════════════════════════════════════════════
// SECURITY LAYER — הצפנת credentials + נעילה
// ══════════════════════════════════════════════

// ── AES-GCM encryption for sensitive localStorage values ──
// Key = PBKDF2( pinHash + origin, salt, 100k rounds )
// Without PIN: origin-only key (weaker but better than plaintext)
const SEC_SALT = new TextEncoder().encode('tj-credentials-v2');

async function _secKey() {
  const pinHash = localStorage.getItem(PIN_KEY) || 'no-pin';
  const raw = new TextEncoder().encode(pinHash + 'tj-local-app');
  const km  = await crypto.subtle.importKey('raw', raw, 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: SEC_SALT, iterations: 100000, hash: 'SHA-256' },
    km,
    { name: 'AES-GCM', length: 256 },
    false, ['encrypt','decrypt']
  );
}

async function secStore(lsKey, value) {
  if (!value) { localStorage.removeItem(lsKey); return; }
  const key = await _secKey();
  const iv  = crypto.getRandomValues(new Uint8Array(12));
  const enc = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    new TextEncoder().encode(value)
  );
  localStorage.setItem(lsKey, JSON.stringify({
    v: 2,
    iv:   Array.from(iv),
    data: Array.from(new Uint8Array(enc))
  }));
}

async function secLoad(lsKey) {
  const raw = localStorage.getItem(lsKey);
  if (!raw) return '';
  try {
    const parsed = JSON.parse(raw);
    if (!parsed.v || parsed.v < 2) return ''; // plaintext remnant → ignore
    const key = await _secKey();
    const dec = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: new Uint8Array(parsed.iv) },
      key,
      new Uint8Array(parsed.data)
    );
    return new TextDecoder().decode(dec);
  } catch(e) {
    console.warn('[Security] Failed to decrypt credential:', lsKey);
    localStorage.removeItem(lsKey); // wipe corrupted/unreadable data
    return '';
  }
}

// Re-encrypt credentials after PIN change (called from pinUnlock after setup)
async function reEncryptCredentials() {
  for (const key of [FLEX_TOKEN_KEY, FLEX_QID_KEY, FINNHUB_KEY_LS]) {
    const val = await secLoad(key);
    if (val) await secStore(key, val); // re-encrypt with new PIN-derived key
  }
}

// ── Auto-lock when tab is hidden ──
// If PIN is set: lock immediately when user switches away
document.addEventListener('visibilitychange', () => {
  if (document.hidden && hasPIN()) {
    lockNow();
  }
});

// ── Clear all sensitive fields from DOM on lock ──
// Prevents shoulder-surfing or form autofill leakage after unlock
const _origLockNow = lockNow;
lockNow = function() {
  _origLockNow();
  // Wipe token/key fields from DOM
  ['flex-token','flex-query-id','finnhub-key-input'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
};

// ── Re-fill credentials only when IBKR tab is opened (after unlock) ──
// (already handled by flexInit() + saveFinnhubKey() calling on tab switch)

// ══════════════════════════════════════════════
// SECURITY: No broker credentials stored in clear
// ══════════════════════════════════════════════
// Flex Token  → AES-GCM encrypted in localStorage (key derived from PIN+origin)
// Finnhub key → AES-GCM encrypted in localStorage (key derived from PIN+origin)
// PIN         → SHA-256 hashed with salt (never stored in clear)
// Account ID  → never stored (only appears in API responses, used transiently)
// Password    → never stored anywhere in this app
// ── Security status renderer ──
function renderSecurityStatus() {
  const setDot = (id, ok) => {
    const el = document.getElementById(id);
    if (el) el.className = 'sec-dot' + (ok ? '' : ' warn');
  };
  setDot('sec-pin-dot', hasPIN());
  setDot('sec-2fa-dot', totpEnabled());
  const pinLbl = document.getElementById('sec-pin-lbl');
  const he = _lang === 'he';
  if (pinLbl) pinLbl.textContent = hasPIN() ? (he?'PIN — פעיל':'PIN — Active') : (he?'PIN — לא מוגדר':'PIN — Not set');
  const pinBtn = document.getElementById('pin-setup-btn');
  if (pinBtn) pinBtn.textContent = hasPIN() ? (he?'שנה / מחק':'Change / Remove') : (he?'הגדר PIN':'Set PIN');
  const lbl2 = document.getElementById('sec-2fa-lbl');
  if (lbl2) lbl2.textContent = totpEnabled() ? (he?'TOTP — פעיל':'TOTP — Active') : (he?'TOTP — לא פעיל':'TOTP — Inactive');
  const tBtn = document.getElementById('totp-toggle-btn');
  const tTxt = document.getElementById('totp-status-text');
  if (tBtn && tTxt) {
    if (totpEnabled()) {
      tTxt.textContent = he?'פעיל':'Active';
      tBtn.textContent = he?'בטל 2FA':'Disable 2FA';
      tBtn.className = 'btn btn-danger btn-sm';
    } else {
      tTxt.textContent = he?'לא פעיל':'Inactive';
      tBtn.textContent = he?'הפעל 2FA':'Enable 2FA';
      tBtn.className = 'btn btn-primary btn-sm';
    }
  }
}

// ── PWA Service Worker ─────────────────────────────
// ── Sidebar Toggle (handled by merged function below) ──
// Close sidebar when a tab is clicked on mobile
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (window.innerWidth <= 768) toggleSidebar();
    });
  });
  calcBreakeven();
  // Restore portfolio total immediately on load (don't wait for tab click)
  const totalEl = document.getElementById('inv-portfolio-total');
  if (totalEl) {
    try {
      const saved = localStorage.getItem('inv_data_v1');
      if (saved) {
        const d = JSON.parse(saved);
        if (d.portfolioTotal) totalEl.value = d.portfolioTotal;
      }
    } catch {}
  }
});

// ── Theme System — Dynamic Stylesheet ──
// Injected <style> always wins cascade (comes after all static CSS)
function _buildLightCSS() {
  return `
    :root {
      color-scheme: light;
      --bg:#dde4ee; --bg2:#cdd6e2; --card:#f3f6fb; --card2:#eef2f8;
      --border:rgba(14,14,18,0.08); --border2:rgba(14,14,18,0.13);
      --text:#0f172a; --text2:#334155; --text3:#64748b;
      --accent:#0ea5e9; --accent2:#0284c7; --accent-glow:rgba(14,165,233,0.12);
      --green:#059669; --green-bg:rgba(5,150,105,0.1);
      --red:#e11d48; --red-bg:rgba(225,29,72,0.08);
      --yellow:#b45309; --yellow-bg:rgba(180,83,9,0.08);
      --sidebar-bg: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);
      --sidebar-border: #dde3ed;
    }
    body { background:#dde4ee !important; color:#0f172a !important;
      background-image: radial-gradient(ellipse 100% 50% at 50% -5%, rgba(14,165,233,0.05) 0%, transparent 60%) !important; }
    header { background:#eef2f8 !important; border-bottom:1px solid #e2e8f0 !important;
      box-shadow:0 1px 0 rgba(14,165,233,0.07),0 2px 12px rgba(0,0,0,0.06) !important; }
    .header-title { color:#0f172a !important; }
    .btn-secondary { background:#f1f5f9 !important; border:1px solid #cbd5e1 !important; color:#475569 !important; }
    .btn-export    { background:#f1f5f9 !important; border:1px solid #cbd5e1 !important; color:#475569 !important; }
    .inactivity-badge { background:#f1f5f9 !important; border-color:#cbd5e1 !important; color:var(--text3) !important; }

    /* Sidebar — high specificity to override base dark rule */
    html[data-theme="light"] .sidebar { background:linear-gradient(180deg,#f8fafc 0%,#f1f5f9 100%) !important; border-inline-end:1px solid #e2e8f0 !important; }
    html[data-theme="light"] #main-sidebar > * { background:transparent !important; }
    html[data-theme="light"] #main-sidebar .tab-btn { background:transparent !important; color:#475569 !important; }
    html[data-theme="light"] #main-sidebar .tab-btn:hover { background:rgba(14,165,233,0.08) !important; color:#0284c7 !important; }
    html[data-theme="light"] #main-sidebar .tab-btn.active { background:rgba(14,165,233,0.12) !important; color:#0284c7 !important; box-shadow:inset 0 0 0 1px rgba(14,165,233,0.2) !important; }
    html[data-theme="light"] .sidebar-brand { border-bottom-color:#e2e8f0 !important; }
    html[data-theme="light"] .sidebar-brand-name { color:#4f46e5 !important; }
    html[data-theme="light"] .sidebar-brand-dot { background:#0ea5e9 !important; }
    html[data-theme="light"] .sidebar-section-label { color:#94a3b8 !important; }
    html[data-theme="light"] .sidebar-footer { border-top-color:#e2e8f0 !important; background:transparent !important; }
    html[data-theme="light"] .sidebar-footer-text { color:#94a3b8 !important; }
    html[data-theme="light"] .tab-btn { color:#475569 !important; }
    html[data-theme="light"] .tab-btn:hover { color:#0f172a !important; background:rgba(14,165,233,0.07) !important; }
    html[data-theme="light"] .tab-btn.active { background:rgba(14,165,233,0.12) !important; color:#0284c7 !important; box-shadow:inset 0 0 0 1px rgba(14,165,233,0.2) !important; }
    html[data-theme="light"] .theme-toggle { background:#e9eef5 !important; border-color:#dde3ed !important; color:#64748b !important; }
    html[data-theme="light"] .nav-icon svg { stroke:#64748b !important; }
    html[data-theme="light"] .tab-btn.active .nav-icon svg { stroke:#0284c7 !important; }

    /* Cards */
    .kpi-card { background:#f3f6fb !important; border:1px solid #e2e8f0 !important; box-shadow:0 1px 6px rgba(0,0,0,0.06) !important; }
    .kpi-card::before,.kpi-card::after { display:none !important; }
    .kpi-card.c-green  { border-top:2px solid #059669 !important; }
    .kpi-card.c-red    { border-top:2px solid #e11d48 !important; }
    .kpi-card.c-blue   { border-top:2px solid #0ea5e9 !important; }
    .kpi-card.c-yellow { border-top:2px solid #b45309 !important; }
    .kpi-card.c-purple { border-top:2px solid #7c3aed !important; }
    .kpi-label { color:#64748b !important; }
    .kpi-value { color:#0f172a !important; }
    .kpi-value.green { color:#059669 !important; }
    .kpi-value.red   { color:#e11d48 !important; }
    .kpi-sub { color:#64748b !important; }
    .kpi-trend.up   { color:#059669 !important; background:rgba(5,150,105,0.1) !important; }
    .kpi-trend.down { color:#e11d48 !important; background:rgba(225,29,72,0.08) !important; }
    .kpi-trend.flat { color:#64748b !important; background:rgba(0,0,0,0.05) !important; }

    .chart-card { background:#f3f6fb !important; border:1px solid #e2e8f0 !important; box-shadow:0 2px 12px rgba(0,0,0,0.05) !important; }
    .chart-card::before { display:none !important; }
    .chart-title { color:#586475 !important; }
    .donut-stat-value.green { color:#047857 !important; }
    .donut-stat-value.red   { color:#be123c !important; }
    .comp-card  { background:#f3f6fb !important; border:1px solid #e2e8f0 !important; box-shadow:0 2px 12px rgba(0,0,0,0.05) !important; }
    .comp-card::before { display:none !important; }
    .comp-card h4 { color:#0f172a !important; }
    .comp-stat  { border-bottom-color:#f1f5f9 !important; }
    .comp-stat-label { color:#64748b !important; }
    .comp-stat-val { color:#0f172a !important; }
    .calc-card  { background:#f3f6fb !important; border:1px solid #e2e8f0 !important; box-shadow:0 2px 12px rgba(0,0,0,0.05) !important; }
    .calc-card h3 { color:#0ea5e9 !important; }
    .calc-divider { border-top-color:#e2e8f0 !important; }
    .overview-section { background:#f3f6fb !important; border:1px solid #e2e8f0 !important; }
    .ov-section-title { color:#64748b !important; }
    .ibkr-card  { background:#f3f6fb !important; border:1px solid #e2e8f0 !important; }
    .ibkr-card-header { border-bottom-color:#e2e8f0 !important; }
    .ibkr-card-title  { color:#0f172a !important; }
    /* Secondary labels darkened slightly to keep AA contrast on off-white cards */
    .kpi-label, .kpi-sub, .chart-title, .comp-stat-label, .ov-section-title { color:#586475 !important; }

    /* Table — use html[data-theme] prefix to beat specificity of static dark rules */
    html[data-theme="light"] .table-wrap { background:#f3f6fb !important; border:1px solid #e2e8f0 !important; box-shadow:0 2px 12px rgba(0,0,0,0.05) !important; }
    html[data-theme="light"] thead tr { background:#f8fafc !important; border-bottom:1px solid #e2e8f0 !important; }
    html[data-theme="light"] thead th { background:#f8fafc !important; }
    html[data-theme="light"] th { color:#64748b !important; }
    html[data-theme="light"] td { color:#0f172a !important; border-bottom-color:#f1f5f9 !important; }
    html[data-theme="light"] tbody tr.data-row:hover td { background:#f0f6ff !important; }
    html[data-theme="light"] tbody tr.profit td { background:rgba(5,150,105,0.03) !important; }
    html[data-theme="light"] tbody tr.profit:hover td { background:rgba(5,150,105,0.08) !important; }
    html[data-theme="light"] tbody tr.loss td { background:rgba(225,29,72,0.03) !important; }
    html[data-theme="light"] tbody tr.loss:hover td { background:rgba(225,29,72,0.07) !important; }
    html[data-theme="light"] .year-group-row td { background:#f8fafc !important; border-color:#e2e8f0 !important; }
    html[data-theme="light"] .year-group-label { color:#64748b !important; }
    html[data-theme="light"] .num-green  { color:#047857 !important; }
    html[data-theme="light"] .num-red    { color:#be123c !important; }
    html[data-theme="light"] .num-yellow { color:#b45309 !important; }
    html[data-theme="light"] .badge-L { background:rgba(5,150,105,0.12) !important; color:#059669 !important; border-color:rgba(5,150,105,0.28) !important; }
    html[data-theme="light"] .badge-S { background:rgba(225,29,72,0.1) !important; color:#e11d48 !important; border-color:rgba(225,29,72,0.25) !important; }

    /* Forms & Inputs */
    .month-filter { background:transparent !important; border-color:rgba(14,14,18,0.08) !important; }
    .month-filter label { color:#64748b !important; }
    select,select.form-control { background:#ffffff !important; border-color:#cbd5e1 !important; color:#0f172a !important; }
    select option { background:#ffffff !important; color:#0f172a !important; }
    input,textarea,.form-control,.qa-input { background:#ffffff !important; border-color:#cbd5e1 !important; color:#0f172a !important; }
    input::placeholder,.qa-input::placeholder { color:#94a3b8 !important; }
    .form-label { color:#0ea5e9 !important; }
    .search-input { background:#ffffff !important; border-color:#cbd5e1 !important; color:#0f172a !important; }

    /* Buttons & Pills */
    .er-pill { background:#f1f5f9 !important; border-color:#cbd5e1 !important; color:#475569 !important; }
    .er-pill.active-bo     { background:rgba(5,150,105,0.1) !important; border-color:#059669 !important; color:#059669 !important; }
    .er-pill.active-handle { background:rgba(234,88,12,0.1) !important; border-color:#ea580c !important; color:#ea580c !important; }
    .er-pill.active-cheath { background:rgba(180,83,9,0.1) !important; border-color:#b45309 !important; color:#b45309 !important; }
    .er-pill.active-cheatl { background:rgba(14,165,233,0.1) !important; border-color:#0284c7 !important; color:#0284c7 !important; }
    .er-pill.active-lps    { background:rgba(124,58,237,0.1) !important; border-color:#7c3aed !important; color:#7c3aed !important; }
    /* Quick Add */
    .quick-add { background:#ffffff !important; border-color:rgba(14,165,233,0.2) !important; }
    .quick-add-title { color:#0ea5e9 !important; }
    .qa-label { color:#64748b !important; }
    .qa-ls-btn { background:#f1f5f9 !important; border-color:#e2e8f0 !important; color:#64748b !important; }
    .qa-ls-btn.active-l { background:rgba(5,150,105,0.1) !important; color:#059669 !important; border-color:rgba(5,150,105,0.3) !important; }
    .qa-ls-btn.active-s { background:rgba(225,29,72,0.08) !important; color:#e11d48 !important; border-color:rgba(225,29,72,0.25) !important; }

    /* Expanded rows, notes */
    .expanded-inner { background:#f8fafc !important; border-top-color:#e2e8f0 !important; }
    .notes-box { background:#f1f5f9 !important; border-color:#e2e8f0 !important; color:#334155 !important; }
    .target-pill { background:#f1f5f9 !important; border-color:#e2e8f0 !important; color:#334155 !important; }

    /* Modal */
    .modal { background:#ffffff !important; border:1px solid #e2e8f0 !important; box-shadow:0 24px 64px rgba(0,0,0,0.14) !important; }
    .modal::before { display:none !important; }
    .modal-overlay { background:rgba(14,14,18,0.5) !important; }
    .modal-header { background:#f8fafc !important; border-bottom:1px solid #e2e8f0 !important; }
    .modal-footer { background:#f8fafc !important; border-top:1px solid #e2e8f0 !important; }
    .modal-title  { color:#0f172a !important; }
    .modal-close  { color:#64748b !important; }

    /* Toast */
    .toast { background:#ffffff !important; border:1px solid #e2e8f0 !important; box-shadow:0 8px 32px rgba(0,0,0,0.1) !important; color:#0f172a !important; }
    .toast.success { border:1px solid rgba(5,150,105,0.35) !important; background:rgba(5,150,105,0.07) !important; }
    .toast.error   { border:1px solid rgba(220,38,38,0.35) !important; background:rgba(220,38,38,0.07) !important; }

    /* Mood pills */
    .mood-pill { background:#f1f5f9 !important; border-color:#cbd5e1 !important; color:#475569 !important; }
    .mood-pill.active-focused   { background:rgba(14,165,233,0.1) !important; border-color:#0284c7 !important; color:#0284c7 !important; }
    .mood-pill.active-calm      { background:rgba(5,150,105,0.1) !important;  border-color:#059669 !important; color:#059669 !important; }
    .mood-pill.active-confident { background:rgba(124,58,237,0.1) !important; border-color:#7c3aed !important; color:#7c3aed !important; }
    .mood-pill.active-stressed  { background:rgba(220,38,38,0.1) !important;  border-color:#c0405c !important; color:#c0405c !important; }
    .mood-pill.active-impatient { background:rgba(234,88,12,0.1) !important;  border-color:#ea580c !important; color:#ea580c !important; }
    .mood-pill.active-doubtful  { background:rgba(100,116,139,0.1) !important; border-color:#64748b !important; color:#64748b !important; }

    /* Scrollbar */
    ::-webkit-scrollbar-thumb { background:rgba(0,0,0,0.15) !important; }
    ::-webkit-scrollbar-thumb:hover { background:rgba(0,0,0,0.25) !important; }

    /* Calendar — override dark html body .cal-* rules (specificity 0-1-2) with 0-2-1 */
    html[data-theme="light"] .cal-wrap { background:#ffffff !important; }
    html[data-theme="light"] .cal-header { background:#ffffff !important; border-bottom:1px solid #e2e8f0 !important; }
    html[data-theme="light"] .cal-title-month { color:#0f172a !important; }
    html[data-theme="light"] .cal-trade-count { color:#64748b !important; }
    html[data-theme="light"] .cal-divider { background:rgba(0,0,0,0.12) !important; }
    html[data-theme="light"] .cal-nav-btn { background:#f1f5f9 !important; border:1px solid #e2e8f0 !important; color:#475569 !important; }
    html[data-theme="light"] .cal-nav-btn:hover { background:#e2e8f0 !important; color:#1e293b !important; }
    html[data-theme="light"] .cal-grid { background:rgba(14,14,18,0.08) !important; border-color:rgba(14,14,18,0.1) !important; }
    html[data-theme="light"] .cal-day-hdr { background:#e8edf5 !important; color:#586475 !important; }
    html[data-theme="light"] .cal-cell { background:#ffffff !important; }
    html[data-theme="light"] .cal-cell.weekend { background:#f8fafc !important; }
    html[data-theme="light"] .cal-cell.has-trades { background:#f0f7ff !important; }
    html[data-theme="light"] .cal-cell.has-trades.weekend { background:#edf6ff !important; }
    html[data-theme="light"] .cal-empty { background:#f1f5f9 !important; }
    html[data-theme="light"] .cal-empty.weekend { background:#edf2f8 !important; }
    html[data-theme="light"] .cal-week-sum { background:#eef2f8 !important; border-left-color:rgba(14,14,18,0.06) !important; }
    html[data-theme="light"] .cal-date { color:#64748b !important; }
    html[data-theme="light"] .cal-cell.has-trades .cal-date { color:#475569 !important; }
    html[data-theme="light"] .cal-cell.today .cal-date { color:#0284c7 !important; }
    html[data-theme="light"] .cal-day-pl { border-top-color:rgba(14,14,18,0.07) !important; }
    html[data-theme="light"] .cal-week-count { color:#94a3b8 !important; }
    html[data-theme="light"] .cal-week-empty { color:rgba(14,14,18,0.12) !important; }

    /* Expanded trade review panel */
    .tr-review { background:#f8fafc !important; border-top:1px solid #e2e8f0 !important; }
    .tr-tile { background:rgba(0,0,0,0.03) !important; border-color:rgba(0,0,0,0.08) !important; }
    .tr-tile-label { color:#94a3b8 !important; }
    .tr-flow-row { background:rgba(0,0,0,0.025) !important; border-color:rgba(0,0,0,0.07) !important; }
    .tr-flow-label { color:#94a3b8 !important; }
    .tr-flow-arrow { color:rgba(0,0,0,0.22) !important; }
    .tr-flow-sub { color:#94a3b8 !important; }
    .tr-target-pill { background:rgba(124,58,237,0.09) !important; color:#7c3aed !important; }
    .tr-note-text { color:#475569 !important; }

    /* Entry reason badges — light-mode contrast */
    .er-badge.lps    { background:rgba(124,58,237,0.1) !important; color:#7c3aed !important; }
    .er-badge.cheatl { background:rgba(14,165,233,0.1) !important; color:#0284c7 !important; }
    .er-badge.cheath { background:rgba(180,83,9,0.1)   !important; color:#b45309 !important; }
    .er-badge.handle { background:rgba(234,88,12,0.1)  !important; color:#ea580c !important; }
    .er-badge.bo     { background:rgba(5,150,105,0.1)  !important; color:#059669 !important; }

    /* Market condition badges — light-mode contrast */
    .mc-badge.easy  { background:rgba(5,150,105,0.1)  !important; color:#059669 !important; }
    .mc-badge.hard  { background:rgba(220,38,38,0.1)  !important; color:#c0405c !important; }
    .mc-badge.up    { background:rgba(14,165,233,0.1) !important; color:#0284c7 !important; }
    .mc-badge.press { background:rgba(180,83,9,0.1)   !important; color:#b45309 !important; }
    .mc-badge.down  { background:rgba(124,58,237,0.1) !important; color:#7c3aed !important; }

    /* Status badges — light-mode contrast */
    .status-badge.open    { background:rgba(14,165,233,0.12) !important; color:#0284c7 !important; border-color:rgba(14,165,233,0.3) !important; }
    .status-badge.closed  { background:rgba(5,150,105,0.12)  !important; color:#065f46 !important; }
    .status-badge.partial { background:rgba(180,83,9,0.1)    !important; color:#b45309 !important; }

    /* Action buttons */
    .btn-icon   { background:rgba(0,0,0,0.03) !important; border-color:rgba(0,0,0,0.1) !important; color:#475569 !important; }
    .btn-camera { background:rgba(0,0,0,0.03) !important; border-color:rgba(0,0,0,0.1) !important; color:#475569 !important; }
  `;
}

const _THEME_SVG_SUN  = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><line x1="12" y1="2" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="4.22" y1="4.22" x2="6.34" y2="6.34"/><line x1="17.66" y1="17.66" x2="19.78" y2="19.78"/><line x1="2" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="22" y2="12"/><line x1="4.22" y1="19.78" x2="6.34" y2="17.66"/><line x1="17.66" y1="6.34" x2="19.78" y2="4.22"/></svg>`;
const _THEME_SVG_MOON = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;

function _applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  let el = document.getElementById('tj-dynamic-theme');
  if (!el) { el = document.createElement('style'); el.id = 'tj-dynamic-theme'; document.head.appendChild(el); }
  el.textContent = theme === 'light' ? _buildLightCSS() : '';
  // Force sidebar + all children via JS — same fix that worked in console
  const sidebar = document.getElementById('main-sidebar');
  if (sidebar) {
    sidebar.style.background = theme === 'light'
      ? 'linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%)'
      : '#0b0b0e';
    sidebar.style.borderLeft = theme === 'light' ? '1px solid #dde3ed' : '1px solid rgba(255,255,255,0.07)';
    sidebar.querySelectorAll('*').forEach(el => {
      el.style.background = 'transparent';
      if (theme === 'light') el.style.color = el.classList.contains('active') ? '#0284c7' : '#475569';
      else el.style.color = '';
    });
    // Restore colored elements
    const mark = sidebar.querySelector('.sidebar-brand-mark');
    if (mark) mark.style.background = 'linear-gradient(135deg, #818cf8 0%, #6366f1 100%)';
    const activeBtns = sidebar.querySelectorAll('.tab-btn.active');
    activeBtns.forEach(btn => { btn.style.background = theme === 'light' ? 'rgba(14,165,233,0.12)' : 'rgba(129,140,248,0.14)'; });
  }
  // Force table-wrap, cal-panel, cal-header backgrounds via JS
  document.querySelectorAll('.table-wrap, .ov-cal-panel').forEach(el => {
    if (theme === 'light') {
      el.style.setProperty('background', '#f3f6fb', 'important');
      el.style.setProperty('border-color', '#e2e8f0', 'important');
    } else {
      el.style.removeProperty('background');
      el.style.removeProperty('border-color');
    }
  });
  document.querySelectorAll('.cal-header, .cal-wrap').forEach(el => {
    if (theme === 'light') {
      el.style.setProperty('background', '#f3f6fb', 'important');
    } else {
      el.style.removeProperty('background');
    }
  });

  const icon = document.getElementById('theme-icon'), label = document.getElementById('theme-label');
  if (icon)  icon.innerHTML  = theme === 'light' ? _THEME_SVG_MOON : _THEME_SVG_SUN;
  if (label) label.textContent = theme === 'light' ? 'מצב כהה' : 'מצב בהיר';
  const hIcon = document.getElementById('header-theme-icon');
  if (hIcon) hIcon.innerHTML = theme === 'light' ? _THEME_SVG_MOON : _THEME_SVG_SUN;
}

function toggleSidebar() {
  const sidebar = document.getElementById('main-sidebar');
  if (window.innerWidth <= 768) {
    const overlay = document.getElementById('sidebar-overlay');
    const isOpen = sidebar.classList.toggle('open');
    overlay?.classList.toggle('open', isOpen);
    document.body.style.overflow = isOpen ? 'hidden' : '';
  } else {
    const collapsed = sidebar.classList.toggle('collapsed');
    localStorage.setItem('tj-sidebar-collapsed', collapsed ? '1' : '0');
  }
}

function toggleTheme() {
  const next = document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
  localStorage.setItem('tj-theme', next);
  _applyTheme(next);
}
function _updateThemeBtn(theme) {
  const icon = document.getElementById('theme-icon'), label = document.getElementById('theme-label');
  if (icon)  icon.innerHTML  = theme === 'light' ? _THEME_SVG_MOON : _THEME_SVG_SUN;
  if (label) label.textContent = theme === 'light' ? 'מצב כהה' : 'מצב בהיר';
}
(function _initTheme() {
  const saved = localStorage.getItem('tj-theme') || 'dark';
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => _applyTheme(saved));
  } else {
    _applyTheme(saved);
  }
})();
(function _initSidebar() {
  const apply = () => {
    if (localStorage.getItem('tj-sidebar-collapsed') === '1') {
      document.getElementById('main-sidebar')?.classList.add('collapsed');
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply);
  else apply();
})();

// ─── Cookie Consent ─────────────────────────────────────────────────────────

(function _cookieInit() {
  const consent = localStorage.getItem('tj-cookie-consent');
  if (!consent) {
    setTimeout(() => {
      const b = document.getElementById('cookie-banner');
      b.style.display = '';
    }, 800);
  }
})();

function cookieAccept() {
  const aiOn = document.getElementById('cookie-ai-toggle')?.checked !== false;
  localStorage.setItem('tj-cookie-consent', JSON.stringify({ necessary: true, ai: aiOn, ts: Date.now() }));
  _cookieHide();
}

function cookieDecline() {
  localStorage.setItem('tj-cookie-consent', JSON.stringify({ necessary: true, ai: false, ts: Date.now() }));
  localStorage.removeItem('tj-ai-key');
  localStorage.removeItem('groq-inv-key');
  _cookieHide();
}

function cookieToggleSettings() {
  const panel = document.getElementById('cookie-settings-panel');
  panel.classList.toggle('open');
}

function _cookieHide() {
  const b = document.getElementById('cookie-banner');
  b.classList.add('hide');
  setTimeout(() => { b.style.display = 'none'; b.classList.remove('hide'); }, 320);
}

// ─── Missed Opportunities ────────────────────────────────────────────────────

const MISSED_KEY = 'tj-missed-v1';

// Sector lookup — common symbols → Hebrew sector name
const SECTOR_MAP = {
  // Technology
  AAPL:'Technology',MSFT:'Technology',GOOGL:'Technology',GOOG:'Technology',META:'Technology',
  NVDA:'Technology',AMD:'Technology',INTC:'Technology',AVGO:'Technology',QCOM:'Technology',
  CRM:'Technology',ORCL:'Technology',IBM:'Technology',SAP:'Technology',SNOW:'Technology',
  PLTR:'Technology',DDOG:'Technology',CRWD:'Technology',ZS:'Technology',NET:'Technology',
  PANW:'Technology',FTNT:'Technology',S:'Technology',MDB:'Technology',ESTC:'Technology',
  ADBE:'Technology',NOW:'Technology',INTU:'Technology',ANSS:'Technology',CDNS:'Technology',
  KLAC:'Semiconductors',LRCX:'Semiconductors',AMAT:'Semiconductors',MRVL:'Semiconductors',SMCI:'Technology',
  ARM:'Semiconductors',AEHR:'Semiconductors',TSM:'Semiconductors',ASML:'Semiconductors',
  // Internet / E-commerce
  AMZN:'Internet / E-Commerce',SHOP:'Internet / E-Commerce',ETSY:'Internet / E-Commerce',EBAY:'Internet / E-Commerce',
  BABA:'Internet / E-Commerce',JD:'Internet / E-Commerce',PDD:'Internet / E-Commerce',SE:'Internet / E-Commerce',
  MELI:'Internet / E-Commerce',GRAB:'Internet / E-Commerce',RDDT:'Internet / E-Commerce',SNAP:'Internet / E-Commerce',
  PINS:'Internet / E-Commerce',LYFT:'Internet / E-Commerce',UBER:'Internet / E-Commerce',DASH:'Internet / E-Commerce',
  // Financials
  JPM:'Financials',BAC:'Financials',GS:'Financials',MS:'Financials',WFC:'Financials',C:'Financials',
  AXP:'Financials',V:'Financials',MA:'Financials',PYPL:'Financials',SQ:'Financials',AFRM:'Financials',
  COIN:'Financials',HOOD:'Financials',PJT:'Financials',JOE:'Financials',AHR:'Financials',
  // Healthcare / Biotech
  JNJ:'Healthcare',PFE:'Healthcare',MRK:'Healthcare',ABBV:'Healthcare',LLY:'Healthcare',BMY:'Healthcare',
  AMGN:'Healthcare',GILD:'Healthcare',BIIB:'Healthcare',MRNA:'Healthcare',BNTX:'Healthcare',
  ANAB:'Biotech',REGN:'Biotech',VRTX:'Biotech',SGEN:'Biotech',
  EXAS:'Biotech',PACB:'Biotech',BEAM:'Biotech',CRSP:'Biotech',
  // Energy
  XOM:'Energy',CVX:'Energy',COP:'Energy',SLB:'Energy',HAL:'Energy',
  OXY:'Energy',DVN:'Energy',MPC:'Energy',PSX:'Energy',
  // EV / Auto
  TSLA:'EV / Auto',RIVN:'EV / Auto',LCID:'EV / Auto',NIO:'EV / Auto',LI:'EV / Auto',
  GM:'EV / Auto',F:'EV / Auto',QS:'EV / Auto',
  // Consumer
  COST:'Consumer',WMT:'Consumer',TGT:'Consumer',HD:'Consumer',LOW:'Consumer',
  NKE:'Consumer',LULU:'Consumer',TJX:'Consumer',SBUX:'Consumer',MCD:'Consumer',
  // Communications / Media
  NFLX:'Media / Entertainment',DIS:'Media / Entertainment',PARA:'Media / Entertainment',WBD:'Media / Entertainment',
  SPOT:'Media / Entertainment',T:'Telecom',VZ:'Telecom',TMUS:'Telecom',
  // ETFs — Blue (broad market / safe haven)
  SPY:'ETF',VOO:'ETF',VTI:'ETF',IVV:'ETF',DIA:'ETF',
  GLD:'ETF',TLT:'ETF',AGG:'ETF',BND:'ETF',SCHD:'ETF',VYM:'ETF',VIG:'ETF',
  // ETFs — Green (growth / sector)
  QQQ:'ETF',IWM:'Growth ETF',ARKK:'Growth ETF',ARKG:'Growth ETF',
  VGT:'Growth ETF',XLK:'Growth ETF',SOXX:'Growth ETF',SMH:'Growth ETF',
  IBB:'Growth ETF',XBI:'Growth ETF',WCLD:'Growth ETF',CIBR:'Growth ETF',
  // ETFs — Leveraged (speculative)
  TQQQ:'Leveraged ETF',SQQQ:'Leveraged ETF',UPRO:'Leveraged ETF',SPXL:'Leveraged ETF',
  SOXL:'Leveraged ETF',LABU:'Leveraged ETF',CONL:'Leveraged ETF',FNGU:'Leveraged ETF',
  // Crypto-related stocks
  MSTR:'Crypto / Bitcoin',MARA:'Crypto / Bitcoin',RIOT:'Crypto / Bitcoin',HUT:'Crypto / Bitcoin',
  CLSK:'Crypto / Bitcoin',
  // Real Estate
  OPEN:'Real Estate',AMT:'Real Estate',EQIX:'Real Estate',PLD:'Real Estate',
  // Industrial
  GE:'Industrials',HON:'Industrials',CAT:'Industrials',DE:'Industrials',BA:'Industrials',RTX:'Industrials',
  AIR:'Industrials',
  // Crypto
  BTC:'Crypto',ETH:'Crypto',SOL:'Crypto',XRP:'Crypto',BNB:'Crypto',DOGE:'Crypto',
  HIPPO:'Crypto',BEAM:'Crypto',
  // Materials / Mining
  GROY:'Materials',NEM:'Materials',GOLD:'Materials',WPM:'Materials',
  // Healthcare / Instruments
  A:'Healthcare',SOLS:'Energy',
  // Misc
  NEGG:'Internet / E-Commerce',
};

const SECTOR_TO_CAT = {
  'Technology':'green','Semiconductors':'green','Internet / E-Commerce':'green',
  'Media / Entertainment':'green','ETF':'blue','Growth ETF':'green',
  'Biotech':'yellow','EV / Auto':'yellow','Crypto':'yellow','Crypto / Bitcoin':'yellow','Leveraged ETF':'yellow',
  'Financials':'blue','Healthcare':'blue','Consumer':'blue','Industrials':'blue',
  'Energy':'blue','Real Estate':'blue','Telecom':'blue',
};

let _missedSectorTimer = null;

function missedAutoSector() {
  const raw = document.getElementById('missed-sym').value.trim().toUpperCase()
    .replace(/[^A-Z0-9._\-]/g,'').replace(/USDT\.P|USDT|\.P$/,'');
  const sectorEl = document.getElementById('missed-sector');
  if (!sectorEl || !raw) return;

  // Instant fill from local map
  const local = SECTOR_MAP[raw];
  if (local) { sectorEl.value = local; return; }

  // Debounce Finnhub lookup — fires 600ms after user stops typing
  clearTimeout(_missedSectorTimer);
  if (raw.length < 2) return;
  _missedSectorTimer = setTimeout(() => _missedFetchSector(raw, sectorEl), 600);
}

async function _missedFetchSector(sym, sectorEl) {
  try {
    const token = await _getToken();
    if (!token) return;
    const url = `${SUPABASE_URL}/functions/v1/finnhub?path=stock%2Fprofile2&symbol=${encodeURIComponent(sym)}`;
    const res = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
    if (!res.ok) return;
    const data = await res.json();
    const sector = data.finnhubIndustry || '';
    if (sector && document.getElementById('missed-sym')?.value.trim().toUpperCase().replace(/[^A-Z0-9._\-]/g,'') === sym) {
      sectorEl.value = sector;
    }
  } catch { /* silent fail */ }
}

// In-memory cache for missed opportunities
let _missedList = [];

async function missedLoad() {
  if (!_currentUser) return [];
  const { data, error } = await _sb.from('missed_opportunities')
    .select('*')
    .eq('user_id', _currentUser.id)
    .order('date', { ascending: false });
  if (error) { console.error('[missedLoad]', error); return []; }
  return (data || []).map(r => ({ id: r.id, sym: r.symbol, date: r.date, price: r.price, sector: r.sector || '', note: r.note || '' }));
}

async function missedAdd() {
  if (!_currentUser) { toast('לא מחובר','error'); return; }
  const sym    = document.getElementById('missed-sym').value.trim().toUpperCase().replace(/[^A-Z0-9._\-]/g,'');
  const date   = document.getElementById('missed-date').value;
  const price  = parseFloat(document.getElementById('missed-price').value);
  const sector = document.getElementById('missed-sector').value.trim().slice(0, 40);
  const note   = document.getElementById('missed-note').value.trim().slice(0, 120);

  if (!sym)                    { toast('הכנס סימבול','error'); return; }
  if (!date)                   { toast('הכנס תאריך','error'); return; }
  if (isNaN(price)||price<=0)  { toast('הכנס מחיר תקין','error'); return; }

  const { data, error } = await _sb.from('missed_opportunities')
    .insert({ user_id: _currentUser.id, symbol: sym, date, price, sector, note })
    .select().single();
  if (error) { toast('שגיאה בהוספה: ' + (error.message || error.code || 'unknown'), 'error'); console.error('[missedAdd]', error); return; }

  document.getElementById('missed-sym').value    = '';
  document.getElementById('missed-date').value   = '';
  document.getElementById('missed-price').value  = '';
  document.getElementById('missed-sector').value = '';
  document.getElementById('missed-note').value   = '';

  // Optimistic: add to local list and render immediately without re-fetching
  const newItem = { id: data.id, sym: data.symbol, date: data.date, price: data.price, sector: data.sector || '', note: data.note || '' };
  _missedList = [newItem, ...(_missedList || [])].sort((a,b) => b.date.localeCompare(a.date));
  missedRenderList(_missedList);
  toast('נוסף ✓','success');
}

async function missedDelete(id) {
  if (!confirm('למחוק הזדמנות זו? הפעולה אינה הפיכה')) return;
  const { error } = await _sb.from('missed_opportunities').delete().eq('id', id).eq('user_id', _currentUser.id);
  if (error) { toast('שגיאה במחיקה','error'); return; }
  await missedRender();
}

function missedRenderList(list) {
  const container = document.getElementById('missed-tbody');
  if (!container) return;
  if (!list.length) {
    container.innerHTML = `<div class="missed-empty">${t('missed_empty')}</div>`;
    return;
  }
  const sorted = [...list].sort((a, b) => b.date.localeCompare(a.date));
  const byMonth = {};
  sorted.forEach(r => {
    const key = r.date.slice(0, 7); // YYYY-MM
    if (!byMonth[key]) byMonth[key] = [];
    byMonth[key].push(r);
  });
  container.innerHTML = Object.entries(byMonth).map(([key, items]) => {
    const [y, m] = key.split('-');
    const label = `${months()[+m-1]} ${y}`;
    const cards = items.map(r => `
      <div class="missed-card" id="missed-row-${r.id}">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:6px">
          <div class="missed-card-sym">${esc(r.sym)}</div>
          <div class="missed-card-actions">
            <button class="missed-del-btn edit" onclick="missedEdit('${r.id}')" title="ערוך">✏</button>
            <button class="missed-del-btn" onclick="missedDelete('${r.id}')" title="מחק">✕</button>
          </div>
        </div>
        <div class="missed-card-price">$${(+r.price).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</div>
        <div class="missed-card-meta">${r.sector ? esc(r.sector)+' · ' : ''}${fmtDate(r.date)}</div>
        ${r.note ? `<div class="missed-card-note">${esc(r.note)}</div>` : ''}
      </div>`).join('');
    return `
      <div class="missed-month-section">
        <div class="missed-month-label">${label} <span style="color:var(--accent);font-size:10px;font-weight:800">${items.length}</span></div>
        <div class="missed-cards">${cards}</div>
      </div>`;
  }).join('');
  container.querySelectorAll('.missed-card').forEach((el, i) => {
    el.style.setProperty('--i', i);
    el.classList.add('animate-in');
  });
}

async function missedRender() {
  const list = await missedLoad();
  _missedList = list;
  missedRenderList(list);
}

function missedEdit(id) {
  const r = _missedList.find(x => String(x.id) === String(id));
  if (!r) return;
  const card = document.getElementById('missed-row-' + id);
  if (!card) return;
  card.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:8px;">
      <input class="form-control" style="font-size:12px;padding:4px 8px;text-transform:uppercase" value="${esc(r.sym)}" id="me-sym-${id}" placeholder="סימבול">
      <input class="form-control" style="font-size:12px;padding:4px 8px" value="${esc(r.sector||'')}" id="me-sec-${id}" placeholder="סקטור">
      <input class="form-control" type="date" style="font-size:12px;padding:4px 8px" value="${esc(r.date)}" id="me-date-${id}">
      <input class="form-control" type="number" style="font-size:12px;padding:4px 8px" value="${r.price}" step="0.0001" id="me-price-${id}" placeholder="מחיר">
      <input class="form-control" style="font-size:12px;padding:4px 8px" value="${esc(r.note||'')}" id="me-note-${id}" placeholder="הערה" maxlength="120">
      <div style="display:flex;gap:6px;margin-top:2px;">
        <button class="btn btn-primary btn-sm" style="flex:1;font-size:11px" onclick="missedSaveEdit('${id}')">שמור</button>
        <button class="btn btn-secondary btn-sm" style="font-size:11px" onclick="missedRender()">ביטול</button>
      </div>
    </div>`;
}

async function missedSaveEdit(id) {
  const sym   = (document.getElementById('me-sym-'+id)?.value||'').trim().toUpperCase().replace(/[^A-Z0-9._\-]/g,'');
  const sector= (document.getElementById('me-sec-'+id)?.value||'').trim().slice(0,40);
  const date  = document.getElementById('me-date-'+id)?.value||'';
  const price = parseFloat(document.getElementById('me-price-'+id)?.value);
  const note  = (document.getElementById('me-note-'+id)?.value||'').trim().slice(0,120);

  if (!sym)                   { toast('הכנס סימבול','error'); return; }
  if (!date)                  { toast('הכנס תאריך','error'); return; }
  if (isNaN(price)||price<=0) { toast('הכנס מחיר תקין','error'); return; }

  const { error } = await _sb.from('missed_opportunities')
    .update({ symbol: sym, sector, date, price, note })
    .eq('id', id).eq('user_id', _currentUser.id);
  if (error) { toast('שגיאה בעדכון','error'); console.error(error); return; }
  await missedRender();
  toast('עודכן ✓','success');
}

// ─── AI Coach ───────────────────────────────────────────────────────────────

let _aiPeriod = 'month';
let _aiRunning = false;
let _aiChatRunning = false;
let _aiChatHistory = [];   // {role, content}
let _aiChatContext = '';   // trade data summary for chat

(function _aiInit() {
  const today = new Date().toISOString().slice(0,10);
  document.getElementById('ai-custom-date').value = today;
})();

function aiSetPeriod(p, btn) {
  _aiPeriod = p;
  document.querySelectorAll('.ai-period-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('ai-custom-date-wrap').style.display = p === 'custom' ? '' : 'none';
}

async function aiSaveKey() {
  const k = document.getElementById('ai-api-key').value.trim();
  if (!k || !k.startsWith('gsk_')) return;
  await _saveUserSettings({ groq_api_key: k });
  const el = document.getElementById('ai-api-key');
  if (el) { el.value = ''; el.placeholder = 'מפתח שמור ✓'; }
  toast('מפתח Groq נשמר 🔐', 'success');
}

async function invSaveGroqKey() {
  const k = document.getElementById('inv-groq-key-input').value.trim();
  if (!k || !k.startsWith('gsk_')) return;
  _userSettings.groq_inv_key = k;
  await _saveUserSettings({ groq_inv_key: k });
  const el = document.getElementById('inv-groq-key-input');
  if (el) { el.value = ''; el.placeholder = 'מפתח שמור ✓'; }
  toast('מפתח Groq ליועץ השקעות נשמר 🔐', 'success');
}

function _getInvGroqKey() {
  const fromInput = (document.getElementById('inv-groq-key-input')?.value || '').trim();
  if (fromInput.startsWith('gsk_')) return fromInput;
  return _userSettings.groq_inv_key || '';
}

function aiToggleKey() {
  const inp = document.getElementById('ai-api-key');
  inp.type = inp.type === 'password' ? 'text' : 'password';
}

function _aiGetDateRange() {
  if (_aiPeriod === 'full') return { start: null, end: null, label: 'כל הזמן — All Time' };
  const fmt = d => d.toISOString().slice(0,10);
  const labelFmt = d => d.toLocaleDateString('he-IL', { day: 'numeric', month: 'short' });

  if (_aiPeriod === 'month') {
    const end = new Date();
    const start = new Date(); start.setDate(end.getDate() - 30);
    return { start: fmt(start), end: fmt(end), label: '30 ימים אחרונים' };
  }

  let ref;
  if (_aiPeriod === 'custom') {
    const v = document.getElementById('ai-custom-date').value;
    ref = v ? new Date(v) : new Date();
  } else {
    ref = new Date();
  }
  const dow = ref.getDay();
  const diffToMon = (dow === 0) ? -6 : 1 - dow;
  const mon = new Date(ref); mon.setDate(ref.getDate() + diffToMon);
  const sun = new Date(mon); sun.setDate(mon.getDate() + 6);
  return {
    start: fmt(mon), end: fmt(sun),
    label: `שבוע ${labelFmt(mon)} – ${labelFmt(sun)}`
  };
}

function _aiCalcPnl(t) {
  const entry   = parseFloat(t.entryPrice || 0);
  const exitP   = parseFloat(t.exitPrice  || 0);
  const shares  = parseFloat(t.shares     || 0);
  const closed  = parseFloat(t.closedShares != null ? t.closedShares : shares) || shares;
  const comm    = parseFloat(t.commission  || 0);
  const ecn     = parseFloat(t.ecn        || 0);
  const ls      = t.ls || 'L';
  const partials = t.t || [];
  let pnl = 0;
  if (partials.length) {
    for (const p of partials) {
      const ps = parseFloat(p.shares || 0);
      const pp = parseFloat(p.price  || 0);
      pnl += ls === 'L' ? (pp - entry) * ps : (entry - pp) * ps;
    }
  } else {
    pnl = ls === 'L' ? (exitP - entry) * closed : (entry - exitP) * closed;
  }
  return pnl - comm - ecn;
}

function _aiGetTrades(start, end) {
  const stocks = Array.isArray(db.stocks) ? db.stocks : [];
  const crypto = Array.isArray(db.crypto) ? db.crypto : [];
  const result = [];
  for (const [assetType, list] of [['stocks', stocks], ['crypto', crypto]]) {
    for (const t of list) {
      const cd = t.closeDate || '';
      if (!cd) continue;
      if (start && cd < start) continue;
      if (end   && cd > end)   continue;
      result.push({
        symbol: t.symbol || '', asset: assetType,
        direction: t.ls || 'L',
        entryDate: t.entryDate || '', closeDate: cd,
        entryPrice: t.entryPrice || 0, exitPrice: t.exitPrice || 0,
        shares: t.shares || 0, pnl: Math.round(_aiCalcPnl(t) * 100) / 100,
        notes_keep: t.notes_keep || '', notes_improve: t.notes_improve || '',
      });
    }
  }
  return result.sort((a,b) => a.closeDate.localeCompare(b.closeDate));
}

function _aiToolSummary(trades) {
  if (!trades.length) return JSON.stringify({ total_trades: 0, message: 'No closed trades in this period.' });
  const winners = trades.filter(t => t.pnl > 0);
  const losers  = trades.filter(t => t.pnl < 0);
  const total   = trades.reduce((s,t) => s + t.pnl, 0);
  return JSON.stringify({
    total_trades: trades.length, total_pnl: Math.round(total*100)/100,
    winners: winners.length, losers: losers.length,
    win_rate_pct: Math.round(winners.length / trades.length * 1000) / 10,
    avg_win:  winners.length ? Math.round(winners.reduce((s,t)=>s+t.pnl,0)/winners.length*100)/100 : 0,
    avg_loss: losers.length  ? Math.round(losers.reduce((s,t)=>s+t.pnl,0)/losers.length*100)/100   : 0,
    profit_factor: losers.length ? Math.round(
      winners.reduce((s,t)=>s+t.pnl,0) / Math.abs(losers.reduce((s,t)=>s+t.pnl,0)) * 100) / 100 : null,
    best_trade:  trades.reduce((b,t) => t.pnl > b.pnl ? t : b),
    worst_trade: trades.reduce((b,t) => t.pnl < b.pnl ? t : b),
    all_trades: trades,
  }, null, 2);
}

function _aiToolSymbols(trades) {
  const by = {};
  for (const t of trades) {
    if (!by[t.symbol]) by[t.symbol] = { symbol: t.symbol, pnl: 0, trades: 0, wins: 0, asset: t.asset };
    by[t.symbol].pnl    += t.pnl;
    by[t.symbol].trades += 1;
    if (t.pnl > 0) by[t.symbol].wins++;
  }
  const rows = Object.values(by).map(r => ({ ...r, pnl: Math.round(r.pnl*100)/100, win_rate: Math.round(r.wins/r.trades*1000)/10 }));
  rows.sort((a,b) => b.pnl - a.pnl);
  return JSON.stringify(rows, null, 2);
}

function _aiToolDaily(trades) {
  const by = {};
  for (const t of trades) {
    if (!by[t.closeDate]) by[t.closeDate] = { date: t.closeDate, pnl: 0, trades: 0, wins: 0 };
    by[t.closeDate].pnl    += t.pnl;
    by[t.closeDate].trades += 1;
    if (t.pnl > 0) by[t.closeDate].wins++;
  }
  return JSON.stringify(Object.values(by).sort((a,b)=>a.date.localeCompare(b.date)).map(r=>({...r,pnl:Math.round(r.pnl*100)/100})), null, 2);
}

function _aiToolNotes(trades) {
  return JSON.stringify(trades.filter(t=>t.notes_keep||t.notes_improve).map(t=>({
    symbol: t.symbol, date: t.closeDate, pnl: t.pnl, keep: t.notes_keep, improve: t.notes_improve
  })), null, 2);
}

function _aiDispatchTool(name, trades) {
  if (name === 'get_summary')          return _aiToolSummary(trades);
  if (name === 'get_symbol_breakdown') return _aiToolSymbols(trades);
  if (name === 'get_daily_breakdown')  return _aiToolDaily(trades);
  if (name === 'get_notes')            return _aiToolNotes(trades);
  return JSON.stringify({ error: 'unknown tool' });
}

function _aiMd(text) {
  // minimal markdown → html
  return text
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/`(.+?)`/g, '<code>$1</code>')
    .replace(/^- (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>.*<\/li>\n?)+/g, s => '<ul>' + s + '</ul>')
    .replace(/(\+\$[\d,]+\.?\d*)/g, '<span class="num-pos">$1</span>')
    .replace(/(−\$[\d,]+\.?\d*|-\$[\d,]+\.?\d*)/g, '<span class="num-neg">$1</span>')
    .replace(/\n/g, '<br>');
}

async function aiRunReport() {
  if (_aiRunning) return;

  if (!_currentUser) { _aiShowStatus('error', 'נא להתחבר תחילה'); return; }

  const { start, end, label } = _aiGetDateRange();
  const trades = _aiGetTrades(start, end);

  if (!trades.length) {
    _aiShowStatus('error', `לא נמצאו עסקאות סגורות${start ? ` לתקופה ${start} → ${end}` : ''}. נסה "כל הזמן".`);
    return;
  }

  _aiRunning = true;
  document.getElementById('ai-run-btn').disabled = true;
  document.getElementById('ai-output').style.display = 'none';
  _aiShowStatus('loading', `טוען נתונים — ${trades.length} עסקאות | קורא ל-Groq…`);

  // Build full data payload for Gemini (no tool-use needed)
  const summaryData  = _aiToolSummary(trades);
  const symbolsData  = _aiToolSymbols(trades);
  const dailyData    = _aiToolDaily(trades);
  const notesData    = _aiToolNotes(trades);

  const system = `אתה מארק מינרוויני. אתה מדבר ישירות עם הסוחר — בשיחה, לא בדוח. הוא הראה לך את העסקאות שלו ואתה מגיב כמו שהיית מגיב אם הוא ישב מולך בחדר.

תקופה: ${label}

=== תנאי שוק — STEM (Stock Trading Environment Model) ===
הסוחר מתעד בכל עסקה את תנאי השוק לפי מודל STEM:
- 🟢 ירוק = Breakouts are working well — consider aggressive trading. פוזיציות גדולות, מסחר אגרסיבי מוצדק.
- 🟠 כתום = Market is selective and/or highly rotational — you can trade but exercise caution. פוזיציות קטנות יותר, להיות מאוד סלקטיבי.
- 🔴 אדום = Breakouts are not working well, risk is high — maximum caution advised. להיות בעיקר בצד, לחתוך הפסדים מהר מאוד.

כשאתה מנתח עסקאות:
- הפסד על breakout בשוק אדום = שגיאת ביצוע קטנה (השוק לא תומך)
- הפסד על breakout בשוק ירוק = בעיה אמיתית בבחירת המניה או בניהול
- אם הסוחר קנה בשוק אדום — שאל אותו למה לא ישב בצד

כתוב בעברית. מספרים ומניות — באנגלית.

=== השיטה שלך — SEPA ו-Trend Template ===

אתה סוחר לפי שיטת SEPA (Specific Entry Point Analysis). הכלל הבסיסי שלך: מניה חייבת לעמוד בכל 8 תנאי ה-Trend Template לפני שאתה בכלל מסתכל עליה.

**Trend Template — 8 התנאים:**
1. מחיר המניה מעל ממוצע נע 150 יום (30 שבועות) וגם מעל ממוצע נע 200 יום (40 שבועות)
2. ממוצע נע 150 יום מעל ממוצע נע 200 יום
3. ממוצע נע 200 יום בעלייה לפחות חודש אחד (עדיף 4-5 חודשים)
4. ממוצע נע 50 יום (10 שבועות) מעל ממוצע נע 150 יום וגם מעל ממוצע נע 200 יום
5. מחיר המניה מעל ממוצע נע 50 יום
6. מחיר המניה לפחות 30% מעל השפל של 52 שבועות (המניות הטובות ביותר יהיו 100%-300% מעל)
7. מחיר המניה עד 25% מהשיא של 52 שבועות (ככל שקרוב יותר לשיא — טוב יותר)
8. Relative Strength (IBD RS) לא פחות מ-70, עדיף 80-90+

**VCP — Volatility Contraction Pattern:**
דפוס הכניסה המועדף: התכווצות תנודתיות עם נפח יורד. כל pivot קטן יותר מהקודם. הכניסה — על breakout מעל ה-pivot האחרון בנפח גבוה.

**כללי risk management שלך:**
- סטופ לוס: 7-8% מתחת לנקודת הכניסה — לעולם לא יותר
- יחס R/R מינימלי: 2:1 (עדיף 3:1)
- לא להוסיף לפוזיציה מפסידה
- לחתוך הפסדים מהר, להחזיק רווחים לאורך זמן
- Stage 2 בלבד — לא לקנות מניות ב-Stage 1 (basing), Stage 3 (top), Stage 4 (downtrend)

**3 יסודות בסיסיים לבחינה — רווחים, מכירות ומרווחים:**

חיובי (מה לחפש):
- רווחים ב-2-3 הרבעונים האחרונים +20% ומעלה — ככל שגבוה יותר, כך טוב יותר
- מכירות בעלייה ב-2-3 הרבעונים האחרונים
- האצה ברווחים ובמכירות — רבעון אחר רבעון — הסתכל על ממוצע 2 רבעונים (עלייה של 20%)
- צמיחה נוכחית ביחס לצמיחה ממוצעת של 3-5 שנים (חפש האצה)
- שנת פריצה (breakout year)
- רווחים שנתיים חזקים
- בדוק מרווחי רווח — האם הם מתרחבים או מתכווצים?
- חפש מניות Code 3

שלילי (אזהרות אדומות):
- האטה מהותית ברווחים — אזהרה
- שחיקת מרווחים — אזהרה
- רווחים חיוביים עם מכירות שליליות — אורך חיים מוגבל
- חברה שמציגה רווחים חזקים אך לא משלמת מיסים — דגל אדום

**כללי מסחר מרכזיים:**
1. היה מוכן לשבת בצד במזומן לתקופות ממושכות — לעולם אל תיתן לממוצעים ללחוץ אותך לעסקאות שלא עומדות בקריטריונים שלך
2. שמור על כל ההפסדים קטנים יחסית לתשואה
3. כאשר העסקאות עובדות — סחר באגרסיביות
4. כאשר העסקאות לא עובדות — נסוג משמעותית
5. לעולם אל תממצע הפסד (Never average down)
6. לעולם אל תתן לרווח גדול להפוך להפסד
7. תמיד כבד את הסיכון ושים משמעת מעל אגו

**מה לעשות בתקופות קשות:**
בתקופות קשות הרווחים שלך יהיו קטנים מהרגיל ואחוז העסקאות הרווחיות יהיה נמוך מהרגיל. **חייב לחתוך הפסדים מהר יותר לפיצוי. לא להרחיב סטופים.**
- צא ממינוף (margin) מיד
- צמצם חשיפה — גודל פוזיציה ומחויבות הון כוללת
- היה פחות סלחן — הדק סטופים. אם בדרך כלל חותך הפסדים ב-7-8%, חתוך ב-4-5%
- היה פחות תאב — הסתפק ברווחים קטנים יותר. אם בדרך כלל לוקח רווחים ב-15-20%, קח ב-10-12%

**Power Play — הגדרה:**
1. תנועת מחיר נפיצה בנפח עצום — המניה עולה 100% ומעלה בפחות מ-8 שבועות
2. העלייה יכולה להיגרם מאירוע חדשות גדול (אישור FDA, תוצאות, הכרזה) — או ללא שום סיבה ברורה (חוזק בלתי מוסבר)
3. לאחר מכן המניה נעה הצידה בטווח צפוף יחסית — לא מתקנת יותר מ-20% לאורך 3-6 שבועות (חלקן מופיעות אחרי 10-12 ימים בלבד)

**סימנים למכירה — Signs to Consider Selling:**
אלה האותות שמעידים שמניה כנראה הגיעה לשיאה ויש לשקול מכירה:
1. 70% ימים עולים מתוך תקופה של 7 עד 15 ימים — וזה קרה פעמיים (2x)
2. קצב עלייה מואץ (Accelerated rate of advance) — המניה מטפסת מהר מדי
3. הגדול ביותר מבין ימי העלייה מגיע כאשר המניה כבר מורחבת (extended) מהבסיס
4. הספרד (מרווח יומי) הגדול ביותר מגיע כאשר המניה כבר extended
5. פער (Gap up) מגיע כאשר המניה כבר extended
6. סימנים של היפוך כיוון (reversal) על נפח כבד
7. הירידה היומית הגדולה ביותר מגיעה על הנפח הגדול ביותר
8. הירידה השבועית הגדולה ביותר מגיעה על הנפח הגדול ביותר

**Stage 3 — מאפיינים של שלב הפסגה:**
1. התנודתיות עולה — המניה נעה קדימה ואחורה בתנועות רחבות ולא סדירות. הדפוס עשוי להיראות דומה ל-Stage 2, אך תנועת המחיר הרבה יותר אירטית.
2. בשלב מסוים יש לרוב שבירת מחיר גדולה על עלייה בנפח — לרוב הירידה היומית הגדולה ביותר מאז תחילת Stage 2. על גרף שבועי — הירידה השבועית הגדולה ביותר מאז תחילת התנועה. שבירות אלה מגיעות כמעט תמיד על נפח מוחץ ומעידות על מכירה מוסדית כבדה.
3. פעולת הפסגה של Stage 3 מגיעה לרוב לאחר שהמניה יצאה ממספר תקופות בסיס (consolidation) במהלך Stage 2 — בדרך כלל 3-5 בסיסות נוצרים לפני שיא Stage 3.

**אותות דוביים — Bearish Signals (Violations):**
אלה הפרות של מבנה עולה תקין — אם אתה רואה אחד מהם, שים לב:
- נפח נמוך ביציאה, נפח גבוה בירידה (Low volume out – high volume in)
- 3-4 lower lows רצופים על נפח — ללא כל פעולת תמיכה ביום 3 או 4
- יותר ימי ירידה מימי עלייה
- יותר סגירות רעות מסגירות טובות
- סגירה מתחת לממוצע 20 יום זמן קצר אחרי הpivot — ובוודאי אם זה מתחת ל-50 יום
- פעולת מחיר רחבה ותנודתית (Wide and volatile price action)

=== הדמות שלך ===
- אתה ישיר ואמיתי. לא מחמיא סתם ולא מוחץ סתם.
- יש לך דעה ואתה אומר אותה — "זה היה טעות", "זה היה נכון", "הייתי עושה אחרת".
- אתה מדבר מניסיון — "אני זוכר שגם אני...", "בשנת 1997 כשהרווחתי 155%...", "הדבר הכי קשה שלמדתי...".
- אתה לא מרצה ולא מסביר הגדרות. אתה מגיב למה שאתה רואה.

=== המבנה ===

**חלק 1 — תגובה ראשונית**
תגובה קצרה על התוצאה הכללית — אמיתית ובלי לעגל פינות.

**חלק 2 — עסקאות ספציפיות**
2-3 עסקאות שבלטו (טוב או רע). אמור מה חשבת כשראית אותן — האם הן עמדו ב-Trend Template? האם הכניסה הייתה על VCP אמיתי? האם ה-stop היה נכון?

**חלק 3 — ניתוח הערות היומן (החלק הכי חשוב)**
קרא את כל הערות "מה לשפר" ו"מה לשמר" שהסוחר כתב. הוא כתב את זה בעצמו — זה הזהב האמיתי.

עבור כל עסקה עם הערות:
- בדוק אם הבעיה שציין (ב"מה לשפר") קשורה לאחד מהאותות שלמדת: כניסה מאוחרת, stop רחב, מניה בStage 3, bearish signals שהתעלם מהם, selling signs שהיו ברורים.
- בדוק אם מה שכתב ב"מה לשמר" אכן עקבי עם שיטת SEPA — ואם לא, אמור לו.
- חפש דפוסים חוזרים — אם אותה מילה או ביטוי מופיע ב-2+ עסקאות, זה לא מקרה.

דוגמאות לחיבורים שאתה עושה:
- "לא כיבדתי את הסטופ" → "זה הדבר שהורג סוחרים. כלל אחד: הסטופ הוא מקום מחיר, לא החלטה רגשית."
- "קניתי מאוחר מדי" → "אתה קונה אחרי הbreakout, לא עליו. VCP אמיתי מאפשר לך להיכנס בדיוק על הpivot."
- "מכרתי מוקדם" → "זה לא בעיה בשיטה — זה בעיה באמון בעצמך. אם הקנייה הייתה נכונה, תן למניה לעבוד."
- "נפח נמוך ביום הכניסה" → "זהו bearish signal ברור — אין אישור מוסדי. זה violation בסיסי."
- "המניה ירדה מהר אחרי הכניסה" → "בדוק אם היו selling signs לפני — extended, largest up day, gap בלי בסיס חדש."

אם אין הערות כלל — אמור לו: "אי אפשר להשתפר בלי לתעד. בלי יומן — אתה חוזר על אותן טעויות ולא יודע."

**חלק 4 — המלצה אחת**
פעולה אחת ספציפית לעסקה הבאה — קונקרטית לגמרי, לא עצות כלליות.

**משפט סיום**
משפט אחד. אמיתי. שיישאר איתו.

השתמש במספרים אמיתיים — לא "הפסדת הרבה" אלא "הפסדת $340 ב-QS ביום אחד".`;

  const notesWithPatterns = _aiToolNotes(trades);
  const improvePhrases = trades.filter(t=>t.notes_improve).map(t=>`[${t.symbol} ${t.closeDate}]: "${t.notes_improve}"`).join('\n') || 'אין הערות שיפור';
  const keepPhrases    = trades.filter(t=>t.notes_keep).map(t=>`[${t.symbol} ${t.closeDate}]: "${t.notes_keep}"`).join('\n') || 'אין הערות שימור';

  const userPrompt = `Here is the full trading data for ${label}:

=== SUMMARY STATS ===
${summaryData}

=== DAILY BREAKDOWN ===
${dailyData}

=== SYMBOL BREAKDOWN ===
${symbolsData}

=== TRADER JOURNAL NOTES — "מה לשפר" (לשיפור) ===
${improvePhrases}

=== TRADER JOURNAL NOTES — "מה לשמר" (לשימור) ===
${keepPhrases}

Find recurring patterns in the "מה לשפר" notes above. If the same mistake appears multiple times (e.g., "bought too expensive", "no entry trigger", "stop too wide"), name the pattern and call it out directly.

Now generate the full performance report as described in your instructions.`;

  let fullText = '';
  const outputBody = document.getElementById('ai-output-body');
  outputBody.innerHTML = '';

  try {
    const resp = await fetch(`${SUPABASE_URL}/functions/v1/groq`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${await _getToken()}`,
      },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile',
        messages: [
          { role: 'system', content: system },
          { role: 'user',   content: userPrompt },
        ],
        stream: true,
        max_tokens: 4096,
        temperature: 0.7,
      }),
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error?.message || `HTTP ${resp.status}`);
    }

    const reader = resp.body.getReader();
    const dec = new TextDecoder();
    let buf = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const raw = line.slice(6).trim();
        if (!raw || raw === '[DONE]') continue;
        let ev;
        try { ev = JSON.parse(raw); } catch { continue; }
        const chunk = ev?.choices?.[0]?.delta?.content;
        if (chunk) {
          fullText += chunk;
          outputBody.innerHTML = _aiMd(fullText);
          outputBody.scrollTop = outputBody.scrollHeight;
          document.getElementById('ai-output').style.display = '';
          document.getElementById('ai-status').style.display = 'none';
        }
      }
    }

    _aiShowStatus('done', `הדוח מוכן — ${trades.length} עסקאות | ${label}`);
    document.getElementById('ai-output-label').textContent = `דוח ביצועים — ${label}`;
    document.getElementById('ai-output').style.display = '';
    outputBody.innerHTML = _aiMd(fullText);

    // Enable chat — seed context with report + trade data
    _aiChatHistory = [];
    _aiChatContext = `${system}\n\n=== REPORT ALREADY GIVEN ===\n${fullText}\n\n=== TRADE DATA ===\n${summaryData}\n${notesData}`;
    document.getElementById('ai-chat-wrap').style.display = '';
    document.getElementById('ai-chat-messages').innerHTML = '';
    aiChatAddBubble('bot', 'יש לך שאלות? אני כאן.');

  } catch (e) {
    _aiShowStatus('error', `שגיאה: ${e.message}`);
    console.error('[AI Minervini]', e);
  }

  _aiRunning = false;
  document.getElementById('ai-run-btn').disabled = false;
}

// ─── Chat ────────────────────────────────────────────────────────────────────

function aiChatAddBubble(who, text) {
  const wrap = document.getElementById('ai-chat-messages');
  const msg = document.createElement('div');
  msg.className = `ai-chat-msg ${who}`;
  msg.innerHTML = `
    <div class="ai-chat-who">${who === 'user' ? 'אתה' : 'מינרוויני'}</div>
    <div class="ai-chat-bubble" id="chat-bubble-${Date.now()}">${who === 'bot' ? _aiMd(text) : esc(text)}</div>`;
  wrap.appendChild(msg);
  wrap.scrollTop = wrap.scrollHeight;
  return msg.querySelector('.ai-chat-bubble');
}

async function aiChatSend() {
  if (_aiChatRunning) return;
  const inp = document.getElementById('ai-chat-input');
  const question = inp.value.trim();
  if (!question) return;
  inp.value = '';
  aiChatAddBubble('user', question);
  _aiChatHistory.push({ role: 'user', content: question });

  _aiChatRunning = true;
  document.getElementById('ai-chat-send').disabled = true;

  const botBubble = aiChatAddBubble('bot', '...');
  let botText = '';

  try {
    const messages = [
      { role: 'system', content: _aiChatContext },
      ..._aiChatHistory
    ];

    const resp = await fetch(`${SUPABASE_URL}/functions/v1/groq`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${await _getToken()}` },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile',
        messages,
        stream: true,
        max_tokens: 1024,
        temperature: 0.7,
      }),
    });

    if (!resp.ok) { const t = await resp.text(); throw new Error(`HTTP ${resp.status}: ${t}`); }

    const reader = resp.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const raw = line.slice(6).trim();
        if (!raw || raw === '[DONE]') continue;
        let ev; try { ev = JSON.parse(raw); } catch { continue; }
        const chunk = ev?.choices?.[0]?.delta?.content;
        if (chunk) {
          botText += chunk;
          botBubble.innerHTML = _aiMd(botText);
          document.getElementById('ai-chat-messages').scrollTop = 99999;
        }
      }
    }

    _aiChatHistory.push({ role: 'assistant', content: botText });

  } catch(e) {
    botBubble.innerHTML = `<span style="color:var(--red)">שגיאה: ${esc(e.message)}</span>`;
  }

  _aiChatRunning = false;
  document.getElementById('ai-chat-send').disabled = false;
  inp.focus();
}

function _aiShowStatus(type, msg) {
  const el = document.getElementById('ai-status');
  el.style.display = '';
  el.className = 'ai-status' + (type === 'error' ? ' error' : '');
  if (type === 'loading') {
    el.innerHTML = `<div class="ai-spinner"></div><span>${msg}</span>`;
  } else if (type === 'done') {
    el.innerHTML = `<span style="color:var(--green)">✓</span> <span>${msg}</span>`;
  } else {
    const safe = msg.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    el.innerHTML = `<span>⚠ ${safe}</span>`;
  }
}

function aiCopyReport() {
  const body = document.getElementById('ai-output-body').innerText;
  navigator.clipboard.writeText(body).then(() => {
    const btn = document.querySelector('.ai-copy-btn');
    const orig = btn.innerHTML;
    btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><polyline points="20 6 9 17 4 12"/></svg> הועתק';
    setTimeout(() => { btn.innerHTML = orig; }, 1800);
  });
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js')
      .then(reg => console.log('[SW] Registered:', reg.scope))
      .catch(err => console.log('[SW] Registration failed:', err));
  });
}

// ===== INVESTMENTS TAB =====
const INV_KEY = 'inv_data_v1';
let _invData = null;
let _invSaveTimer = null;

function invGetCurrency() {
  return localStorage.getItem('inv_currency') || '$';
}
function invSetCurrency(cur) {
  localStorage.setItem('inv_currency', cur);
  document.getElementById('inv-cur-usd')?.classList.toggle('active', cur === '$');
  document.getElementById('inv-cur-ils')?.classList.toggle('active', cur === '₪');
  invSyncPnlBtn();
  invRecalc();
  invSaveData(invLoad());
}
function invGetPnlMode() { return localStorage.getItem('inv_pnl_mode') || 'amount'; }
function invSyncPnlBtn() {
  const btn = document.getElementById('inv-pnl-toggle');
  if (btn) btn.textContent = invGetPnlMode() === 'amount' ? invGetCurrency() : '%';
}
function invTogglePnlMode() {
  const next = invGetPnlMode() === 'amount' ? '%' : 'amount';
  localStorage.setItem('inv_pnl_mode', next);
  invSyncPnlBtn();
  invRecalc();
}

function invLoad() {
  if (_invData) return _invData;
  try {
    const raw = localStorage.getItem(INV_KEY);
    return raw ? JSON.parse(raw) : { portfolioTotal: '', cashBalance: '', holdings: [], deposits: [] };
  } catch { return { portfolioTotal: '', holdings: [], deposits: [] }; }
}

async function invLoadFromDB() {
  if (!_currentUser) return invLoad();
  const portfolioTotal = _userSettings.portfolio_total != null
    ? String(_userSettings.portfolio_total)
    : (invLoad().portfolioTotal || '');
  const { data } = await _sb.from('investments')
    .select('holdings, deposits, currency, alloc_targets')
    .eq('user_id', _currentUser.id)
    .single();
  const local = invLoad();
  if (data) {
    const holdings = (data.holdings || []).map(h => ({ ...h, locked: h.locked !== false ? true : false }));
    invApplyTargets(data.alloc_targets || local.allocTargets);
    _invData = { portfolioTotal, cashBalance: local.cashBalance || '', holdings, deposits: data.deposits || [], allocTargets: invTargetsPayload() };
    if (data.currency) localStorage.setItem('inv_currency', data.currency);
  } else {
    invApplyTargets(local.allocTargets);
    _invData = { portfolioTotal, cashBalance: local.cashBalance || '', holdings: local.holdings || [], deposits: local.deposits || [] };
    if (_invData.holdings.length || _invData.deposits.length) invSaveData(_invData);
  }
  return _invData;
}

async function invSaveData(data) {
  _invData = data;
  if (!_currentUser) return;
  const { error } = await _sb.from('investments').upsert(
    { user_id: _currentUser.id, holdings: data.holdings || [], deposits: data.deposits || [], currency: invGetCurrency(), alloc_targets: data.allocTargets || invTargetsPayload() },
    { onConflict: 'user_id' }
  );
  if (error) {
    console.error('[invSaveData]', error);
    toast('שגיאה בשמירת השקעות: ' + error.message, 'error');
    return false;
  }
  return true;
}

async function invInit() {
  const data = await invLoadFromDB();
  const cur = invGetCurrency();
  document.getElementById('inv-cur-usd')?.classList.toggle('active', cur === '$');
  document.getElementById('inv-cur-ils')?.classList.toggle('active', cur === '₪');
  invSyncPnlBtn();
  const totalEl = document.getElementById('inv-portfolio-total');
  if (totalEl) totalEl.value = data.portfolioTotal || '';
  const dl = document.getElementById('inv-sym-list');
  if (dl) dl.innerHTML = Object.keys(SECTOR_MAP).filter(s => !symIsCrypto(s)).map(s => `<option value="${s}">`).join('');
  invRenderRows(data.holdings || []);
  invRenderDeposits(data.deposits || []);
  invSyncTargetInputs();
  invRecalc();
  invFetchPrices();
  // Keep holdings P&L live: refresh quotes every 60s while on this tab
  // (cleared in switchTab when leaving). No DB write on these ticks.
  if (_invPriceTimer) clearInterval(_invPriceTimer);
  _invPriceTimer = setInterval(() => invFetchPrices(false), 60000);
}
let _invPriceTimer = null;

function invRenderRows(holdings) {
  const tbody = document.getElementById('inv-tbody');
  if (!tbody) return;
  if (!holdings.length) {
    tbody.innerHTML = '';
    return;
  }
  tbody.innerHTML = holdings.map((h, i) => {
    const locked = h.locked !== false;
    const ro = locked ? 'disabled' : '';
    const symCell = locked
      ? `<input type="hidden" value="${esc(h.symbol||'')}"><span class="inv-sym-chip">${esc(h.symbol||'—')}</span>`
      : `<input class="inv-sym-input" type="text" value="${esc(h.symbol||'')}" placeholder="AAPL" list="inv-sym-list" oninput="this.value=this.value.toUpperCase();invRecalc();invAutoSector(${i});">`;
    return `
    <tr data-idx="${i}" class="${locked?'inv-row-locked':'inv-row-edit'}">
      <td ${locked&&h.symbol?`onclick="invToggleBuyRow(${i})" style="cursor:pointer"`:''}>${symCell}</td>
      <td><input class="inv-sector-input" type="text" value="${esc(h.sector||'')}" placeholder="טכנולוגיה" data-sector-idx="${i}" ${ro} ${locked?'':'oninput="invAutoSave()"'}></td>
      <td>
        <select class="inv-cat-sel" ${ro} onchange="invRecalc();${locked?'':'invAutoSave()'}">
          <option value="">—</option>
          <option value="blue" ${h.cat==='blue'?'selected':''}>🔵 Blue Chip</option>
          <option value="green" ${h.cat==='green'?'selected':''}>🟢 Growth</option>
          <option value="yellow" ${h.cat==='yellow'?'selected':''}>🟡 Speculative</option>
        </select>
      </td>
      <td><input type="number" value="${h.entryShares||''}" placeholder="0" min="0" step="any" ${ro} ${locked?'':'oninput="invRecalc();invAutoSave()"'}></td>
      <td><input type="number" value="${h.entryPrice||''}" placeholder="0.00" min="0" step="any" ${ro} ${locked?'':'oninput="invRecalc();invAutoSave()"'}></td>
      <td><input type="number" value="${h.currentPrice||''}" placeholder="0.00" min="0" step="any" readonly tabindex="-1" style="cursor:default;opacity:0.7;" title="מחיר נשלף אוטומטית"></td>
      <td><span class="inv-avg-label" id="inv-avg-${i}">—</span></td>
      <td><span class="inv-value-label" id="inv-val-${i}">—</span></td>
      <td><span class="inv-pnl-label" id="inv-pnl-${i}">—</span></td>
      <td><div class="inv-pct-bar"><div class="inv-pct-fill" id="inv-bar-${i}" style="width:0%"></div><span class="inv-pct-label" id="inv-pct-${i}">0%</span></div></td>
      <td><span class="inv-cat-rem" id="inv-catrem-${i}">—</span></td>
      <td style="white-space:nowrap;width:52px;text-align:center;">
        ${locked
          ? `<button class="inv-edit-btn" onclick="invEditRow(${i})" title="ערוך"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>`
          : `<button class="inv-lock-btn" onclick="invLockRow(${i})" title="שמור"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></button>`
        }
        ${locked ? `<button class="inv-buy-btn" onclick="invToggleBuyRow(${i})" title="הוסף רכישה">+</button>` : ''}
        <button class="inv-del-btn" onclick="invDeleteRow(${i})">×</button>
      </td>
    </tr>`;
  }).join('');
  invRecalc();
}

const ALLOC_DEFAULTS = { blue: 0.60, green: 0.35, yellow: 0.05, cash: 0.05 };
let ALLOC_TARGETS = { blue: 0.60, green: 0.35, yellow: 0.05 };
let ALLOC_CASH_TARGET = 0.05;
const ALLOC_COLORS  = { blue: '#818cf8', green: '#34d399', yellow: '#fbbf24' };

function invApplyTargets(tg) {
  const v = tg && typeof tg === 'object' ? tg : {};
  ALLOC_TARGETS = {
    blue:   v.blue   != null ? +v.blue   : ALLOC_DEFAULTS.blue,
    green:  v.green  != null ? +v.green  : ALLOC_DEFAULTS.green,
    yellow: v.yellow != null ? +v.yellow : ALLOC_DEFAULTS.yellow,
  };
  ALLOC_CASH_TARGET = v.cash != null ? +v.cash : ALLOC_DEFAULTS.cash;
}

function invTargetsPayload() {
  return { blue: ALLOC_TARGETS.blue, green: ALLOC_TARGETS.green, yellow: ALLOC_TARGETS.yellow, cash: ALLOC_CASH_TARGET };
}

function invSetTarget(cat, pctStr) {
  let pct = parseFloat(pctStr);
  if (!isFinite(pct)) pct = 0;
  pct = Math.max(0, Math.min(100, pct));
  const frac = pct / 100;
  const prev = cat === 'cash' ? ALLOC_CASH_TARGET : ALLOC_TARGETS[cat];
  if (cat === 'cash') ALLOC_CASH_TARGET = frac;
  else ALLOC_TARGETS[cat] = frac;
  const total = ALLOC_TARGETS.blue + ALLOC_TARGETS.green + ALLOC_TARGETS.yellow + ALLOC_CASH_TARGET;
  if (total > 1.0001) {
    if (cat === 'cash') ALLOC_CASH_TARGET = prev;
    else ALLOC_TARGETS[cat] = prev;
    invSyncTargetInputs();
    const over = Math.round(total * 100);
    toast(`סה"כ יעדים ${over}% — חייב להיות עד 100%`, 'error');
    return;
  }
  invSyncTargetInputs();
  invRecalc();
  const data = invLoad();
  data.allocTargets = invTargetsPayload();
  invSaveData(data);
}

function invSyncTargetInputs() {
  const set = (id, frac) => { const el = document.getElementById(id); if (el && document.activeElement !== el) el.value = Math.round(frac * 100); };
  set('inv-tg-blue', ALLOC_TARGETS.blue);
  set('inv-tg-green', ALLOC_TARGETS.green);
  set('inv-tg-yellow', ALLOC_TARGETS.yellow);
  set('inv-tg-cash', ALLOC_CASH_TARGET);
}

function invRecalc() {
  const tbody = document.getElementById('inv-tbody');
  if (!tbody) return;
  const rows = tbody.querySelectorAll('tr[data-idx]');

  // Pass 1: accumulate totals
  let totalCost = 0, totalCurrentValue = 0, totalUnrealizedPnL = null;
  const byCat = { blue: 0, green: 0, yellow: 0 };
  const byCatValue = { blue: 0, green: 0, yellow: 0 };
  const rowData = [];
  rows.forEach(row => {
    const inputs = row.querySelectorAll('input');
    const cat          = row.querySelector('.inv-cat-sel')?.value || '';
    const entryShares  = +(inputs[2]?.value) || 0;
    const entryPrice   = +(inputs[3]?.value) || 0;
    const currentPrice = +(inputs[4]?.value) || 0;
    const value  = currentPrice > 0 ? entryShares * currentPrice : entryShares * entryPrice;
    const cost   = entryShares * entryPrice;
    const pnlAmt = (currentPrice > 0 && entryPrice > 0) ? (currentPrice - entryPrice) * entryShares : null;
    const pnlPct = (pnlAmt !== null && cost > 0) ? (pnlAmt / cost) * 100 : null;
    totalCost         += cost;
    totalCurrentValue += value;
    if (pnlAmt !== null) totalUnrealizedPnL = (totalUnrealizedPnL || 0) + pnlAmt;
    if (cat && byCat[cat] !== undefined) byCat[cat] += cost;
    if (cat && byCatValue[cat] !== undefined) byCatValue[cat] += value;
    rowData.push({ i: +row.dataset.idx, cat, value, cost, pnlAmt, pnlPct });
  });

  // Total portfolio is the anchor (input). Free cash is whatever isn't invested
  // in holdings (total − holdings value), so it stays in sync with the total and
  // grows when a monthly deposit raises the total.
  const portfolioTotal = +(document.getElementById('inv-portfolio-total')?.value) || 0;
  const cash = Math.max(0, portfolioTotal - totalCurrentValue);
  const effectiveTotal = portfolioTotal;

  // Pass 2: render per-row display (pct now uses totalCost as denominator)
  const cur = invGetCurrency();
  const pnlMode = invGetPnlMode();
  rowData.forEach(({ i, value, cost, pnlAmt, pnlPct }) => {
    const pct   = effectiveTotal > 0 ? (value / effectiveTotal) * 100 : 0;
    const avgEl = document.getElementById(`inv-avg-${i}`);
    const valEl = document.getElementById(`inv-val-${i}`);
    const pnlEl = document.getElementById(`inv-pnl-${i}`);
    const barEl = document.getElementById(`inv-bar-${i}`);
    const pctEl = document.getElementById(`inv-pct-${i}`);
    const inputs = tbody.querySelector(`tr[data-idx="${i}"]`)?.querySelectorAll('input');
    const entryPrice = +(inputs?.[3]?.value) || 0;
    if (avgEl) avgEl.textContent = entryPrice > 0 ? cur + entryPrice.toFixed(2) : '—';
    if (valEl) valEl.textContent = value > 0 ? cur + value.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2}) : '—';
    if (pnlEl) {
      if (pnlAmt !== null) {
        const sign = pnlAmt >= 0 ? '+' : '';
        pnlEl.textContent = pnlMode === 'amount'
          ? `${sign}${cur}${Math.abs(pnlAmt).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}`
          : `${sign}${pnlPct.toFixed(2)}%`;
        pnlEl.style.color = pnlAmt >= 0 ? 'var(--green)' : 'var(--red)';
        pnlEl.style.fontWeight = '600';
      } else {
        pnlEl.textContent = '—'; pnlEl.style.color = ''; pnlEl.style.fontWeight = '';
      }
    }
    if (barEl) barEl.style.width = Math.min(pct, 100) + '%';
    if (pctEl) pctEl.textContent = pct > 0 ? pct.toFixed(1) + '%' : '0%';
  });

  // Allocated % = invested value / total portfolio
  const allocEl = document.getElementById('inv-allocated-pct');
  if (allocEl) {
    const allocPct = effectiveTotal > 0 ? (totalCost / effectiveTotal * 100) : 0;
    allocEl.textContent = allocPct.toFixed(1) + '%';
    allocEl.style.color = allocPct > 100 ? 'var(--red)' : 'var(--accent)';
  }
  // Free cash = total − invested (live). Shown next to the total input.
  const cashValEl = document.getElementById('inv-cash-value');
  if (cashValEl) cashValEl.textContent = portfolioTotal > 0
    ? invGetCurrency() + cash.toLocaleString('en-US', { maximumFractionDigits: 2 })
    : '—';

  // Allocation bars — invested COST deployed vs target (so unrealized profit
  // never pushes a category "over"). byCat = cost, byCatValue = current value.
  const c = invGetCurrency();
  Object.entries(ALLOC_TARGETS).forEach(([cat, target]) => {
    const targetAmt  = effectiveTotal * target;
    const currentAmt = byCat[cat];
    const currentPct = effectiveTotal > 0 ? (currentAmt / effectiveTotal * 100) : 0;
    const remaining  = Math.max(0, targetAmt - currentAmt);
    const over       = effectiveTotal > 0 && currentAmt > targetAmt;
    const barW       = targetAmt > 0 ? Math.min(currentAmt / targetAmt * 100, 100) : 0;
    const barEl = document.getElementById(`alloc-bar-${cat}`);
    const invEl = document.getElementById(`alloc-inv-${cat}`);
    const curEl = document.getElementById(`alloc-cur-${cat}`);
    const remEl = document.getElementById(`alloc-rem-${cat}`);
    if (barEl) { barEl.style.width = barW + '%'; barEl.style.background = over ? 'var(--red)' : ALLOC_COLORS[cat]; }
    if (invEl) invEl.textContent = currentAmt > 0 ? `${c}${currentAmt.toLocaleString('en-US', {maximumFractionDigits:0})}` : '—';
    if (curEl) { curEl.textContent = currentPct.toFixed(1) + '%'; curEl.style.color = over ? 'var(--red)' : 'var(--text2)'; }
    if (remEl) {
      if (effectiveTotal === 0) { remEl.textContent = ''; return; }
      remEl.textContent = over
        ? `${t('inv_overby')} ${c}${(currentAmt - targetAmt).toLocaleString('en-US', {maximumFractionDigits:0})}`
        : `${t('inv_free')}: ${c}${remaining.toLocaleString('en-US', {maximumFractionDigits:0})}`;
      remEl.style.color = over ? 'var(--red)' : 'var(--text3)';
    }
  });

  // Cash row
  const cashTarget = portfolioTotal * ALLOC_CASH_TARGET;
  const cashPct = portfolioTotal > 0 ? (cash / portfolioTotal * 100) : 0;
  const cashBarW = cashTarget > 0 ? Math.min(cash / cashTarget * 100, 100) : 0;
  const cashOver = portfolioTotal > 0 && cash > cashTarget;
  const cashBarEl = document.getElementById('alloc-bar-cash');
  const cashCurEl = document.getElementById('alloc-cur-cash');
  const cashRemEl = document.getElementById('alloc-rem-cash');
  if (cashBarEl) { cashBarEl.style.width = cashBarW + '%'; cashBarEl.style.background = '#2dd4bf'; }
  const cashInvEl = document.getElementById('alloc-inv-cash');
  if (cashInvEl) cashInvEl.textContent = cash > 0 ? c + cash.toLocaleString('en-US', {maximumFractionDigits:0}) : '—';
  if (cashCurEl) { cashCurEl.textContent = cashPct.toFixed(1) + '%'; cashCurEl.style.color = 'var(--text2)'; }
  if (cashRemEl) {
    cashRemEl.textContent = '';
  }

  const catRemaining = {};
  Object.entries(ALLOC_TARGETS).forEach(([cat, target]) => {
    catRemaining[cat] = Math.max(0, portfolioTotal * target - byCat[cat]);
  });
  rowData.forEach(({ i, cat }) => {
    const remEl = document.getElementById(`inv-catrem-${i}`);
    if (!remEl) return;
    if (!cat || portfolioTotal === 0) { remEl.textContent = '—'; remEl.style.color = ''; return; }
    const over = byCat[cat] > portfolioTotal * ALLOC_TARGETS[cat];
    remEl.textContent = over ? t('inv_over') : `${c}${catRemaining[cat].toLocaleString('en-US',{maximumFractionDigits:0})}`;
    remEl.style.color = over ? 'var(--red)' : 'var(--green)';
  });

  invUpdateDonut(byCat, effectiveTotal, cash);
  invRenderDeposits(invLoad().deposits || [], totalCurrentValue);

  // Summary bar
  const costEl = document.getElementById('inv-sum-cost');
  const valEl2 = document.getElementById('inv-sum-value');
  const pnlEl2 = document.getElementById('inv-sum-pnl');
  if (costEl) costEl.textContent = totalCost > 0 ? cur + totalCost.toLocaleString('en-US',{maximumFractionDigits:0}) : '—';
  if (valEl2) valEl2.textContent = totalCurrentValue > 0 ? cur + totalCurrentValue.toLocaleString('en-US',{maximumFractionDigits:0}) : '—';
  if (pnlEl2) {
    if (totalUnrealizedPnL !== null) {
      const sign = totalUnrealizedPnL >= 0 ? '+' : '';
      const pct  = totalCost > 0 ? (totalUnrealizedPnL / totalCost * 100).toFixed(1) : null;
      pnlEl2.textContent = `${sign}${cur}${Math.abs(totalUnrealizedPnL).toLocaleString('en-US',{maximumFractionDigits:0})}${pct !== null ? ` (${sign}${pct}%)` : ''}`;
      pnlEl2.classList.remove('pnl-pos', 'pnl-neg');
      pnlEl2.classList.add(totalUnrealizedPnL >= 0 ? 'pnl-pos' : 'pnl-neg');
    } else { pnlEl2.textContent = '—'; pnlEl2.classList.remove('pnl-pos', 'pnl-neg'); }
  }
}

function invGetCurrentData() {
  const tbody = document.getElementById('inv-tbody');
  const rows = tbody ? tbody.querySelectorAll('tr[data-idx]') : [];
  const holdings = [];
  rows.forEach(row => {
    const inputs = row.querySelectorAll('input');
    const cat = row.querySelector('.inv-cat-sel')?.value || '';
    holdings.push({
      symbol:       (inputs[0]?.value || '').toUpperCase().trim(),
      sector:       (inputs[1]?.value || '').trim(),
      cat,
      entryShares:  +(inputs[2]?.value) || 0,
      entryPrice:   +(inputs[3]?.value) || 0,
      currentPrice: +(inputs[4]?.value) || 0,
    });
  });
  return {
    portfolioTotal: document.getElementById('inv-portfolio-total')?.value || '',
    holdings: holdings.filter(h => h.symbol || h.entryShares || h.entryPrice),
    deposits: invLoad().deposits || []
  };
}

function invEditRow(i) {
  const data = invGetCurrentData();
  if (data.holdings[i]) { data.holdings[i].locked = false; _invData = data; invRenderRows(data.holdings); }
}

async function invLockRow(i) {
  const data = invGetCurrentData();
  if (!data.holdings[i]) return;
  data.holdings[i].locked = true;
  const ok = await invSaveData(data);
  if (ok) toast('נשמר ✓', 'success');
  invRenderRows(data.holdings);
  invRecalc();
}

function invAddRow() {
  const data = invGetCurrentData();
  data.holdings.push({ symbol:'', entryShares:0, entryPrice:0, locked: false });
  invRenderRows(data.holdings);
  const tbody = document.getElementById('inv-tbody');
  if (tbody) {
    const newRow = tbody.querySelector('tr[data-idx="' + (data.holdings.length - 1) + '"]');
    newRow?.querySelector('input')?.focus();
  }
}

async function invFetchPrices(save = true) {
  const tbody = document.getElementById('inv-tbody');
  if (!tbody) return;
  const rows = [...tbody.querySelectorAll('tr[data-idx]')];
  const symbols = [];
  rows.forEach(row => {
    const symInput = row.querySelector('input');
    const sym = symInput?.value?.trim().toUpperCase();
    if (sym) symbols.push({ row, sym });
  });
  if (!symbols.length) return;

  const token = await _getToken();
  let updated = 0;
  await Promise.all(symbols.map(async ({ row, sym }) => {
    try {
      const r = await fetch(`${SUPABASE_URL}/functions/v1/finnhub?path=quote&symbol=${encodeURIComponent(sym)}`,
        { headers: { 'Authorization': `Bearer ${token}` } });
      const data = await r.json();
      const price = data.c || data.pc;
      if (!price) return;
      const inputs = row.querySelectorAll('input');
      const priceInput = inputs[4];
      if (priceInput) { priceInput.value = price; updated++; }
    } catch {}
  }));

  if (updated > 0) {
    _invPricesUpdatedAt = Date.now();
    invRecalc();
    if (save) invAutoSave();
    invUpdatePricesTimestamp();
  }
}

let _invPricesUpdatedAt = null;
function invUpdatePricesTimestamp() {
  const el = document.getElementById('inv-prices-updated');
  if (!el || !_invPricesUpdatedAt) return;
  const mins = Math.round((Date.now() - _invPricesUpdatedAt) / 60000);
  el.textContent = mins === 0 ? t('inv_just_now') : `${mins} min ago`;
}

let _invPosRowIdx = null;

function invToggleBuyRow(i) {
  _invPosRowIdx = i;
  const tbody = document.getElementById('inv-tbody');
  const mainRow = tbody?.querySelector(`tr[data-idx="${i}"]`);
  if (!mainRow) return;
  const inputs = mainRow.querySelectorAll('input');
  const sym = inputs[0]?.value || '';
  const oldQty   = +(inputs[2]?.value) || 0;
  const oldPrice = +(inputs[3]?.value) || 0;
  const cur = invGetCurrency();

  document.getElementById('inv-pos-modal-title').textContent = sym;
  const currentPrice = +(inputs[4]?.value) || 0;
  document.getElementById('inv-pos-qty').value = '';
  document.getElementById('inv-pos-price').value = '';
  document.getElementById('inv-pos-current-price').value = currentPrice || '';
  document.getElementById('inv-pos-date').value = new Date().toISOString().slice(0,10);
  document.getElementById('inv-pos-result').style.display = 'none';
  invSetPosMode('buy');

  const updatePreview = () => {
    const qty   = +(document.getElementById('inv-pos-qty')?.value) || 0;
    const price = +(document.getElementById('inv-pos-price')?.value) || 0;
    const mode  = document.getElementById('inv-pos-modal')?.dataset.mode || 'buy';
    const res   = document.getElementById('inv-pos-result');
    if (!qty) { res.style.display = 'none'; return; }
    res.style.display = 'block';
    if (mode === 'buy' && price) {
      const totalQty = oldQty + qty;
      const avg = (oldQty * oldPrice + qty * price) / totalQty;
      res.innerHTML = `כמות חדשה: <b>${totalQty}</b> &nbsp;|&nbsp; שער ממוצע חדש: <b>${cur}${avg.toFixed(2)}</b>`;
    } else if (mode === 'sell') {
      const remaining = oldQty - qty;
      res.innerHTML = remaining > 0
        ? `כמות שתישאר: <b>${remaining}</b>`
        : `<span style="color:var(--red)">הפוזיציה תיסגר לחלוטין</span>`;
    } else { res.style.display = 'none'; }
  };

  document.getElementById('inv-pos-qty').oninput   = updatePreview;
  document.getElementById('inv-pos-price').oninput = updatePreview;

  const modal = document.getElementById('inv-position-modal');
  modal.dataset.mode = 'buy';
  modal.classList.add('open');
  setTimeout(() => document.getElementById('inv-pos-qty')?.focus(), 80);
}

function invSetPosMode(mode) {
  document.getElementById('inv-pos-buy-btn')?.classList.toggle('buy-active',  mode === 'buy');
  document.getElementById('inv-pos-buy-btn')?.classList.toggle('sell-active', false);
  document.getElementById('inv-pos-sell-btn')?.classList.toggle('sell-active', mode === 'sell');
  document.getElementById('inv-pos-sell-btn')?.classList.toggle('buy-active',  false);
  const priceGroup = document.getElementById('inv-pos-price-group');
  if (priceGroup) priceGroup.style.display = mode === 'sell' ? 'none' : '';
  const modal = document.getElementById('inv-position-modal');
  if (modal) modal.dataset.mode = mode;
  document.getElementById('inv-pos-qty')?.dispatchEvent(new Event('input'));
}

function invClosePositionModal() {
  document.getElementById('inv-position-modal')?.classList.remove('open');
  _invPosRowIdx = null;
}

function invConfirmPositionModal() {
  const i = _invPosRowIdx;
  if (i === null) return;
  const mode  = document.getElementById('inv-position-modal')?.dataset.mode || 'buy';
  const qty   = +(document.getElementById('inv-pos-qty')?.value) || 0;
  const price = +(document.getElementById('inv-pos-price')?.value) || 0;
  if (!qty) { toast('הכנס כמות', 'error'); return; }
  if (mode === 'buy' && !price) { toast('הכנס מחיר', 'error'); return; }

  const tbody = document.getElementById('inv-tbody');
  const mainRow = tbody?.querySelector(`tr[data-idx="${i}"]`);
  if (!mainRow) return;
  const inputs = mainRow.querySelectorAll('input');
  const oldQty   = +(inputs[2]?.value) || 0;
  const oldPrice = +(inputs[3]?.value) || 0;
  const cur = invGetCurrency();

  invClosePositionModal();

  const newCurrentPrice = +(document.getElementById('inv-pos-current-price')?.value) || 0;
  if (newCurrentPrice && inputs[4]) inputs[4].value = newCurrentPrice;

  if (mode === 'buy') {
    const totalQty = oldQty + qty;
    const avgPrice = totalQty > 0 ? (oldQty * oldPrice + qty * price) / totalQty : price;
    if (inputs[2]) inputs[2].value = totalQty;
    if (inputs[3]) inputs[3].value = avgPrice.toFixed(4);
    invRecalc(); invAutoSave();
    toast(`עודכן: ${totalQty} מניות @ ${cur}${avgPrice.toFixed(2)} ממוצע`, 'success');
  } else {
    const newQty = oldQty - qty;
    if (newQty <= 0) {
      invDeleteRow(i);
      toast('פוזיציה הוסרה', 'success');
      return;
    }
    if (inputs[2]) inputs[2].value = newQty;
    invRecalc(); invAutoSave();
    toast(`עודכן: ${newQty} מניות נותרו`, 'success');
  }
}

function invDeleteRow(i) {
  const data = invGetCurrentData();
  data.holdings.splice(i, 1);
  invRenderRows(data.holdings);
  invSaveData(data);
}

function invMergeDuplicates(holdings) {
  const merged = [];
  holdings.forEach(h => {
    if (!h.symbol) { merged.push(h); return; }
    const existing = merged.find(m => m.symbol === h.symbol);
    if (existing) {
      const totalShares = existing.entryShares + h.entryShares;
      const totalCost   = (existing.entryShares * existing.entryPrice) + (h.entryShares * h.entryPrice);
      existing.entryShares = totalShares;
      existing.entryPrice  = totalShares > 0 ? totalCost / totalShares : 0;
      if (!existing.sector && h.sector) existing.sector = h.sector;
      if (!existing.cat && h.cat) existing.cat = h.cat;
    } else {
      merged.push({ ...h });
    }
  });
  return merged;
}

function invAutoSave() {
  clearTimeout(_invSaveTimer);
  _invSaveTimer = setTimeout(() => {
    if (!_invData) return;
    const data = invGetCurrentData();
    const merged = invMergeDuplicates(data.holdings);
    if (merged.length !== data.holdings.length) {
      data.holdings = merged;
      invRenderRows(merged);
    }
    invSaveData(data);
  }, 800);
}

function invSave() {
  const data = invGetCurrentData();
  invSaveData(data);
  toast(t('inv_saved'), 'success');
}

const _invSectorTimers = {};
function invAutoSector(idx) {
  const tbody = document.getElementById('inv-tbody');
  const row = tbody?.querySelector(`tr[data-idx="${idx}"]`);
  if (!row) return;
  const sym = row.querySelector('.inv-sym-input')?.value.trim().toUpperCase().replace(/[^A-Z0-9._\-]/g,'') || '';
  const sectorEl = row.querySelector('.inv-sector-input');
  if (!sectorEl || !sym) return;
  const local = SECTOR_MAP[sym];
  if (local) {
    sectorEl.value = local;
    const catSel = row.querySelector('.inv-cat-sel');
    if (catSel && !catSel.value) { catSel.value = SECTOR_TO_CAT[local] || ''; }
    invRecalc();
    return;
  }
  clearTimeout(_invSectorTimers[idx]);
  if (sym.length < 2) return;
  _invSectorTimers[idx] = setTimeout(async () => {
    try {
      const token = await _getToken();
      if (!token) return;
      const res = await fetch(`${SUPABASE_URL}/functions/v1/finnhub?path=stock%2Fprofile2&symbol=${encodeURIComponent(sym)}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) return;
      const data = await res.json();
      const currentSym = row.querySelector('.inv-sym-input')?.value.trim().toUpperCase();
      if (data.finnhubIndustry && currentSym === sym) {
        sectorEl.value = data.finnhubIndustry;
        const catSel = row.querySelector('.inv-cat-sel');
        if (catSel && !catSel.value) { catSel.value = SECTOR_TO_CAT[data.finnhubIndustry] || ''; }
        invRecalc();
      }
    } catch { /* silent */ }
  }, 600);
}

function invAutoSaveTotal() {
  const val = document.getElementById('inv-portfolio-total')?.value || '';
  // The portfolio total lives in user_settings — persist only that. Never rewrite
  // the holdings here: invLoad() may return stale localStorage and would clobber
  // the precise holdings stored in the DB.
  if (_invData) _invData.portfolioTotal = val;
  _saveUserSettings({ portfolio_total: val ? +val : null });
}



function invUpdateDonut(byCat, portfolioTotal, cash = 0) {
  const C = 314.159;
  const pcts = {
    blue:   portfolioTotal > 0 ? byCat.blue   / portfolioTotal * 100 : 0,
    green:  portfolioTotal > 0 ? byCat.green  / portfolioTotal * 100 : 0,
    yellow: portfolioTotal > 0 ? byCat.yellow / portfolioTotal * 100 : 0,
  };
  const totalAllocated = pcts.blue + pcts.green + pcts.yellow;
  // Cash = real free cash share. The remainder (unrealized gains) stays unfilled.
  pcts.cash = portfolioTotal > 0 ? Math.min(cash / portfolioTotal * 100, 100 - totalAllocated) : 0;

  const order = ['blue', 'green', 'yellow', 'cash'];
  let offset = 0;
  order.forEach(key => {
    const el = document.getElementById(`donut-${key}`);
    if (!el) return;
    const len = pcts[key] / 100 * C;
    el.setAttribute('stroke-dasharray', `${len.toFixed(2)} ${C}`);
    el.setAttribute('stroke-dashoffset', `${(-offset / 100 * C).toFixed(2)}`);
    offset += pcts[key];
  });

  const lbl = document.getElementById('donut-label-pct');
  if (lbl) lbl.textContent = totalAllocated.toFixed(0) + '%';
  ['blue','green','yellow','cash'].forEach(k => {
    const el = document.getElementById(`leg-${k}`);
    if (el) el.textContent = (pcts[k] || 0).toFixed(1) + '%';
  });
}

function invAddDeposit() {
  const month    = document.getElementById('inv-dep-month')?.value;
  const amount   = +(document.getElementById('inv-dep-amount')?.value) || 0;
  const currency = document.getElementById('inv-dep-currency')?.value || '$';
  if (!month || !amount) { toast('Enter month and amount', 'error'); return; }
  // Read holdings from the DOM (precise) — never from stale localStorage.
  const data = invGetCurrentData();
  if (!data.deposits) data.deposits = [];
  data.deposits.push({ month, amount, currency });
  data.deposits.sort((a, b) => b.month.localeCompare(a.month));
  const totalElD = document.getElementById('inv-portfolio-total');
  const newTotal = (+(totalElD?.value) || 0) + amount;
  if (totalElD) totalElD.value = newTotal;
  data.portfolioTotal = String(newTotal);
  invSaveData(data);
  _saveUserSettings({ portfolio_total: newTotal });
  invRenderDeposits(data.deposits);
  invRecalc();
  document.getElementById('inv-dep-amount').value = '';
}

function invDeleteDeposit(idx) {
  const deposits = invLoad().deposits || [];
  if (!deposits.length) return;
  deposits.splice(idx, 1);
  // Holdings from the DOM (precise) — avoid clobbering DB with stale localStorage.
  const data = invGetCurrentData();
  data.deposits = deposits;
  invSaveData(data);
  invRenderDeposits(deposits);
}

function invRenderDeposits(deposits = [], totalCurrentValue = 0) {
  const listEl = document.getElementById('dep-list');
  if (!listEl) return;
  const totalDeposited = deposits.reduce((s, d) => s + (+d.amount || 0), 0);

  const totalEl = document.getElementById('dep-total-val');
  const pnlEl   = document.getElementById('dep-pnl-val');

  const cur = invGetCurrency();
  if (totalEl) totalEl.textContent = cur + totalDeposited.toLocaleString('en-US', { maximumFractionDigits: 0 });
  if (pnlEl) {
    if (totalCurrentValue > 0 && totalDeposited) {
      const pnl    = totalCurrentValue - totalDeposited;
      const pnlPct = (pnl / totalDeposited * 100).toFixed(1);
      pnlEl.textContent = (pnl >= 0 ? '+' : '') + cur + Math.abs(pnl).toLocaleString('en-US', { maximumFractionDigits: 0 }) + ` (${pnl >= 0 ? '+' : ''}${pnlPct}%)`;
      pnlEl.style.color = pnl >= 0 ? 'var(--green)' : 'var(--red)';
    } else {
      pnlEl.textContent = '—';
      pnlEl.style.color = '';
    }
  }

  if (!deposits.length) { listEl.innerHTML = ''; return; }
  const heMonth = m => {
    const [y, mo] = m.split('-');
    return new Date(+y, +mo - 1, 1).toLocaleDateString('he-IL', { month: 'long', year: 'numeric' });
  };
  let cumul = totalDeposited;
  listEl.innerHTML = `<table class="inv-dep-table"><thead><tr><th>${t('inv_dep_month')}</th><th>${t('inv_dep_amount')}</th><th>${t('inv_dep_cumulative')}</th><th></th></tr></thead><tbody>${
    deposits.map((d, i) => {
      const dCur = d.currency || cur;
      const row = `<tr><td>${heMonth(d.month)}</td><td>${dCur}${(+d.amount).toLocaleString('en-US',{maximumFractionDigits:0})}</td><td>${cur}${cumul.toLocaleString('en-US',{maximumFractionDigits:0})}</td><td><button class="inv-dep-del" onclick="invDeleteDeposit(${i})">×</button></td></tr>`;
      cumul -= +d.amount;
      return row;
    }).join('')
  }</tbody></table>`;
}

// ===== INVESTMENT ADVISOR =====
function invSymbolAutocomplete(val) {
  const list = document.getElementById('inv-adv-symbol-list');
  if (!list) return;
  list.innerHTML = '';
  if (!val || val.length < 1) return;
  let count = 0;
  for (const s of STOCK_SYMBOLS) {
    if (s.startsWith(val) && !symIsCrypto(s)) {
      const opt = document.createElement('option');
      opt.value = s;
      list.appendChild(opt);
      if (++count >= 15) break;
    }
  }
}

function invToggleSettings() {
  const p = document.getElementById('inv-settings-panel');
  p.style.display = p.style.display === 'none' ? 'flex' : 'none';
}

function formatInvOutput(raw) {
  let h = raw
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  h = h.replace(/={2,}\s*(.+?)\s*={2,}/g, '<span class="inv-section-h">$1</span>');
  h = h.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  h = h.replace(/✅/g, '<span class="inv-ok">✅</span>');
  h = h.replace(/⚠️/g, '<span class="inv-warn">⚠️</span>');
  h = h.replace(/❌/g, '<span class="inv-bad">❌</span>');
  h = h.replace(/❓/g, '<span class="inv-unk">❓</span>');
  h = h.replace(/\n/g, '<br>');
  return h;
}

async function invAnalyze() {
  const sym = (document.getElementById('inv-adv-symbol')?.value || '').trim().toUpperCase();
  if (!sym) { toast('הכנס סימבול מניה', 'error'); return; }

  const isIsraeli = sym.endsWith('.TA');

  const btn      = document.getElementById('inv-analyze-btn');
  const out      = document.getElementById('inv-adv-output');
  const dataPre  = document.getElementById('inv-data-pre');
  const outWrap  = document.getElementById('inv-output-wrap');
  btn.disabled = true;
  btn.textContent = '⏳ מנתח...';
  outWrap.style.display = 'flex';
  out.innerHTML = '';
  dataPre.textContent = 'מושך נתונים...';

  try {
    const token = await _getToken();
    if (!token) { toast('נא להתחבר תחילה', 'error'); return; }

    const hdr = { Authorization: `Bearer ${token}` };
    const base = `${SUPABASE_URL}/functions/v1/finnhub`;
    const fmpKey = getFmpKey();
    const fmpBase = `${SUPABASE_URL}/functions/v1/fmp`;

    // ── שלב 0: SEC EDGAR ישיר (הכי עדכני — לפני Finnhub) ──
    let edgarData = null;
    if (!isIsraeli) {
      dataPre.textContent = 'מושך נתונים מ-SEC EDGAR...';
      try {
        const edgarRes = await fetch(`${SUPABASE_URL}/functions/v1/edgar?symbol=${encodeURIComponent(sym)}`, { headers: hdr });
        if (edgarRes.ok) {
          edgarData = await edgarRes.json();
          if (edgarData?.error) edgarData = null;
        }
      } catch(e) { console.warn('[EDGAR] failed:', e); }
    }

    // ── שלב 1: Finnhub — עם retry על 429 ──
    dataPre.textContent = 'מושך נתונים מ-Finnhub...';
    const fetchRetry = async (url, opts, retries = 3) => {
      for (let i = 0; i < retries; i++) {
        const r = await fetch(url, opts);
        if (r.status !== 429) return r;
        await new Promise(res => setTimeout(res, 1200 * (i + 1)));
      }
      return { ok: false, status: 429 };
    };
    const fh = u => fetchRetry(u, { headers: hdr });
    const [metricRes, profileRes, quoteRes, earningsRes, financialsQRes, financialsARes] = await Promise.all([
      fh(`${base}?path=stock%2Fmetric&symbol=${encodeURIComponent(sym)}&metric=all`),
      fh(`${base}?path=stock%2Fprofile2&symbol=${encodeURIComponent(sym)}`),
      fh(`${base}?path=quote&symbol=${encodeURIComponent(sym)}`),
      fh(`${base}?path=stock%2Fearnings&symbol=${encodeURIComponent(sym)}`),
      isIsraeli ? Promise.resolve({ok:false}) : fh(`${base}?path=stock%2Ffinancials-reported&symbol=${encodeURIComponent(sym)}&freq=quarterly`),
      isIsraeli ? Promise.resolve({ok:false}) : fh(`${base}?path=stock%2Ffinancials-reported&symbol=${encodeURIComponent(sym)}&freq=annual`),
    ]);

    const metricData      = metricRes.ok  ? await metricRes.json()  : {};
    const profileData     = profileRes.ok ? await profileRes.json() : {};
    let   quoteData       = quoteRes.ok   ? await quoteRes.json()   : {};
    const earningsData    = earningsRes.ok ? await earningsRes.json() : {};
    const financialsQData = (!isIsraeli && financialsQRes.ok) ? await financialsQRes.json() : {};
    const financialsAData = (!isIsraeli && financialsARes.ok) ? await financialsARes.json() : {};
    const qLatest = financialsQData?.data?.[0];
    const aLatest = financialsAData?.data?.[0];
    const financialsData = ((aLatest?.endDate||'') > (qLatest?.endDate||'')) ? financialsAData : financialsQData;
    let m = metricData.metric || {};
    const earnings = Array.isArray(earningsData) ? earningsData.slice(0, 4) : [];

    // ── שלב 2: FMP — דוחות כספיים (כשיש מפתח ולא ישראלי) ──
    let fmpData = null;
    let extDataSource = '';
    if (!isIsraeli && fmpKey) {
      out.textContent = 'מושך דוחות כספיים מ-FMP...';
      const [fmpQuoteRes, fmpProfileRes, fmpIncomeRes, fmpMetricsRes] = await Promise.all([
        fetch(`${fmpBase}?path=quote&symbol=${encodeURIComponent(sym)}`, { headers: hdr }),
        fetch(`${fmpBase}?path=profile&symbol=${encodeURIComponent(sym)}`, { headers: hdr }),
        fetch(`${fmpBase}?path=income-statement&symbol=${encodeURIComponent(sym)}&period=annual`, { headers: hdr }),
        fetch(`${fmpBase}?path=key-metrics&symbol=${encodeURIComponent(sym)}&period=annual`, { headers: hdr }),
      ]);
      const fmpQuote   = fmpQuoteRes.ok   ? await fmpQuoteRes.json()   : [];
      const fmpProfile = fmpProfileRes.ok ? await fmpProfileRes.json() : [];
      const fmpIncome  = fmpIncomeRes.ok  ? await fmpIncomeRes.json()  : [];
      const fmpMetrics = fmpMetricsRes.ok ? await fmpMetricsRes.json() : [];

      if (Array.isArray(fmpIncome) && fmpIncome.length > 0) {
        fmpData = { quote: fmpQuote[0]||{}, profile: fmpProfile[0]||{}, income: fmpIncome, metrics: fmpMetrics[0]||{} };
        extDataSource = 'FMP';
        if (fmpData.quote.price) quoteData = { c: fmpData.quote.price, dp: fmpData.quote.changesPercentage };
        if (fmpData.quote.yearHigh) m = { ...m, '52WeekHigh': fmpData.quote.yearHigh, '52WeekLow': fmpData.quote.yearLow };
        if (fmpData.quote.pe) m = { ...m, peTTM: fmpData.quote.pe };
      }
    }

    // ── שלב 3: Alpha Vantage — fallback כשאין FMP data ──
    const avKey = getAvKey();
    if (!fmpData && !isIsraeli && avKey) {
      out.textContent = 'מושך דוחות כספיים מ-Alpha Vantage...';
      const avBase = `${SUPABASE_URL}/functions/v1/alphavantage`;
      const avDelay = ms => new Promise(r => setTimeout(r, ms));
      const avQuoteRes    = await fetch(`${avBase}?function=GLOBAL_QUOTE&symbol=${encodeURIComponent(sym)}`, { headers: hdr });
      await avDelay(1100);
      const avOverviewRes = await fetch(`${avBase}?function=OVERVIEW&symbol=${encodeURIComponent(sym)}`, { headers: hdr });
      await avDelay(1100);
      const avIncomeRes   = await fetch(`${avBase}?function=INCOME_STATEMENT&symbol=${encodeURIComponent(sym)}`, { headers: hdr });
      const avQuoteRaw   = avQuoteRes.ok   ? await avQuoteRes.json()   : {};
      const avOverview   = avOverviewRes.ok ? await avOverviewRes.json() : {};
      const avIncomeRaw  = avIncomeRes.ok  ? await avIncomeRes.json()  : {};

      const avQ = avQuoteRaw['Global Quote'] || {};
      const avIncome = (avIncomeRaw.annualReports || []).slice(0, 4).map(r => ({
        date: r.fiscalDateEnding,
        revenue: +r.totalRevenue || null,
        netIncome: +r.netIncome || null,
        operatingIncome: +r.operatingIncome || null,
        ebitda: +r.ebitda || null,
        grossProfit: +r.grossProfit || null,
      }));

      if (avIncome.length > 0) {
        fmpData = {
          quote:   { price: +avQ['05. price']||0, changesPercentage: parseFloat(avQ['10. change percent']||'0'), yearHigh: +avOverview['52WeekHigh']||0, yearLow: +avOverview['52WeekLow']||0 },
          profile: { companyName: avOverview.Name||sym, industry: avOverview.Industry||'', mktCap: +avOverview.MarketCapitalization||0 },
          income:  avIncome,
          metrics: {},
        };
        extDataSource = 'Alpha Vantage';
        if (fmpData.quote.price)   quoteData = { c: fmpData.quote.price, dp: fmpData.quote.changesPercentage };
        if (fmpData.quote.yearHigh) m = { ...m, '52WeekHigh': fmpData.quote.yearHigh, '52WeekLow': fmpData.quote.yearLow };
        if (avOverview.PERatio && avOverview.PERatio !== 'None') {
          m = { ...m, peBasicExclExtraTTM: +avOverview.PERatio, peTTM: +avOverview.PERatio };
        }
      }
    }

    // Extract latest 2 quarterly SEC reports (Finnhub)
    const reports = financialsData?.data?.slice(0, 2) || [];
    const latestReport = reports[0] || null;
    const fhLatestPeriod = latestReport?.endDate?.split?.(' ')?.[0] || latestReport?.period || null;

    // EDGAR direct — prefer if more recent than Finnhub SEC
    const edgarFiling = edgarData?.latestFiling;
    const edgarPeriod = edgarFiling?.period || null;
    const latestPeriod = (edgarPeriod && (!fhLatestPeriod || edgarPeriod > fhLatestPeriod)) ? edgarPeriod : fhLatestPeriod;
    const dataSource   = (edgarPeriod && (!fhLatestPeriod || edgarPeriod > fhLatestPeriod))
      ? `SEC EDGAR ישיר (${edgarData.latestForm}${edgarFiling?.filed ? ', הוגש '+edgarFiling.filed : ''})`
      : 'Finnhub / SEC';

    // Staleness check: how many months since the latest report period?
    const today = new Date();
    const reportDate = latestPeriod ? new Date(latestPeriod) : null;
    const monthsOld = reportDate ? Math.round((today - reportDate) / (1000 * 60 * 60 * 24 * 30)) : null;
    const stalenessWarning = monthsOld == null
      ? '⚠️ לא ניתן לקבוע תאריך דוח'
      : monthsOld <= 4
        ? `✅ דוח עדכני (לפני ${monthsOld} חודשים)`
        : monthsOld <= 6
          ? `⚠️ דוח גבולי (לפני ${monthsOld} חודשים) — עשוי להיות לפני פרסום הרבעון האחרון`
          : `🔴 דוח ישן (לפני ${monthsOld} חודשים) — הנתונים עשויים לא לשקף מצב עכשווי`;

    const getRaw = (arr, ...concepts) => {
      for (const c of concepts) {
        const found = arr?.find(x => x.concept === c || x.concept === `us-gaap_${c}`);
        if (found?.value != null) return +found.value;
      }
      return null;
    };
    const get = (arr, ...concepts) => {
      const v = getRaw(arr, ...concepts);
      return v != null ? (v / 1e6).toFixed(1) + 'M' : 'אין נתון';
    };
    // SEC-derived metrics (authoritative — primary source for all companies)
    const secIC = latestReport?.report?.ic || [];
    const secBS = latestReport?.report?.bs || [];
    const secCF = latestReport?.report?.cf || [];
    const prevIC = (reports[1]?.report?.ic) || [];

    // Industry detection — drives concept selection + metric interpretation
    const industry = (profileData.finnhubIndustry || '').toLowerCase();
    const isFinancial = /bank|insurance|financial|fintech|reit|brokerage|capital market/.test(industry);
    const isHealthcare = /biotech|pharma|health|medical|drug/.test(industry);
    const isEnergy     = /oil|gas|energy|mining|utilities|coal/.test(industry);

    // Universal revenue concepts — covers tech, retail, healthcare, energy, financial, SaaS, real estate
    const REV_C = [
      'Revenues','RevenueFromContractWithCustomerExcludingAssessedTax',
      'RevenueFromContractWithCustomerIncludingAssessedTax',
      'SalesRevenueNet','SalesRevenueGoodsNet','SalesRevenueServicesNet',
      'InterestAndDividendIncomeOperating','NoninterestIncome','InterestIncomeOperating',
      'OilAndGasRevenue','RealEstateRevenueNet','HealthCareOrganizationRevenue',
      'ProductRevenue','LicenseAndServicesRevenue','SubscriptionRevenue',
      'TotalRevenues','NetRevenues','RevenueNet',
    ];
    const NI_C = [
      'NetIncomeLoss','ProfitLoss',
      'NetIncomeLossAvailableToCommonStockholdersBasic',
      'NetIncomeLossAttributableToParent',
      'IncomeLossFromContinuingOperations',
    ];

    // Finnhub SEC values
    const fhRevRaw    = getRaw(secIC, ...REV_C);
    const prevRevRaw  = getRaw(prevIC, ...REV_C);
    const fhNIRaw     = getRaw(secIC, ...NI_C);
    const fhGPRaw     = getRaw(secIC, 'GrossProfit','GrossProfitLoss');
    const fhCOGSRaw   = getRaw(secIC, 'CostOfRevenue','CostOfGoodsAndServicesSold',
      'CostOfGoodsSold','CostOfGoodsAndServiceExcludingDepreciationDepletionAndAmortization');
    const fhOpIncRaw  = getRaw(secIC, 'OperatingIncomeLoss',
      'IncomeLossFromContinuingOperationsBeforeInterestExpenseInterestIncomeIncomeTaxesExtraordinaryItemsNoncontrollingInterestsNet');
    const fhPreTaxRaw = getRaw(secIC,
      'IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest',
      'IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments',
      'IncomeLossBeforeIncomeTaxExpenseBenefit','IncomeLossBeforeProvisionForIncomeTax');
    const fhDAraw     = getRaw(secCF, 'DepreciationDepletionAndAmortization',
      'DepreciationAndAmortization','Depreciation');
    const fhAssetsRaw = getRaw(secBS, 'Assets');
    const fhEquityRaw = getRaw(secBS, 'StockholdersEquity',
      'StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest',
      'PartnersCapital','MembersEquity');
    const fhLTDebtRaw = getRaw(secBS, 'LongTermDebt','LongTermDebtNoncurrent',
      'LongTermNotesPayable','SeniorNotes','LongTermLineOfCredit');
    const fhSTDebtRaw = getRaw(secBS, 'ShortTermBorrowings','DebtCurrent',
      'NotesPayableCurrent','LongTermDebtCurrent','CommercialPaper');
    const fhCurrAssetsRaw = getRaw(secBS, 'AssetsCurrent');
    const fhCurrLiabRaw   = getRaw(secBS, 'LiabilitiesCurrent');
    const fhOpCFRaw   = getRaw(secCF, 'NetCashProvidedByUsedInOperatingActivities');
    const fhCapexRaw  = getRaw(secCF,
      'PaymentsToAcquirePropertyPlantAndEquipment',
      'PaymentsForCapitalImprovements','CapitalExpendituresIncurredButNotYetPaid',
      'PaymentsToAcquireOtherPropertyPlantAndEquipment',
      'PurchaseOfPropertyAndEquipment','AdditionsToPropertyAndEquipment');

    // Use EDGAR direct when its period is newer (or when Finnhub has no data)
    const edgarNewer = edgarData && (!fhLatestPeriod || (edgarPeriod && edgarPeriod > fhLatestPeriod));
    const secRevRaw    = edgarNewer && edgarData.revenue    ? edgarData.revenue.val    : fhRevRaw;
    const secNIRaw     = edgarNewer && edgarData.netIncome  ? edgarData.netIncome.val  : fhNIRaw;
    const secGPRaw     = edgarNewer && edgarData.grossProfit ? edgarData.grossProfit.val : fhGPRaw;
    const secCOGSRaw   = edgarNewer ? null : fhCOGSRaw;
    const secOpIncRaw  = edgarNewer && edgarData.opIncome   ? edgarData.opIncome.val   : fhOpIncRaw;
    const secPreTaxRaw = fhPreTaxRaw;
    const secDAraw     = edgarNewer && edgarData.da         ? edgarData.da.val         : fhDAraw;
    const secAssetsRaw = edgarNewer && edgarData.assets     ? edgarData.assets.val     : fhAssetsRaw;
    const secEquityRaw = edgarNewer && edgarData.equity     ? edgarData.equity.val     : fhEquityRaw;
    const secLTDebtRaw = edgarNewer && edgarData.ltDebt     ? edgarData.ltDebt.val     : fhLTDebtRaw;
    const secSTDebtRaw = fhSTDebtRaw;
    const secCurrAssetsRaw = edgarNewer && edgarData.currAssets ? edgarData.currAssets.val : fhCurrAssetsRaw;
    const secCurrLiabRaw   = edgarNewer && edgarData.currLiab   ? edgarData.currLiab.val   : fhCurrLiabRaw;
    const secOpCFRaw   = edgarNewer && edgarData.opCF       ? edgarData.opCF.val       : fhOpCFRaw;
    const secCapexRaw  = edgarNewer && edgarData.capex      ? edgarData.capex.val      : fhCapexRaw;

    const sl = isIsraeli ? '' : (latestPeriod ? ` [${edgarNewer ? 'EDGAR' : 'SEC'} ${latestPeriod}]` : ' [SEC]');

    const secTotalDebtRaw = (secLTDebtRaw != null || secSTDebtRaw != null)
      ? (secLTDebtRaw ?? 0) + (secSTDebtRaw ?? 0) : null;
    const secNetMargin    = (secRevRaw && secNIRaw != null) ? (secNIRaw / secRevRaw * 100).toFixed(2) : null;
    const secGrossMargin  = secGPRaw != null && secRevRaw
      ? (secGPRaw / secRevRaw * 100).toFixed(2)
      : (secCOGSRaw != null && secRevRaw ? ((secRevRaw - secCOGSRaw) / secRevRaw * 100).toFixed(2) : null);
    const secPreTaxMargin = (secPreTaxRaw != null && secRevRaw) ? (secPreTaxRaw / secRevRaw * 100).toFixed(2) : null;
    const secOpMargin     = (!isFinancial && secOpIncRaw != null && secRevRaw) ? (secOpIncRaw / secRevRaw * 100).toFixed(2) : null;
    const secEBITDARaw    = (secOpIncRaw != null && secDAraw != null) ? secOpIncRaw + secDAraw : null;
    const secROE          = (secNIRaw != null && secEquityRaw) ? (secNIRaw / secEquityRaw * 100).toFixed(2) : null;
    const secROA          = (secNIRaw != null && secAssetsRaw) ? (secNIRaw / secAssetsRaw * 100).toFixed(2) : null;
    const secDE           = (secTotalDebtRaw != null && secEquityRaw) ? (secTotalDebtRaw / secEquityRaw).toFixed(2)
      : (secLTDebtRaw != null && secEquityRaw ? (secLTDebtRaw / secEquityRaw).toFixed(2) : null);
    const secCurrentRatio = (secCurrAssetsRaw && secCurrLiabRaw) ? (secCurrAssetsRaw / secCurrLiabRaw).toFixed(2) : null;
    const secFCFRaw       = secOpCFRaw != null
      ? (secCapexRaw != null ? secOpCFRaw - Math.abs(secCapexRaw) : secOpCFRaw)
      : null;
    const fcfNote = secOpCFRaw != null && secCapexRaw == null ? ' (תזרים תפעולי בלבד — Capex לא נמצא)' : '';
    const secRevGrowth    = (secRevRaw && prevRevRaw) ? ((secRevRaw - prevRevRaw) / Math.abs(prevRevRaw) * 100).toFixed(1) : null;

    const edgarRevHistory = edgarData?.revenueHistory ?? [];
    const edgarNIHistory  = edgarData?.netIncomeHistory ?? [];
    // Always compare quarterly vs quarterly to avoid annual vs quarterly mismatch
    const curQRev       = edgarRevHistory[0]?.val ?? null;
    const yearAgoRev    = edgarRevHistory[4]?.val ?? null;
    const curQNI        = edgarNIHistory[0]?.val  ?? null;
    const yearAgoNI     = edgarNIHistory[4]?.val  ?? null;
    const yearAgoPeriod = edgarRevHistory[4]?.period ?? null;
    const yoyRev = (curQRev && yearAgoRev) ? ((curQRev - yearAgoRev) / Math.abs(yearAgoRev) * 100).toFixed(1) : null;
    const yoyNI  = (curQNI != null && yearAgoNI != null) ? ((curQNI - yearAgoNI) / Math.abs(yearAgoNI) * 100).toFixed(1) : null;

    // Auto-detect one-time items: net margin >> pre-tax margin = likely tax benefit / non-recurring
    const oneTimeFlag = (secNetMargin != null && secPreTaxMargin != null &&
      Math.abs(+secNetMargin - +secPreTaxMargin) > 12)
      ? ` ⚠️ פער גדול מ-pre-tax (${secPreTaxMargin}%) — ייתכנו items חד-פעמיים`
      : '';

    // EPS trend from quarterly history (more reliable than YoY for transition companies)
    const epsActuals = earnings.map(e => e.actual).filter(v => v != null);
    const epsTrend = epsActuals.length >= 3
      ? (epsActuals[0] > epsActuals[epsActuals.length - 1]
          ? '📈 מגמה רבעונית עולה'
          : epsActuals[0] < epsActuals[epsActuals.length - 1]
            ? '📉 מגמה רבעונית יורדת'
            : '➡️ מגמה רבעונית יציבה')
      : '';

    const epsNorm = m['epsNormalizedAnnual'] ?? m['epsTTM'];

    // ── Pre-flight data quality validation ──
    const checks = [];
    // 1. SEC freshness (skip for Israeli stocks — SEC data not expected)
    if (isIsraeli) {
      checks.push('ℹ️ מניה ישראלית — דוחות SEC לא זמינים, נתונים מ-Finnhub בלבד');
    } else {
      checks.push(monthsOld == null ? '⚠️ תאריך דוח SEC לא ידוע'
        : monthsOld <= 4 ? `✅ דוח SEC עדכני (לפני ${monthsOld} חודשים)`
        : monthsOld <= 6 ? `⚠️ דוח SEC גבולי (${monthsOld} חודשים)`
        : `🔴 דוח SEC ישן (${monthsOld} חודשים)`);
    }
    // 2. Price in 52W range
    const hi52 = m['52WeekHigh'], lo52 = m['52WeekLow'], px = quoteData.c;
    if (hi52 && lo52 && px)
      checks.push(px >= lo52 * 0.9 && px <= hi52 * 1.1
        ? `✅ מחיר ($${px}) בטווח 52W ($${lo52}–$${hi52})`
        : `⚠️ מחיר חריג מחוץ לטווח 52W — ייתכן נתון מיושן`);
    // 3. EPS vs net income consistency
    if (epsNorm != null && secNIRaw != null)
      checks.push((+epsNorm > 0) === (secNIRaw > 0)
        ? `✅ EPS ורווח נטו SEC עקביים`
        : `⚠️ סתירה: EPS Finnhub ${+epsNorm > 0 ? 'חיובי' : 'שלילי'} אך רווח נטו SEC ${secNIRaw > 0 ? 'חיובי' : 'שלילי'}`);
    // 4. One-time items
    if (oneTimeFlag) checks.push('⚠️ זוהו items חד-פעמיים (פער נטו vs לפני-מס > 12%)');
    // 5. Data completeness
    if (isIsraeli) {
      checks.push(px != null ? '✅ מחיר ומדדי Finnhub זמינים' : '⚠️ מחיר לא זמין — בדוק את הסימבול');
    } else {
      const missing = [secRevRaw, secNIRaw, secEquityRaw, secAssetsRaw, px].filter(v => v == null).length;
      checks.push(missing === 0 ? '✅ כל המדדים הקריטיים זמינים'
        : `⚠️ ${missing} מדד/ים קריטי/ים חסר/ים`);
    }

    const warnCount = checks.filter(c => c.startsWith('⚠️') || c.startsWith('🔴')).length;
    const qualityScore = Math.max(1, 10 - warnCount * 2);
    const qualityLine = qualityScore >= 8 ? `${qualityScore}/10 ✅ נתונים אמינים`
      : qualityScore >= 6 ? `${qualityScore}/10 ⚠️ נתונים חלקית בעייתיים — ראה פירוט`
      : `${qualityScore}/10 🔴 נתונים בעייתיים — זהירות בניתוח`;

    const fmtSEC = (v, suffix, fallback) => v != null ? `${v}${suffix}${sl}` : (fallback ?? 'אין נתון');
    const fmtReport = (r) => {
      if (!r) return '';
      const ic = r.report?.ic || [];
      const cf = r.report?.cf || [];
      const bs = r.report?.bs || [];
      const period = r.endDate?.split?.(' ')?.[0] || r.period || '';
      const revenue = get(ic,
        'Revenues','RevenueFromContractWithCustomerExcludingAssessedTax',
        'SalesRevenueNet','InterestAndDividendIncomeOperating',
        'RevenueFromContractWithCustomerIncludingAssessedTax',
        'NoninterestIncome','InterestIncomeOperating');
      const netIncome = get(ic, 'NetIncomeLoss', 'ProfitLoss', 'NetIncomeLossAvailableToCommonStockholdersBasic');
      const opCF = get(cf, 'NetCashProvidedByUsedInOperatingActivities');
      return `📋 ${period} (${r.form||''})\n     הכנסות: $${revenue} | רווח נטו: $${netIncome} | תזרים תפעולי: $${opCF}`;
    };

    const fmt  = (v, suffix='') => (v != null && !isNaN(+v)) ? `${(+v).toFixed(2)}${suffix}` : 'אין נתון';
    const fmtM = (v) => (v != null && !isNaN(+v)) ? `$${(+v/1e6).toFixed(1)}M` : 'אין נתון';
    const epsHistory = earnings.length
      ? earnings.map(e => `${e.period||''}: EPS בפועל ${e.actual ?? '?'}, תחזית ${e.estimate ?? '?'}, הפתעה ${e.surprisePercent != null ? e.surprisePercent.toFixed(1)+'%' : '?'}`).join('\n   ')
      : 'אין נתון';

    // PEG: P/E ÷ EPS growth — try multiple growth rate sources
    const pe = m['peNormalizedAnnual'] ?? m['peTTM'];
    const epsG = m['epsGrowthTTMYoy'] ?? m['epsGrowth3Y'] ?? m['epsGrowth5Y'] ?? m['epsGrowthQuarterlyYoy'];
    const pegCalc = (pe != null && epsG != null && +epsG > 0) ? (+pe / +epsG).toFixed(2) : null;
    const pegVal = m['pegRatio'] ?? pegCalc;
    const pegDisplay = pegVal != null ? pegVal + (pegCalc && !m['pegRatio'] ? ' (מחושב)' : '')
      : (pe != null && epsG != null && +epsG <= 0) ? 'לא ישים (EPS growth שלילי — חברה בצמיחה לרווחיות)'
      : 'אין נתון';

    // Revenue growth — show 3 timeframes so AI can judge trend, not outlier
    // Current ratio — annual → quarterly fallback
    const currentRatio = m['currentRatioAnnual'] ?? m['currentRatioQuarterly'];

    const fmtV = (v, suffix='') => v != null ? `${v}${suffix}` : '❓';

    const metricsText = `תאריך ניתוח: ${today.toLocaleDateString('he-IL', { year:'numeric', month:'long', day:'numeric' })}
מניה: ${profileData.name || sym} (${sym}) | מחיר: ${quoteData.c ? '$'+quoteData.c : '❓'} | שינוי: ${quoteData.dp != null ? quoteData.dp.toFixed(2)+'%' : '❓'}
52W: ${fmt(m['52WeekHigh'])}–${fmt(m['52WeekLow'])} | שווי שוק: ${profileData.marketCapitalization ? '$'+(profileData.marketCapitalization/1000).toFixed(1)+'B' : '❓'} | סקטור: ${profileData.finnhubIndustry || '❓'}
מקור: ${edgarNewer ? `EDGAR ${edgarData.latestForm}${edgarFiling?.filed ? ' (הוגש '+edgarFiling.filed+')' : ''}` : 'Finnhub/SEC'} | ${stalenessWarning}

=== דוח אחרון: ${latestPeriod || '❓'} ===
הכנסות: ${secRevRaw != null ? '$'+(secRevRaw/1e6).toFixed(1)+'M' : '❓'} | רווח נטו: ${secNIRaw != null ? '$'+(secNIRaw/1e6).toFixed(1)+'M' : '❓'} | EPS: ${fmtV(epsNorm)} ${epsNorm != null ? (+epsNorm > 0 ? '✅' : '❌') : ''}
שולי גולמי: ${fmtV(secGrossMargin,'%')} | שולי תפעולי: ${fmtV(secOpMargin,'%')} | שולי נטו: ${fmtV(secNetMargin,'%')}${oneTimeFlag}
ROE: ${fmtV(secROE,'%')} | ROA: ${fmtV(secROA,'%')} | EBITDA: ${secEBITDARaw != null ? '$'+(secEBITDARaw/1e6).toFixed(1)+'M' : '❓'}
צמיחה YoY → הכנסות: ${yoyRev != null ? yoyRev+'%' : '❓'} | רווח נטו: ${yoyNI != null ? yoyNI+'%' : '❓'}

=== מכפילים (Finnhub) ===
P/E: ${fmt(m['peTTM'] ?? m['peNormalizedAnnual'])}${(+(m['peTTM'] ?? m['peNormalizedAnnual'] ?? 0) > 150) ? ' (GAAP בלבד — Non-GAAP נמוך משמעותית עקב stock-based compensation)' : ''} | P/B: ${fmt(m['pbAnnual'] ?? m['pbQuarterly'])} | PEG: ${pegDisplay} | Beta: ${fmt(m['beta'])} | דיבידנד: ${fmt(m['dividendYieldIndicatedAnnual'],'%')}

=== מאזן ===
D/E: ${fmtV(secDE)}${isFinancial ? ' (חברה פיננסית)' : ''} | Current Ratio: ${isFinancial ? 'לא רלוונטי' : fmtV(secCurrentRatio)} | FCF: ${secFCFRaw != null ? '$'+(secFCFRaw/1e6).toFixed(1)+'M' : '❓'}${fcfNote}

=== EPS רבעוני ===
${epsHistory}
${edgarData?.latest8K ? `
=== הכרזת רווחים (8-K ${edgarData.latest8K.filed}) ===
${edgarData.latest8K.text.slice(0, 1500)}` : ''}`.trim();

    const systemPrompt = `אתה יועץ השקעות מקצועי המנתח מניות לפי מסגרת הספר "המעבדה" (פרקים 8–12). נתח את המניה לפי הנתונים בלבד — אסור להשתמש בידע מהאימון. נתון חסר = ❓.
אם קיים קטע "הכרזת רווחים (8-K)" — זה המקור הכי עדכני, תעדיף אותו.
אם הדוח ישן מ-5 חודשים — ציין זאת.

=== מחזור חיי המניה (איור 9 מהספר) ===
חלום → צמיחה → ערך → דועכת
מניות עוברות בין קטגוריות לאורך זמן. סווג לפי המצב הנוכחי בלבד.

=== פרק 8: מניות כחולות — ערך (Value Stocks) ===
חברות ותיקות עם יציבות פיננסית שהשוק מתמחר בחסר.
קריטריונים לזיהוי:
• P/E נמוך ביחס לממוצע שוק ולמתחרים בענף
• P/B < 1 — השוק מתמחר מתחת לערך הפנקסני (נכסים נטו)
• תשואת דיבידנד 2%–5% | Payout Ratio 40%–60% (לא גבוה מדי = יציבות)
• Earnings Yield גבוה — רווח/מחיר גבוה ביחס לממוצע שוק
• שולי רווח (גולמי + תפעולי + נטו) יציבים או גבוהים לאורך שנים
• ROE 15%–20%+ עקבי לאורך זמן רב
• D/E < 1 (עדיף < 0.5) — חוב נמוך, יכולת החזר
• FCF חיובי, יציב וגבוה — מממן דיבידנד ורכישות עצמיות
• צמיחת EPS עקבית (לאו דווקא מהירה — חשוב שתהיה יציבה 5–10 שנים)
• צמיחת הכנסות עקבית — סימן לביקוש יציב
• Forward Growth פוטנציאלי — לא חייב גבוה, אבל לא שלילי
• מודל עסקי בוגר ומוכח, תעשייה בשלה (פיננסים, אנרגיה, תשתיות, תרופות ותיקות)
סכנות: "מלכודת ערך" — P/E נמוך עם FCF שלילי וירידת הכנסות = מניה דועכת שנראית זולה

=== פרק 9: מניות ירוקות — צמיחה (Growth Stocks) ===
חברות שצומחות בקצב גבוה מהממוצע, לרוב בתחומים חדשים.
קריטריונים לזיהוי:
• צמיחת הכנסות דו-ספרתית (20%+) לפחות 3–5 שנים רצופות — מדד מרכזי
• EPS צומח 20%+ YoY עקבי — בחברות צמיחה EPS צריך לגדול יותר מהירה מהיציבות
• P/E גבוה אבל מוצדק — משקיעים משלמים פרמיה על צמיחה עתידית
• PEG < 1 — הצמיחה מצדיקה את המכפיל (P/E חלקי שיעור הצמיחה)
• ROE 20%+ עולה לאורך זמן
• ROA גבוה ויציב — ניהול יעיל של הנכסים
• שולי גולמי גבוהים מהענף + עולים — Gross Profit Margin
• Operating Margin גבוה — חברות צמיחה שומרות על רווחיות תפעולית גבוהה
• D/E נמוך — חברות צמיחה בריאות מממנות עצמן מהון עצמי לא מחוב
• R&D גבוה — השקעה במחקר ופיתוח לטכנולוגיות חדשות
• Earnings Growth Rate 15%–20%+ לשנה
• מודל עסקי סקיילבילי (SaaS / פלטפורמה / e-commerce / פינטק)
• חדשנות ותחומים חדשים — AI, ביוטכנולוגיה, בינה מלאכותית, אנרגיה ירוקה
• יתרון תחרותי (Moat) — פטנטים, network effect, עלויות מעבר גבוהות

=== פרק 10: מניות אדומות — דועכות (Declining Stocks) ===
חברות שמתקשות לצמוח או לשמור על רווחיות. להימנע.
סימני אזהרה מרכזיים:
• ירידה עקבית בהכנסות וברווחיות — 2+ רבעונים (מדד קריטי ראשון)
• D/E > 1.0 + FCF שלילי — מדד קריטי שני: חוב גבוה ויצירת מזומן שלילית
• תחרות גוברת ואובדן נתח שוק — לא מצליחה להרחיב או לשמור על שוק קיים (Market Share יורד)
• ירידה בכמות / באיכות המוצרים — לא מצליחה לחדש
• בעיות ניהוליות ושינויי הנהלה — תחלופה גבוהה של מנכ"לים ובכירים
• הפסדים מתמשכים + ביקורות שליליות חוזרות של אנליסטים (Downgrades)
• שולי רווח מצטמצמים באופן עקבי — גולמי, תפעולי
• ROE שלילי או יורד — ניהול לא יעיל של ההון
• שוק מלאכותי/בועה — P/E גבוה מהממוצע ללא צמיחה אמיתית
• הסתמכות על מוצר אחד ולא מצליחה לגוון
🚨 מדד קריטי: FCF שלילי + D/E > 1.0 = סיכון פשיטת רגל

=== פרק 11: מניות צהובות — חלום (Dream/Speculative Stocks) ===
חברות חלום — סיכון גבוה מאוד, פוטנציאל תשואה יוצאת דופן.
אלו לא מניות להחזקה רגילה — סיכון גבוה כרוכה בהן.
מאפייני סיכון (שצריך לזהות):
• P/E לא רציונלי / גבוה מאוד (הרבה מעל ממוצע ענף) / ללא רווחים כלל
• חוסר יציבות פיננסית — D/E גבוה, Current Ratio נמוך, תלות בגיוסי הון
• מודל עסקי לא מוכח — חברה בשלב מוקדם, רעיון לא הוכח בשוק
• תלות במוצר/טכנולוגיה אחת — כל כישלון יפגע משמעותית
• צמיחה שאינה בת-קיימא — לא יציבה, לא עקבית
• מימון חיצוני — קרנות הון-סיכון, גיוסי הון תכופים
• תחרות חזקה / אי-יכולת לבדל
• ניהול לא מוכח — צוות צעיר, חסר ניסיון
• תנודתיות גבוהה — שוק קטן/לא מבוסס
מדדים חיוביים שמצדיקים סיווג כחלום (ולא אדום):
• צמיחת הכנסות 20%+ (גם אם עדיין לא רווחית)
• Forward Growth Estimates גבוהות מאוד (אנליסטים צופים צמיחה חדה)
• ROE גבוה (20%+) אם קיים
• השקעת R&D גבוהה — חברה משקיעה בעתיד
• גיבוי VC / קרנות גדולות — אנשי מקצוע שעשו Due Diligence
• תחום עם תנודתיות גבוהה מאוד: AI, ביוטכנולוגיה, גנטיקה, אנרגיה מתחדשת, רובוטיקה, פינטק
• שוק פוטנציאלי (TAM) גדול מאוד

=== כללי סימון חובה — אל תסטה מהם ===
✅ = הקריטריון מתקיים במלואו לפי הסף המוגדר
⚠️ = מתקיים חלקית / גבולי
❌ = לא מתקיים — חולשה ברורה
❓ = נתון חסר לחלוטין

ספי חובה — רק אם הנתון עומד בסף יקבל ✅. אסור לסמן ✅ על נתון חלש גם אם "החברה בשלב צמיחה":
• צמיחת הכנסות: ✅ 20%+ (ירוקות/חלום) | ✅ יציבה חיובית (כחולות) | ⚠️ 10%-20% | ❌ מתחת ל-10% או שלילי
• ROE: ✅ 20%+ (ירוקות) / 15%+ (כחולות) | ⚠️ 10%-15% | ❌ מתחת ל-10%
• ROA: ✅ גבוה ויציב | ⚠️ בינוני | ❌ נמוך/יורד
• שולי תפעולי: ✅ חיובי ועולה | ⚠️ חיובי אך נמוך | ❌ שלילי
• D/E: ✅ מתחת ל-0.5 | ⚠️ 0.5–1.0 | ❌ מעל 1.0
• FCF: ✅ חיובי וגבוה | ⚠️ חיובי אך נמוך | ❌ שלילי
• PEG: ✅ מתחת ל-1 | ⚠️ 1–2 | ❌ מעל 2
• דיבידנד (כחולות בלבד): ✅ 2%-5% יציב | ⚠️ קיים אך מחוץ לטווח | ❌ אין

=== פורמט הניתוח (חובה לדייק) ===

=== סיווג ===
[🔵/🟢/🟡/🔴] **[שם הקטגוריה]** — [נימוק קצר מהנתונים בלבד]

=== ניתוח קריטריונים ===
✅/⚠️/❌/❓ **צמיחת הכנסות YoY**: [ערך%] — [האם עקבית? כמה שנים?]
✅/⚠️/❌/❓ **רווחיות**: גולמי [X]% | תפעולי [X]% | נטו [X]% — [מגמה?]
✅/⚠️/❌/❓ **EPS**: [ערך] | צמיחה YoY: [%]
✅/⚠️/❌/❓ **ROE**: [X]% | **ROA**: [X]% — [ציין אם מתחת לסף]
✅/⚠️/❌/❓ **FCF**: [ערך] — [חיובי/שלילי/גדל?]
✅/⚠️/❌/❓ **מינוף D/E**: [ערך] | **Current Ratio**: [ערך]
✅/⚠️/❌/❓ **P/E**: [ערך] | **P/B**: [ערך] | **PEG**: [ערך] | **Beta**: [ערך]
✅/⚠️/❌/❓ **דיבידנד**: [%] | **Payout Ratio**: [%]

=== מיקום במחזור החיים ===
[איפה המניה נמצאת על ציר חלום→צמיחה→ערך→דעיכה ולמה]

=== בדיקה עצמית ===
[האם הסיווג עולה בקנה אחד עם כל הנתונים? אם יש סתירה — ציין אותה]

=== ציון ===
**[X]/10** — [נימוק קצר]

=== המלצה ===
[קנייה / המתנה / הימנע] — [נימוק מהנתונים]

=== הקשר שוק ===
[2-3 משפטים: סיכון ענפי, מחזוריות, רגולציה — מה המספרים לא אומרים לבד]

=== מבט קדימה — לאן החברה הולכת? ===
נתח באופן אובייקטיבי בלבד לפי הנתונים הזמינים:
• **מגמת הכנסות**: עולה / יציבה / יורדת — האם המגמה מתחזקת או מתמתנת?
• **מגמת רווחיות**: שולי הרווח משתפרים / נשחקים / יציבים?
• **חוסן פיננסי**: האם המאזן מתחזק (פחות חוב, יותר FCF) או נחלש?
• **כיוון כללי**: [משתפרת / יציבה / מדשדשת / דועכת] — נימוק קצר מהנתונים בלבד
אל תנחש, אל תסתמך על ידע חיצוני — רק מה שהנתונים מראים.

🚨 אם 🔴 — התרע בבירור בראש הניתוח לפני כל השאר.`;

    dataPre.textContent = metricsText;
    out.innerHTML = '<span style="color:var(--text3)">מנתח עם AI...</span>';

    const groqBody = JSON.stringify({
      model: 'llama-3.3-70b-versatile',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: metricsText },
      ],
      stream: true,
      max_tokens: 2000,
      temperature: 0.2,
    });
    const invKey = _getInvGroqKey();
    const groqBodyWithKey = invKey
      ? JSON.stringify({ ...JSON.parse(groqBody), _inv_key: invKey })
      : groqBody;
    let resp = await fetch(`${SUPABASE_URL}/functions/v1/groq`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: groqBodyWithKey,
    });
    if (resp.status === 429) {
      let errMsg = '';
      try { const j = await resp.clone().json(); const e = j.error; const raw = typeof e === 'string' ? e : (typeof e?.message === 'string' ? e.message : JSON.stringify(j)); errMsg = String(raw); } catch { errMsg = await resp.text(); }
      if (errMsg.includes('Rate limit exceeded')) {
        out.textContent = '⛔ הגעת למגבלת הבקשות שלנו (10/דקה). הוסף Groq API key ייעודי או המתן דקה.';
      } else {
        out.textContent = `⛔ Groq 429: ${errMsg.slice(0, 200)}`;
      }
      return;
    }
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);

    dataPre.textContent = metricsText;
    out.innerHTML = '';
    const reader = resp.body.getReader();
    const dec = new TextDecoder();
    let buf = '', rawText = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        if (!line.startsWith('data: ') || line === 'data: [DONE]') continue;
        try {
          const chunk = JSON.parse(line.slice(6));
          const delta = chunk.choices?.[0]?.delta?.content || '';
          rawText += delta;
          out.textContent = rawText;
          out.scrollTop = out.scrollHeight;
        } catch { /* skip */ }
      }
    }
    // Post-process: convert === headers, **bold**, status icons to HTML
    out.innerHTML = formatInvOutput(rawText);
  } catch (e) {
    out.innerHTML = '<span class="inv-bad">שגיאה: ' + (e.message || 'נסה שוב') + '</span>';
  } finally {
    btn.disabled = false;
    btn.textContent = '▶ נתח מניה';
  }
}

// ─────────────────────────────────────────────
// THEME TRACKER
// ─────────────────────────────────────────────
let _ttData = null, _ttIndices = null, _ttPeriod = 'today', _ttLoading = false, _ttTimer = null;

function ttSetPeriod(p, btn) {
  _ttPeriod = p;
  document.querySelectorAll('.tt-period').forEach(b => b.classList.toggle('active', b.dataset.p === p));
  if (_ttData) ttRender(_ttData, _ttIndices);
  if (_sectorTicker) {
    if (_sectorCache[_sectorTicker]) _renderHoldingsForPeriod(_sectorCache[_sectorTicker], p);
    else _fetchAndRender(_sectorTicker, false);
  }
}

function ttStartTimer() {
  ttStopTimer();
  _ttTimer = setInterval(() => ttLoad(true), 60000);
}

function ttScheduleMidnight() {
  const now = new Date();
  const next = new Date(now);
  next.setHours(24, 0, 30, 0); // 00:00:30 Israel time next day
  const ms = next - now;
  setTimeout(() => {
    _ttData = null; // force fresh fetch
    if (document.getElementById('tab-themes')?.classList.contains('active')) ttLoad(true);
    ttScheduleMidnight(); // reschedule for next day
  }, ms);
}

function ttStopTimer() {
  if (_ttTimer) { clearInterval(_ttTimer); _ttTimer = null; }
}

async function ttLoad(force = false) {
  if (_ttLoading) return;
  if (_ttData && !force) { ttRender(_ttData, _ttIndices); return; }
  _ttLoading = true;
  const silent = !!_ttData;
  if (!silent) {
    document.getElementById('tt-grid').innerHTML = '<div class="tt-loading">Loading...</div>';
    const _idxEl = document.getElementById('tt-indices');
    if (_idxEl) _idxEl.innerHTML = '';
    const _metaEl = document.getElementById('tt-meta');
    if (_metaEl) _metaEl.innerHTML = '';
  }
  try {
    const _ttToken = await _getToken();
    const res = await fetch(
      `${SUPABASE_URL}/functions/v1/theme-tracker`,
      { headers: { 'Authorization': `Bearer ${_ttToken}` } }
    );
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const json = await res.json();
    _ttData = json.themes;
    _ttIndices = json.indices || [];
    const ts = new Date(json.ts);
    const el = document.getElementById('tt-updated');
    if (el) el.textContent = 'עודכן: ' + ts.toLocaleTimeString('he-IL', { hour:'2-digit', minute:'2-digit' });
    ttRender(_ttData, _ttIndices);
  } catch(e) {
    if (!silent) document.getElementById('tt-grid').innerHTML = '<div class="tt-loading">שגיאה בטעינת נתונים — נסה שוב</div>';
  } finally {
    _ttLoading = false;
  }
}

function ttRender(themes, indices) {
  const grid = document.getElementById('tt-grid');
  if (!grid) return;
  const pKey = _ttPeriod;

  // ── Indices bar ──
  const indicesEl = document.getElementById('tt-indices');
  if (indicesEl && indices?.length) {
    indicesEl.innerHTML = indices.map(idx => {
      const pct = idx.today;
      const cls = pct == null ? 'flat' : pct > 0 ? 'pos' : pct < 0 ? 'neg' : 'flat';
      const sign = pct != null && pct > 0 ? '+' : '';
      const display = pct != null ? sign + pct.toFixed(2) + '%' : '—';
      return `<div class="tt-index-card">
        <div class="tt-index-name">${esc(idx.name)}</div>
        <div class="tt-index-pct ${cls}">${display}</div>
        <div class="tt-index-ticker">${esc(idx.ticker)}</div>
      </div>`;
    }).join('');
  }

  // ── Theme list ──
  const valid = themes.filter(t => t[pKey] != null);
  const sorted = [...valid].sort((a, b) => b[pKey] - a[pKey]);
  if (!sorted.length) { grid.innerHTML = '<div class="tt-loading">אין נתונים לתקופה זו</div>'; return; }

  // ── Sentiment Score (overview widget only) ──
  {
    const green = sorted.filter(t => t[pKey] >= 0).length;
    const total = sorted.length;
    const breadthScore = (green / total) * 100;
    const avgPct = sorted.reduce((s, t) => s + t[pKey], 0) / total;
    const momentumScore = Math.min(Math.max((avgPct + 5) / 10 * 100, 0), 100);
    const score = Math.round(breadthScore * 0.5 + momentumScore * 0.5);
    const [label, color] = score >= 80 ? ['Extreme Greed', '#2dd4a0']
      : score >= 60 ? ['Greed', '#84cc16']
      : score >= 40 ? ['Neutral', '#94a3b8']
      : score >= 20 ? ['Fear', '#f97316']
      : ['Extreme Fear', '#ff6b8a'];
    ttRenderPulseWidget(score, label, color);
  }

  // ── Meta: Top3/Bottom3 + Breadth ──
  const metaEl = document.getElementById('tt-meta');
  if (metaEl) {
    const _ttN = window.innerWidth <= 768 ? 3 : 5;
    const top3 = sorted.slice(0, _ttN);
    const bot3 = sorted.slice(-_ttN).reverse();
    const green = sorted.filter(t => t[pKey] >= 0).length;
    const red   = sorted.filter(t => t[pKey] <  0).length;
    const total = sorted.length;
    const greenPct = Math.round((green / total) * 100);
    const redPct   = 100 - greenPct;

    const podiumRow = t => {
      const pct = t[pKey];
      const pos = pct >= 0;
      const sign = pos ? '+' : '';
      return `<div class="tt-podium-row">
        <span class="tt-podium-name">${esc(t.name)}</span>
        <span class="tt-podium-pct ${pos?'pos':'neg'}">${sign}${pct.toFixed(2)}%</span>
      </div>`;
    };

    metaEl.innerHTML = `
      <div class="tt-meta-card">
        <div class="tt-meta-title">Top ${_ttN} &nbsp;·&nbsp; Bottom ${_ttN}</div>
        <div class="tt-podium">${top3.map(podiumRow).join('')}</div>
        <div style="height:8px"></div>
        <div class="tt-podium">${bot3.map(podiumRow).join('')}</div>
      </div>
      <div class="tt-meta-card">
        <div class="tt-meta-title">Market Breadth</div>
        <div class="tt-breadth-bar-wrap" style="background:linear-gradient(to right,#2dd4a0 ${greenPct}%,#ff6b8a ${greenPct}%)"></div>
        <div class="tt-breadth-labels">
          <span class="tt-breadth-red">▼ ${red} <span style="opacity:0.7">(${redPct}%)</span></span>
          <span class="tt-breadth-neutral">${total} themes</span>
          <span class="tt-breadth-green">▲ ${green} <span style="opacity:0.7">(${greenPct}%)</span></span>
        </div>
        <div class="tt-breadth-chips" id="tt-breadth-chips-inner"></div>
      </div>`;
    const chipsEl = document.getElementById('tt-breadth-chips-inner');
    if (chipsEl) {
      const greens = sorted.filter(t => t[pKey] > 0).slice(0, 7);
      const reds   = sorted.filter(t => t[pKey] < 0).slice(-7).reverse();
      const rows = Math.max(greens.length, reds.length);
      let chipsHtml = '';
      for (let i = 0; i < rows; i++) {
        const g = greens[i], r = reds[i];
        chipsHtml += r
          ? `<div class="tt-chip red" style="cursor:pointer" onclick="sectorModalOpen('${esc(r.ticker)}','${esc(r.name)}')"><span>${esc(r.name)}</span><span>${r[pKey].toFixed(1)}%</span></div>`
          : '<div></div>';
        chipsHtml += g
          ? `<div class="tt-chip green" style="cursor:pointer" onclick="sectorModalOpen('${esc(g.ticker)}','${esc(g.name)}')"><span>${esc(g.name)}</span><span>+${g[pKey].toFixed(1)}%</span></div>`
          : '<div></div>';
      }
      chipsEl.innerHTML = chipsHtml;
    }
  }

  const maxAbs = Math.max(...sorted.map(t => Math.abs(t[pKey])), 0.01);
  const renderRow = t => {
    const pct = t[pKey];
    const pos = pct >= 0;
    const barW = Math.min((Math.abs(pct) / maxAbs) * 48, 48);
    const sign = pos ? '+' : '';
    return `<div class="tt-row" onclick="sectorModalOpen('${esc(t.ticker)}','${esc(t.name)}')">
      <div class="tt-name">${esc(t.name)}</div>
      <div class="tt-bar-wrap">
        <div class="tt-bar-bg"></div>
        <div class="tt-bar ${pos?'pos':'neg'}" style="width:${barW}%"></div>
      </div>
      <div class="tt-pct ${pos?'pos':'neg'}">${sign}${pct.toFixed(2)}%</div>
    </div>`;
  };
  const half = Math.ceil(sorted.length / 2);
  grid.innerHTML = `<div class="tt-col">${sorted.slice(half).map(renderRow).join('')}</div>`
                 + `<div class="tt-col">${sorted.slice(0, half).map(renderRow).join('')}</div>`;
}

function ttRenderPulseWidget(score, label, color) {
  const el = document.getElementById('ov-pulse-widget');
  if (!el) return;
  const R = 33, C = 40, FULL = 2 * Math.PI * R;
  const dash = (score / 100) * FULL;
  el.innerHTML = `
    <div class="fg-gauge-wrap">
      <svg width="80" height="80" viewBox="0 0 80 80">
        <circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="6"/>
        <circle cx="${C}" cy="${C}" r="${R}" fill="none" stroke="${color}" stroke-width="6"
          stroke-dasharray="${dash} ${FULL}" stroke-linecap="round"
          style="filter:drop-shadow(0 0 6px ${color}80)"/>
      </svg>
      <div class="fg-gauge-text">
        <span class="fg-score" style="color:${color}">${score}</span>
        <span class="fg-score-sub">/100</span>
      </div>
    </div>
    <div class="fg-info">
      <div class="fg-label">Market Pulse</div>
      <div class="fg-rating" style="color:${color}">${label}</div>
      <div class="fg-source">Themes · ${new Date().toLocaleDateString('en-US',{month:'short',day:'numeric'})}</div>
    </div>`;
}

// ─────────────────────────────────────────────
// ─────────────────────────────────────────────
// SECTOR HOLDINGS MODAL
// ─────────────────────────────────────────────
let _sectorTimer = null, _sectorTicker = null;

function _renderHoldingsForPeriod(allHoldings, period) {
  const body = document.getElementById('sector-modal-body');
  if (!body) return;
  const key = period || 'today';
  const sorted = allHoldings
    .filter(h => h[key] != null)
    .sort((a, b) => b[key] - a[key])
    .slice(0, 10);
  if (!sorted.length) { body.innerHTML = '<div class="sector-modal-loading">אין נתונים לתקופה זו</div>'; return; }
  body.innerHTML = sorted.map(h => {
    const pct = h[key];
    const pos = pct > 0, neg = pct < 0;
    const cls = pos ? 'pos' : neg ? 'neg' : '';
    const sign = pos ? '+' : '';
    return '<div class="sector-holding-row">'
      + '<span class="sector-holding-sym">' + esc(h.symbol) + '</span>'
      + '<span class="sector-holding-name">' + esc(h.name) + '</span>'
      + '<span class="sector-holding-pct ' + cls + '">' + sign + pct.toFixed(2) + '%</span>'
      + '</div>';
  }).join('');
}

async function _fetchAndRender(ticker, showLoading) {
  const body = document.getElementById('sector-modal-body');
  if (!body) return;
  if (showLoading) body.innerHTML = '<div class="sector-modal-loading">Loading...</div>';
  try {
    const _shToken = await _getToken();
    const res = await fetch(
      `${SUPABASE_URL}/functions/v1/sector-holdings?ticker=${encodeURIComponent(ticker)}`,
      { headers: { 'Authorization': `Bearer ${_shToken}` } }
    );
    const json = await res.json();
    if (json.error) { body.innerHTML = `<div class="sector-modal-loading">${json.error}</div>`; return; }
    if (!json.holdings?.length) { body.innerHTML = '<div class="sector-modal-loading">No holdings data</div>'; return; }
    _sectorCache[ticker] = json.holdings;
    _sectorSaveLS(ticker, json.holdings);
    _renderHoldingsForPeriod(json.holdings, _ttPeriod);
    const sub = document.getElementById('sector-modal-sub');
    if (sub) sub.textContent = ticker + ' — updated ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch {
    if (showLoading) body.innerHTML = '<div class="sector-modal-loading">Error loading data</div>';
  }
}

async function sectorModalOpen(ticker, name) {
  const overlay = document.getElementById('sector-modal-overlay');
  const modal   = document.getElementById('sector-modal');
  const title   = document.getElementById('sector-modal-title');
  if (!modal) return;

  _sectorTicker = ticker;
  title.textContent = name;
  overlay.style.display = 'block';
  modal.style.display   = 'block';

  clearInterval(_sectorTimer);
  // Stale-while-revalidate: show any cached data (memory → localStorage)
  // instantly, then refresh in the background. Only show a spinner on a true
  // first open with nothing cached.
  const lsHit = !_sectorCache[ticker] && _sectorLoadLS()[ticker];
  if (lsHit?.holdings?.length) _sectorCache[ticker] = lsHit.holdings;
  if (_sectorCache[ticker]) {
    _renderHoldingsForPeriod(_sectorCache[ticker], _ttPeriod);
    _fetchAndRender(ticker, false); // refresh in background, no spinner
  } else {
    await _fetchAndRender(ticker, true);
  }
  _sectorTimer = setInterval(() => _fetchAndRender(_sectorTicker, false), 60000);
}

function sectorModalClose() {
  clearInterval(_sectorTimer);
  _sectorTimer = null;
  _sectorTicker = null;
  document.getElementById('sector-modal-overlay').style.display = 'none';
  document.getElementById('sector-modal').style.display = 'none';
}

// BROKER CSV IMPORT
// ─────────────────────────────────────────────
const BROKER_DEFS = {
  colmex: {
    name: 'Colmex Pro',
    cols: {
      symbol:     ['Symbol','Ticker','Instrument','Description','Sym'],
      side:       ['Side','Direction','Action','Type','Buy/Sell','B/S'],
      shares:     ['Quantity','Qty','Volume','Size','Amount','Shares'],
      entryPrice: ['Open Price','Entry Price','Price','Open','Bought'],
      exitPrice:  ['Close Price','Exit Price','Close','Sold'],
      entryDate:  ['Date/Time','DateTime','Open Date','Date','Time','Open Time','Trade Date'],
      commission: ['Execution fee','Commission','Fee','Fees','Commissions','Exec Fee'],
      pnl:        ['Net P/L','Net PL','NetPL','P/L','PnL','Profit','Gross P/L','Net Profit'],
    },
    sideMap: { 'buy':'L','long':'L','b':'L','l':'L','sell':'S','short':'S','s':'S' },
  }
};

let _biRows = null, _biMapping = null, _biTrades = null;

function brokerLoadFile(input) {
  const file = (input.files || input)[0];
  if (!file) return;
  const broker = document.getElementById('bi-broker').value;
  if (!broker) { toast('בחר ברוקר תחילה', true); return; }
  const reader = new FileReader();
  reader.onload = e => {
    try {
      _biRows = biParseCSV(e.target.result);
      if (!_biRows.length) { toast('לא נמצאו שורות בקובץ', true); return; }
      const def = BROKER_DEFS[broker];
      _biMapping = biDetectCols(Object.keys(_biRows[0]), def.cols);
      biShowMapping(_biMapping, Object.keys(_biRows[0]));
    } catch(err) { toast('שגיאה בקריאת הקובץ', true); }
  };
  reader.readAsText(file, 'UTF-8');
}

function biParseCSV(text) {
  const lines = text.trim().split(/\r?\n/);
  if (lines.length < 2) return [];
  const headers = biSplitLine(lines[0]);
  return lines.slice(1).filter(l => l.trim()).map(line => {
    const vals = biSplitLine(line);
    const obj = {};
    headers.forEach((h, i) => { obj[h.trim()] = (vals[i] || '').trim(); });
    return obj;
  });
}

function biSplitLine(line) {
  const r = []; let cur = '', q = false;
  for (const c of line) {
    if (c === '"') q = !q;
    else if (c === ',' && !q) { r.push(cur); cur = ''; }
    else cur += c;
  }
  r.push(cur);
  return r;
}

function biDetectCols(headers, colDefs) {
  const map = {};
  for (const [field, candidates] of Object.entries(colDefs)) {
    for (const c of candidates) {
      const found = headers.find(h => h.toLowerCase().trim() === c.toLowerCase().trim());
      if (found) { map[field] = found; break; }
    }
  }
  return map;
}

function biShowMapping(mapping, headers) {
  const labels = {
    symbol:'סימבול *', side:'כיוון (L/S) *', shares:'כמות *',
    entryPrice:'מחיר כניסה *', exitPrice:'מחיר יציאה',
    entryDate:'תאריך *', commission:'עמלה', pnl:'P&L'
  };
  let h = `<div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border);">
    <div style="font-size:11px;color:var(--text3);margin-bottom:8px;">מיפוי עמודות (ניתן לשנות):</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;">`;
  for (const [field, label] of Object.entries(labels)) {
    const sel = mapping[field] || '';
    h += `<div>
      <div class="ibkr-field-label">${label}</div>
      <select class="form-control" style="font-size:12px;padding:4px 8px;"
        onchange="_biMapping['${field}']=this.value">
        <option value="">— לא ממופה —</option>
        ${headers.map(hd => `<option value="${esc(hd)}"${hd===sel?' selected':''}>${esc(hd)}</option>`).join('')}
      </select>
    </div>`;
  }
  h += `</div><button class="btn btn-secondary btn-sm" onclick="biPreview()">👁 תצוגה מקדימה</button></div>`;
  const el = document.getElementById('bi-mapping');
  el.innerHTML = h; el.style.display = 'block';
  document.getElementById('bi-preview').style.display = 'none';
  document.getElementById('bi-import-btn').style.display = 'none';
}

function biPreview() {
  const broker = document.getElementById('bi-broker').value;
  const def = BROKER_DEFS[broker];
  _biTrades = biParseRows(_biRows, _biMapping, def);
  if (!_biTrades.length) { toast('לא זוהו עסקאות — בדוק מיפוי עמודות', true); return; }
  const show = _biTrades.slice(0, 5);
  let h = `<div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border);">
    <div style="font-size:11px;color:var(--text3);margin-bottom:8px;">
      ${_biTrades.length} עסקאות זוהו — מוצגות 5 ראשונות:
    </div>
    <div class="table-wrap" style="margin-bottom:12px;max-height:220px;overflow-y:auto;">
    <table><thead><tr><th>סימבול</th><th>כיוון</th><th>תאריך</th><th>כניסה</th><th>יציאה</th><th>כמות</th><th>עמלה</th></tr></thead><tbody>`;
  for (const t of show) {
    h += `<tr class="data-row">
      <td><strong>${esc(t.symbol)}</strong></td>
      <td><span class="badge badge-${t.ls}">${t.ls}</span></td>
      <td>${fmtDate(t.entryDate)}</td>
      <td>$${fmtPrice(t.entryPrice)}</td>
      <td>${t.exitPrice ? '$'+fmtPrice(t.exitPrice) : '—'}</td>
      <td>${t.shares}</td>
      <td>$${fmt(t.commission||0)}</td>
    </tr>`;
  }
  h += `</tbody></table></div>
    <div style="display:flex;align-items:center;gap:10px;">
      <div class="ibkr-field-label" style="margin:0;">סוג נכס:</div>
      <select id="bi-asset-type" class="form-control" style="font-size:12px;padding:4px 8px;width:130px;">
        <option value="stock">מניות</option>
        <option value="crypto">קריפטו</option>
      </select>
    </div>
  </div>`;
  const el = document.getElementById('bi-preview');
  el.innerHTML = h; el.style.display = 'block';
  document.getElementById('bi-import-btn').style.display = 'inline-flex';
}

function biParseRows(rows, mapping, def) {
  const trades = [];
  for (const row of rows) {
    try {
      const symbol = (row[mapping.symbol] || '').trim().toUpperCase().replace(/\s+/g,'');
      if (!symbol) continue;
      const sideRaw = (row[mapping.side] || '').trim().toLowerCase();
      const ls = def.sideMap[sideRaw] || (sideRaw.startsWith('b') || sideRaw.startsWith('l') ? 'L' : 'S');
      const shares = parseFloat(row[mapping.shares]) || 0;
      if (shares <= 0) continue;
      let entryPrice = parseFloat(row[mapping.entryPrice]) || 0;
      const rawDate = (row[mapping.entryDate] || '').trim();
      const entryDate = biParseDate(rawDate);
      if (!entryDate) continue;
      let exitPrice = mapping.exitPrice ? (parseFloat(row[mapping.exitPrice]) || 0) : 0;
      const commission = mapping.commission ? (parseFloat(row[mapping.commission]) || 0) : 0;
      const pnl = mapping.pnl ? (parseFloat(row[mapping.pnl]) || 0) : 0;
      // Colmex "Bought"/"Sold" may be total values — detect and convert to price
      if (entryPrice > shares * 1000 && shares > 0) entryPrice = entryPrice / shares;
      if (exitPrice > shares * 1000 && shares > 0) exitPrice = exitPrice / shares;
      // Back-calc exit price from P/L if missing
      if (!exitPrice && pnl && entryPrice && shares) {
        const dir = ls === 'L' ? 1 : -1;
        exitPrice = entryPrice + (pnl + commission) / shares * dir;
        if (exitPrice < 0) exitPrice = 0;
      }
      trades.push({ symbol, ls, entryDate, entryPrice, exitPrice: exitPrice > 0 ? exitPrice : null, shares, commission });
    } catch(e) { /* skip bad row */ }
  }
  return trades;
}

function biParseDate(raw) {
  if (!raw) return null;
  // YYYY-MM-DD or YYYY/MM/DD
  let m = raw.match(/^(\d{4})[-\/\.](\d{1,2})[-\/\.](\d{1,2})/);
  if (m) return `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;
  // DD/MM/YYYY or MM/DD/YYYY
  m = raw.match(/^(\d{1,2})[-\/\.](\d{1,2})[-\/\.](\d{4})/);
  if (m) {
    const d1 = +m[1], d2 = +m[2];
    if (d1 > 12) return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
    return `${m[3]}-${m[1].padStart(2,'0')}-${m[2].padStart(2,'0')}`;
  }
  return null;
}

async function brokerImport() {
  if (!_biTrades?.length) return;
  const type = document.getElementById('bi-asset-type').value;
  const btn = document.getElementById('bi-import-btn');
  btn.disabled = true; btn.textContent = 'מייבא...';
  let added = 0, skipped = 0, dupes = 0;
  for (const t of _biTrades) {
    t.type = type;
    const fp = `${t.symbol}||${t.entryDate}||${Math.round((t.entryPrice||0)*1000)}||${Math.round((t.shares||0)*1000)}`;
    if (db._deletedFingerprints?.has(fp)) { dupes++; continue; }
    const existing = (type==='stock'?db.stocks:db.crypto).find(x =>
      x.symbol===t.symbol && x.entryDate===t.entryDate &&
      Math.abs((x.entryPrice||0)-(t.entryPrice||0)) < 0.001 &&
      Math.abs((x.shares||0)-(t.shares||0)) < 0.001);
    if (existing) { dupes++; continue; }
    try {
      const row = _tradeToRow(t);
      const { data, error } = await _sb.from('trades').insert(row).select().single();
      if (error) { skipped++; continue; }
      const trade = _rowToTrade(data);
      (type==='stock' ? db.stocks : db.crypto).push(trade);
      added++;
    } catch(e) { skipped++; }
  }
  btn.disabled = false; btn.textContent = 'ייבא עסקאות';
  toast(`ייבוא הסתיים: ${added} נוספו${dupes?' | '+dupes+' כפולות':''}${skipped?' | '+skipped+' שגיאות':''}`);
  if (added) { renderTable(type); renderOverview(); }
  _biTrades = null;
  document.getElementById('bi-preview').style.display = 'none';
  document.getElementById('bi-import-btn').style.display = 'none';
}

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}

// ─────────────────────────────────────────────
// ADVANCED STATS CHARTS — Drawdown + R Distribution
// ─────────────────────────────────────────────
function renderDrawdownChart(labels, series) {
  const el = document.getElementById('chart-dd');
  const empty = document.getElementById('dd-empty');
  if (!el) return;
  destroyChart('dd');
  if (!series || series.length < 2) {
    el.style.display = 'none';
    if (empty) empty.style.display = 'block';
    return;
  }
  el.style.display = 'block';
  if (empty) empty.style.display = 'none';
  const ctx = el.getContext('2d');
  const grad = ctx.createLinearGradient(0, 0, 0, el.offsetHeight || 200);
  grad.addColorStop(0, 'rgba(239,68,68,0.00)');
  grad.addColorStop(1, 'rgba(239,68,68,0.30)');
  const opts = chartDefaults('line');
  opts.plugins.legend.display = false;
  opts.plugins.tooltip.callbacks.label = c => 'Drawdown: -$' + Math.abs(c.parsed.y).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  opts.scales.y.max = 0;
  opts.scales.y.ticks.callback = v => '-$' + Math.abs(v).toLocaleString('en-US');
  charts.dd = new Chart(ctx, {
    type: 'line',
    data: { labels, datasets: [{
      data: series,
      borderColor: '#ff6b8a',
      backgroundColor: grad,
      fill: { target: { value: 0 } },
      tension: 0.3,
      pointRadius: series.length > 25 ? 0 : 2.5,
      pointBackgroundColor: '#ff6b8a',
      borderWidth: 2,
    }]},
    options: opts
  });
}

function renderRHistogram(closed) {
  const el = document.getElementById('chart-rhist');
  const empty = document.getElementById('rhist-empty');
  if (!el) return;
  destroyChart('rhist');
  // Collect R multiples (only trades with a real stop)
  const rs = [];
  closed.forEach(t => {
    const sl = +t.stop || 0;
    if (!sl || !t.entryPrice) return;
    const risk = Math.abs((+t.entryPrice) - sl) * (+t.closedShares || +t.shares || 0);
    if (risk > 0) rs.push(calcTotal(t) / risk);
  });
  if (rs.length < 2) {
    el.style.display = 'none';
    if (empty) empty.style.display = 'block';
    return;
  }
  el.style.display = 'block';
  if (empty) empty.style.display = 'none';
  // Buckets: <-2R, -2..-1, -1..0, 0..1, 1..2, 2..3, 3..5, >5R
  const edges = [-Infinity, -2, -1, 0, 1, 2, 3, 5, Infinity];
  const names = ['< -2R', '-2..-1R', '-1..0R', '0..1R', '1..2R', '2..3R', '3..5R', '> 5R'];
  const counts = new Array(names.length).fill(0);
  rs.forEach(r => {
    for (let i = 0; i < edges.length - 1; i++) {
      if (r > edges[i] && r <= edges[i + 1]) { counts[i]++; break; }
    }
  });
  const colors = names.map((_, i) => i < 3 ? 'rgba(255,107,138,0.75)' : 'rgba(45,212,160,0.75)');
  const opts = chartDefaults('bar');
  opts.plugins.legend.display = false;
  opts.plugins.tooltip.callbacks.label = c => c.parsed.y + (c.parsed.y === 1 ? ' עסקה' : ' עסקאות');
  opts.scales.y.ticks.precision = 0;
  charts.rhist = new Chart(el.getContext('2d'), {
    type: 'bar',
    data: { labels: names, datasets: [{ data: counts, backgroundColor: colors, borderRadius: 6, maxBarThickness: 44 }] },
    options: opts
  });
}
